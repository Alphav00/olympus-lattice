---
slug: audio-formats-and-delivery
routing_description: Retrieve for sample rate, bit depth, codec choice, file formats, stems, metadata, or delivery specs for streaming, video, games and podcasts.
built: 2026-10-28
protocol: kb-v1
tags: [music, audio, formats, codecs, sample-rate, stems, delivery]
---

# Audio Formats and Delivery

## Sample rate and bit depth

Sample rate sets the highest representable frequency (Nyquist = half the rate). 44.1 kHz is the CD and music-streaming standard; 48 kHz is the video, broadcast and game standard; 96 kHz is used for sound design that will be pitched down and for some archival masters. Bit depth sets the noise floor: 16-bit = about 96 dB dynamic range (CD delivery), 24-bit = about 144 dB (tracking and mixing), 32-bit float = effectively unclippable inside a DAW and used for field recorders and intermediate renders. Always dither when reducing bit depth to 16 (TPDF or noise-shaped). Sample-rate convert once, at the end, with a high-quality SRC; avoid repeated conversions. Match the project rate to the delivery rate (48 kHz for anything going into video).

## Codecs

| Format | Type | Use |
|---|---|---|
| WAV / AIFF | uncompressed PCM | masters, stems, DAW interchange |
| FLAC | lossless, ~50-60% size | archives, lossless streaming, ComfyUI default |
| ALAC | lossless (Apple) | Apple ecosystem |
| MP3 | lossy, 320 kbps max | universal compatibility; artifacts above 16 kHz at low rates |
| AAC (m4a) | lossy, better than MP3 at same bitrate | Apple Music, YouTube, video |
| Opus | lossy, best at low bitrates | voice, Discord, WebRTC, web embeds |
| Ogg Vorbis | lossy | games, Spotify legacy |
| WebM | container for Opus/Vorbis | browsers |

Deliver lossless to distributors; they transcode. Never master from a lossy file. For web playback ship AAC or Opus plus an MP3 fallback. Loop points: WAV and OGG support cue/loop metadata, MP3 adds encoder padding and will not loop seamlessly.

## Stems and multitracks

Stems are grouped sub-mixes (drums, bass, music, vocals, FX) rendered from the same start point at the same length so they sum back to the mix. Multitracks are every individual track. Export stems as 24-bit WAV at the project rate, from bar 1 beat 1 to the mix end, with mix-bus processing either on all stems or on none (document which). Name consistently: `song_120bpm_Fmin_drums.wav`. Include a dry vocal and a wet vocal when sharing for remix. For AI separation (Demucs, UVR) expect bleed on reverbs and overlapping frequencies; 4-stem (vocals, drums, bass, other) is the reliable default, 6-stem adds guitar and piano with more error. Check that stems sum to the mix by phase-inverting against the master.

## Delivery specs by destination

| Destination | Format | Loudness |
|---|---|---|
| Streaming distributor | WAV 44.1/16 or 24-bit, stereo | -14 LUFS, -1 dBTP |
| Video / YouTube | 48 kHz AAC 320k or WAV in the edit | -14 LUFS |
| Podcast | 44.1 or 48 kHz MP3 128-192k mono/stereo | -16 LUFS stereo, -19 mono |
| Game engine | 48 kHz WAV or OGG/Opus; loops cue-marked | -16 to -20 LUFS, headroom for mixing |
| Broadcast | 48 kHz, 24-bit | -23 LUFS (EBU), -24 LKFS (US) |
| Vinyl pre-master | 24-bit, 44.1/48 kHz, dynamic | no limiting, mono bass |

Trim leading silence to about 0.1-0.5 s and leave the reverb tail. Fade the last 5-20 ms to avoid clicks. Embed metadata (title, artist, ISRC, BPM, key) via ID3/Vorbis tags with `ffmpeg -metadata`. Reference: [Apple Digital Masters guidelines](https://www.apple.com/apple-music/apple-digital-masters/).

## Quick ffmpeg conversions

```bash
ffmpeg -i in.flac -ar 48000 -sample_fmt s24 out48.wav
ffmpeg -i in.wav -c:a aac -b:a 320k out.m4a
ffmpeg -i in.wav -c:a libopus -b:a 96k -ac 1 voice.opus
ffmpeg -i in.wav -af "silenceremove=start_periods=1:start_threshold=-50dB" trimmed.wav
```

Expected: a new file at the stated rate/codec; `ffprobe out.wav` confirms. Failure: `-sample_fmt s24` is not valid for every encoder, use `pcm_s24le` via `-c:a pcm_s24le` if it errors.
