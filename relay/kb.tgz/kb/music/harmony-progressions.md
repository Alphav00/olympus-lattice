---
slug: harmony-progressions
routing_description: Retrieve when asked for chord progressions, Roman numeral analysis, what progression fits a genre, or how to reharmonize.
built: 2026-10-28
protocol: kb-v1
tags: [music, harmony, chord-progressions, roman-numerals, genre]
---

# Harmony and Progressions

## Reading Roman numerals

Uppercase = major, lowercase = minor, ° = diminished, + = augmented, superscript 7 = seventh chord. Numerals are relative to the key, so I-V-vi-IV in C = C-G-Am-F and in G = G-D-Em-C. Flat numerals (bVII, bVI) are borrowed from the parallel minor. Slash notation V/V means "the dominant of the dominant". Inversions use figured bass (I6 = first inversion, V64 = second). Capitalize consistently; in minor keys the natural chords are i ii° III iv v VI VII, with V (major) when harmonic minor is used.

## Pop and rock

| Name | Numerals | Examples / feel |
|---|---|---|
| Axis / four-chord | I-V-vi-IV | huge pop anthem staple |
| Sensitive female | vi-IV-I-V | same chords, minor start, wistful |
| 50s / doo-wop | I-vi-IV-V | ballads, retro |
| Mixolydian rock | I-bVII-IV | classic rock, "Sweet Home" shape |
| Andalusian | i-bVII-bVI-V | flamenco, surf, dramatic descent |
| Plagal loop | I-IV | gospel-rock vamp |
| Punk | I-IV-V | three chords, fast |
| Power ballad lift | IV-V-vi (pre-chorus) then I | tension into chorus |

Rotate the start chord to change mood without changing harmony (I-V-vi-IV vs vi-IV-I-V).

## Blues, jazz, soul

12-bar blues: I7 I7 I7 I7 / IV7 IV7 I7 I7 / V7 IV7 I7 V7 (turnaround). Quick-change puts IV7 in bar 2. Jazz blues adds ii-V in bars 9-10 and a VI7 in bar 8.

| Name | Numerals | Notes |
|---|---|---|
| ii-V-I | ii7-V7-Imaj7 | the jazz atom; in minor ii°7-V7b9-i |
| Rhythm changes A | I-vi-ii-V (x2), I-I7-IV-#iv°-I-V-I | 32-bar AABA |
| Turnaround | I-VI7-ii7-V7 | last 2 bars of a chorus |
| Coltrane changes | I-bIII7-bVI-VII7-III-V7-I | major 3rds cycle |
| Soul vamp | Imaj7-IVmaj7 or I7-IV7 | Marvin Gaye, neo-soul |
| Gospel walk-up | I-I/3-IV-#iv°-V | passing diminished |
| Backdoor | iv7-bVII7-I | softer than V7 |

Reharmonize by tritone sub (V7 -> bII7), adding secondary dominants, or chord-scale planing.

## EDM, hip-hop, R&B

Loop-based genres favor 2- or 4-chord cycles in minor. House/trance: i-VI-III-VII (vi-IV-I-V relative to major) and i-VII-VI-VII. Future bass/pop-EDM: IV-V-iii-vi or I-V-vi-iii-IV. Trap and drill often sit on a single minor chord or i-VI with melodic 808 implying harmony; harmonic interest comes from sample pitch and melody, not changes. Lo-fi hip-hop borrows jazz: ii7-V7-Imaj7-vi7 or Imaj7-iii7-vi7-ii7 with 9ths and 11ths, swung. R&B: I-iii-vi-IV with extended chords, chromatic bass walk-downs, borrowed iv for melancholy. Phonk/synthwave: i-VI-VII with arpeggiated minor 7ths. Sidechain and bass movement carry the harmony; keep voicings in a narrow mid register so the low end stays mono.

## Folk, country, Latin, film

Folk/country: I-IV-V-I, I-V-IV-I, and the "Nashville number system" (same idea as Roman numerals using Arabic digits, 1-4-5). Country ballad: I-V-vi-IV or I-iii-IV-V. Bossa/samba: Imaj7-ii7-V7-Imaj7 with chromatic descending ii-V chains, 6/9 chords. Flamenco: Phrygian i-bVII-bVI-V (Andalusian). Film score: Lydian I-II (I-II7 in Lydian) for wonder, i-bVI for heroic, chromatic mediants (I-bIII, I-bVI, I-III) for epic shifts, static pedal with changing upper chords for suspense. Classical period: I-IV-V7-I, I-ii6-V-I, circle-of-fifths sequences (vi-ii-V-I), Neapolitan bII6-V-i. Reference: [Hooktheory TheoryTab trends](https://www.hooktheory.com/theorytab/common-chord-progressions).
