---
slug: INDEX
routing_description: Index of the music knowledge bank; retrieve to decide which music file answers a question.
built: 2026-10-28
protocol: kb-v1
tags: [music, index]
---

# Music Bank Index

| File | Retrieve when |
|---|---|
| music-theory-core.md | intervals, scales, modes, chord construction and function, cadences |
| rhythm-and-meter.md | time signatures, tempo math, swing, syncopation, drum patterns, polyrhythm |
| harmony-progressions.md | chord progressions by genre in Roman numerals, reharmonization |
| song-structure-and-arrangement.md | song form, section lengths, arrangement density, transitions, duration planning |
| genre-reference.md | 29 genres with BPM, instrumentation, feel, reference eras; tag-list building |
| production-mixing-basics.md | gain staging, EQ ranges, compression, reverb, LUFS targets |
| lyric-writing-craft.md | meter, rhyme schemes, hooks, prosody, lyric formatting |
| ai-music-prompting.md | tags and lyrics for ACE-Step, HeartMuLa, Stable Audio, Suno-style tools; BPM/key/duration/section tags |
| comfyui-audio-nodes.md | ComfyUI audio workflows: ACE-Step, HeartMuLa, Stable Audio, VideoHelperSuite, ffmpeg loudnorm |
| audio-formats-and-delivery.md | sample rate, bit depth, codecs, stems, delivery specs, ffmpeg conversions |
| ear-training-and-analysis.md | analyzing a reference track (tempo, key, form, texture), ear-training drills |
