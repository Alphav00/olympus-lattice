---
slug: lyric-writing-craft
routing_description: Retrieve when writing, editing, or evaluating lyrics: meter, rhyme schemes, hooks, prosody, imagery, point of view, or lyric formatting for singers and generators.
built: 2026-10-28
protocol: kb-v1
tags: [music, lyrics, songwriting, rhyme, meter, prosody, hooks]
---

# Lyric Writing Craft

## Meter and stress

Lyrics are stressed syllables placed on strong beats. Count stresses per line, not syllables: a 4-stress line fits a 2-bar phrase in 4/4. Common feet: iamb (da-DUM, "to-DAY"), trochee (DUM-da, "NEV-er"), anapest (da-da-DUM), dactyl (DUM-da-da). Pop verses often run 4-stress lines in pairs; choruses shorten to 2-3 stresses so the words land harder. Match the natural spoken stress of a word to the musical accent; "guiTAR" on a downbeat sounds wrong as "GUItar". Melisma (several notes on one syllable) buys space when a line is short; cramming extra syllables into a bar is the usual error. Read the lyric aloud at tempo and tap the beat before setting a melody.

## Rhyme schemes and types

| Scheme | Pattern | Use |
|---|---|---|
| Couplet | AABB | nursery, punchline, rap bars |
| Alternate | ABAB | ballads, verses |
| Ballad | XAXA | folk; only lines 2 and 4 rhyme |
| Enclosed | ABBA | reflective, slower |
| Mono | AAAA | chant, hook, drill flows |

Rhyme types: perfect (light/night), family (sounds share consonant class: light/ride), slant/near (light/late), assonance (vowels only: light/time), consonance (final consonants: light/lot), internal (within a line), multisyllabic ("capital" / "rap at all"). Perfect rhyme closes; imperfect keeps motion. Rap stacks internal and multisyllabic rhymes across the bar; pop uses perfect rhymes at phrase ends. Avoid predictable pairs (fire/desire, heart/apart) unless subverted.

## Hooks and titles

The title should appear in the chorus, usually first or last line, often both. Hook types: melodic (the sung phrase), lyrical (the title line), rhythmic (chant or clap pattern), production (a signature sound). Chorus lyrics stay identical every time; verses carry new information. Write the chorus first so the verses know where they are going. A pre-chorus should end on an unresolved thought that the chorus answers. Keep chorus vocabulary simple and open-vowel (ah, oh, ay) for sustained notes; closed vowels (ee, ih) are harder to belt. Post-chorus: wordless or one repeated phrase. Test: can someone sing the hook after one listen?

## Prosody and point of view

Prosody = agreement between meaning, melody and harmony. Sad words on a minor chord or a descending line; uplift on rising lines and major arrival; a question ends on a high or unresolved note. Stable ideas get stable rhyme and even line lengths; unstable ideas get odd line counts, slant rhyme, and lines that spill over the bar. Point of view: first person (confessional), second ("you", direct address, most pop), third (story songs). Keep tense and person consistent within a section. Show rather than state: a concrete object (coffee going cold) beats an abstraction (loneliness). One idea per verse, one image per line; the chorus states the universal.

## Formatting for singers and generators

Write one sung line per text line; blank line between sections; label sections in brackets: [Intro], [Verse 1], [Pre-Chorus], [Chorus], [Verse 2], [Bridge], [Outro]. Mark repeats explicitly rather than "(x2)" when a generator must sing them. Write ad-libs in parentheses: (oh), (yeah). Spell numbers and abbreviations as sung ("twenty-four", "doctor"). Avoid stage directions inside lyric lines; put them in the section tag ([Chorus, big harmonies]) where the tool supports it. Syllable budget: about 8-12 per line for mid-tempo pop, 12-16 for rap bars. Reference: [Pat Pattison, Writing Better Lyrics (Berklee)](https://online.berklee.edu/courses/lyric-writing-tools-and-strategies).
