---
slug: ai-music-prompting
routing_description: Retrieve when writing prompts, tag strings, or structured lyrics for ACE-Step, HeartMuLa, Stable Audio, Suno/Udio-style generators, including BPM, key, duration and section tags.
built: 2026-10-28
protocol: kb-v1
tags: [music, ai, prompting, ace-step, heartmula, suno, stable-audio, tags]
---

# AI Music Prompting

## Two inputs: tags and lyrics

Tag-driven generators (ACE-Step, HeartMuLa, Suno, Udio) take a short comma-separated style string plus a lyrics text with section markers. The tags describe genre, instruments, vocal type, mood, tempo and era; the lyrics decide structure and words. ACE-Step's ComfyUI node `TextEncodeAceStepAudio` exposes exactly these two fields, `tags` and `lyrics` ([ComfyUI ACE-Step tutorial](https://docs.comfy.org/tutorials/audio/ace-step/ace-step-v1)). Keep tags to 6-12 items; too many compete. Order roughly: genre, sub-genre or era, instruments, vocal, mood, tempo. Instrumental: omit vocal tags and list instruments instead; ACE-Step treats empty lyrics plus instrument tags as instrumental.

## Tag string recipe

`<genre>, <sub-genre/era>, <2-3 instruments>, <vocal type>, <2 mood words>, <bpm> bpm, <key>`

Examples:

- `synthwave, 1980s, analog synths, gated drums, female vocal, nostalgic, driving, 110 bpm, F minor`
- `lo-fi hip hop, jazzy, Rhodes piano, dusty drums, vinyl crackle, instrumental, relaxed, 82 bpm`
- `folk, acoustic guitar, fiddle, male vocal, intimate, storytelling, 96 bpm, G major`

BPM tags such as "110 bpm" are the documented way to steer tempo in ACE-Step ([ComfyUI docs](https://docs.comfy.org/tutorials/audio/ace-step/ace-step-v1)). Key tags are soft hints; verify by ear. Use plain English descriptors, not artist names (most models ignore or refuse them). Negative or exclusion phrasing ("no drums") is unreliable; describe what you want instead ("solo piano, sparse").

## Lyric structure tags

Section markers go on their own line in square brackets: `[intro]`, `[verse]`, `[pre-chorus]`, `[chorus]`, `[bridge]`, `[outro]`. ACE-Step documents `[verse]`, `[chorus]`, `[bridge]`, `[outro]`; language prefixes like `[zh]`, `[ko]`, `[ja]` at the start of a line mark non-English lyrics, and only Japanese kana is auto-romanized in ComfyUI, so romanize other scripts first ([ComfyUI docs](https://docs.comfy.org/tutorials/audio/ace-step/ace-step-v1)). Suno-style metatags extend this with performance hints: `[Chorus, anthemic]`, `[Instrumental break]`, `[Guitar solo]`, `[Spoken word]`, `[Fade out]`; capitalization varies by tool ([Suno metatag guide](https://jackrighteous.com/blogs/guides-using-suno-ai-music-creation/understanding-suno-ai-a-comprehensive-guide-to-metatags)). Keep 4-8 lines per section, identical chorus text each time, and write ad-libs in parentheses.

## Duration, BPM, key, structure math

Duration is set in seconds (ACE-Step `EmptyAceStepLatentAudio`, Stable Audio `EmptyLatentAudio`, default 47.6 s for Stable Audio Open). Plan structure to fit: seconds per bar = 240 / BPM. At 120 BPM an 8-bar section is 16 s; intro + 2 verses + 3 choruses + bridge of 8 bars each = 64 bars = 128 s. Ask for slightly more than the plan so the outro is not cut. Short clips (10-30 s) suit Stable Audio Open and loops; full songs (120-240 s) suit ACE-Step and HeartMuLa. State tempo once in the tags; do not repeat it in the lyrics. If a generation drifts in tempo or key, lower the sampler's randomness (fewer steps is not the fix) and keep the seed to A/B tag changes.

## Model-specific notes

| Model | Input style | Notes |
|---|---|---|
| ACE-Step 1.x (3.5B) | tags + bracketed lyrics | audio-to-audio via `LoadAudio` + KSampler `denoise` < 1; `LatentOperationTonemapReinhard` multiplier raises vocal prominence |
| HeartMuLa | genre/vocal/mood/tempo tags + lyrics | ComfyUI packs expose a Tags Builder with genre, vocal_type, mood, tempo, instruments fields ([node page](https://www.runcomfy.com/comfyui-nodes/ComfyUI_FL-HeartMuLa/fl-heart-mu-la-tags-builder)) |
| Stable Audio Open 1.0 | single text prompt via `CLIPTextEncode` (T5) | no lyrics; best for SFX, loops, textures up to ~47 s |
| Suno / Udio | style box + lyrics with metatags | style box is tags; avoid artist names |

Iterate: fix tags, vary seed; then fix seed, vary one tag. Keep a log of tag strings that worked per genre.
