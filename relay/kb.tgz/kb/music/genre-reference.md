---
slug: genre-reference
routing_description: Retrieve when a genre name needs tempo range, typical instrumentation, feel, or reference era, including for building generator tag lists.
built: 2026-10-28
protocol: kb-v1
tags: [music, genre, tempo, instrumentation, reference]
---

# Genre Reference

Tempo in BPM. Eras are the canonical reference periods, not the only ones.

## Pop, rock, folk

| Genre | BPM | Instrumentation | Feel | Eras |
|---|---|---|---|---|
| Pop | 100-130 | synths, programmed drums, vocal stacks | bright, hooky, compressed | 1980s, 2010s |
| Indie rock | 110-150 | jangly guitars, live drums, bass | loose, melodic, lo-fi edge | 2000s |
| Classic rock | 110-140 | overdriven guitars, Hammond, live kit | driving backbeat | 1968-1979 |
| Punk | 160-200 | distorted guitars, shouted vocals | fast, raw, 3 chords | 1976-1984 |
| Metal | 90-200 | high-gain guitars, double kick, growls/clean | heavy, tight, modal | 1983-1992, 2005+ |
| Folk | 80-120 | acoustic guitar, fiddle, banjo, harmonies | intimate, narrative | 1960s |
| Country | 80-130 | Telecaster, pedal steel, fiddle, brushes | twangy, storytelling | 1990s, 2020s |

## Electronic

| Genre | BPM | Instrumentation | Feel | Eras |
|---|---|---|---|---|
| House | 118-128 | 909 kit, piano stabs, filtered disco samples | four-on-floor, warm | 1986-1995, 2015+ |
| Techno | 125-140 | 909/808, analog sequences, minimal | hypnotic, dark, driving | 1990s Detroit/Berlin |
| Trance | 130-142 | supersaws, arpeggios, long builds | euphoric, uplifting | 1996-2004 |
| Drum and bass | 160-180 | chopped breaks, Reese bass | fast, rolling | 1994-2002 |
| Dubstep | 138-142 (half-time) | wobble bass, sparse snare on 3 | heavy, spacious | 2006-2012 |
| Trap (EDM) | 140-160 | 808s, hi-hat rolls, brass stabs | aggressive, half-time | 2012-2016 |
| Synthwave | 80-118 | analog poly synths, gated reverb drums | nostalgic, cinematic | 2010s retro-80s |
| Ambient | 60-90 or beatless | pads, field recordings, granular | slow, spacious | 1978+ |
| Lo-fi hip-hop | 70-90 | dusty samples, jazz chords, vinyl crackle | relaxed, swung | 2015+ |

## Hip-hop, R&B, soul

| Genre | BPM | Instrumentation | Feel | Eras |
|---|---|---|---|---|
| Boom bap | 85-95 | chopped soul samples, MPC drums | swung, gritty | 1988-1997 |
| Trap (rap) | 130-170 (half-time 65-85) | 808 kick/bass, snappy snare, triplet hats | dark, minimal | 2010+ |
| Drill | 138-145 | sliding 808s, off-grid hats, eerie keys | tense, syncopated | 2012 Chicago, 2015+ UK |
| R&B | 60-100 | Rhodes, electric bass, layered vocals | smooth, melismatic | 1990s, 2010s alt |
| Soul | 90-120 | horns, Wurlitzer, live rhythm section | warm, gospel-rooted | 1965-1975 |
| Funk | 95-120 | clavinet, slap bass, tight horns, 16th-note guitar | syncopated on the 1 | 1970s |

## Jazz, Latin, world, classical

| Genre | BPM | Instrumentation | Feel | Eras |
|---|---|---|---|---|
| Swing jazz | 120-200 | big band horns, walking bass, ride | swung 8ths | 1935-1945 |
| Bebop | 200-300 | sax, trumpet, piano trio | fast, chromatic | 1945-1955 |
| Bossa nova | 120-140 | nylon guitar, soft brushes, flute | gentle, syncopated | 1958-1965 |
| Reggae | 60-90 | skank guitar on off-beats, one-drop drums, dub bass | laid back | 1970s |
| Reggaeton | 88-100 | dembow pattern, synth brass, auto-tuned vocals | bouncy | 2004+, 2017+ |
| Afrobeats | 95-115 | log drum, shakers, bright guitar, Auto-Tune | warm, polyrhythmic | 2015+ |
| Orchestral/film | varies | strings, brass, woodwinds, percussion | dynamic, thematic | 1900s Romantic, 1977+ Williams |

## Using the table

For generator prompts, convert one row into tags: genre, 2-3 instruments, feel words, era, BPM, vocal type. Example: "funk, clavinet, slap bass, tight horns, syncopated, 1970s, 108 bpm, male vocal". Half-time genres (trap, dubstep) can be written at either the full or halved BPM; state which when precision matters. Tempo ranges from [Hooktheory](https://www.hooktheory.com/) and genre descriptors from [AllMusic genre guides](https://www.allmusic.com/genres).
