---
slug: rhythm-and-meter
routing_description: Retrieve for time signatures, note values, tempo, syncopation, swing, groove, polyrhythm, or drum pattern questions.
built: 2026-10-28
protocol: kb-v1
tags: [music, rhythm, meter, tempo, groove, drums, syncopation]
---

# Rhythm and Meter

## Note values and tempo

Whole = 2 halves = 4 quarters = 8 eighths = 16 sixteenths. A dot adds half the value (dotted quarter = 1.5 beats). Tuplets squeeze n notes into the space of m (triplet = 3 in 2). Tie joins durations across a beat or bar. Tempo is in BPM (quarter-note beats per minute unless stated). Approximate ranges: Largo 40-60, Adagio 66-76, Andante 76-108, Moderato 108-120, Allegro 120-168, Presto 168-200. Beat duration ms = 60000 / BPM (120 BPM = 500 ms per quarter, 250 ms per eighth). Use this to set delay/reverb times and sample-accurate loop lengths.

## Meter

Time signature: top = beats per bar, bottom = beat unit. Simple meters divide beats in 2 (2/4, 3/4, 4/4); compound meters divide beats in 3 (6/8 = 2 dotted-quarter beats, 9/8 = 3, 12/8 = 4). Asymmetric/odd: 5/4 (3+2 or 2+3), 7/8 (2+2+3 typical). Metric accent: strong on 1, secondary on 3 in 4/4. Hypermeter groups bars into 4- or 8-bar phrases; pop sections are almost always multiples of 4 bars. Half-time halves the perceived pulse (snare on 3); double-time doubles it. Cut time (2/2) feels like fast 2 rather than 4. Mixed meter changes signature bar to bar; prog rock and film score use it for tension.

## Syncopation, swing, groove

Syncopation accents off-beats or weak beats (the "and" of 2, the 16th before the downbeat). Anticipation hits a chord slightly before the beat it belongs to. Swing delays the second eighth of each pair toward a triplet feel; swing % in DAWs maps 50% = straight, 66% = triplet. Shuffle = swung eighths in a blues/rock context. Groove also lives in micro-timing: pushing the snare late (hip-hop, Dilla feel), hi-hats slightly ahead for urgency. Humanize with 5-15 ms velocity and timing variation, never on the kick in dance music. The backbeat (snare on 2 and 4) is the spine of rock, soul and pop; the four-on-the-floor kick is the spine of house and disco.

## Common drum patterns

| Style | Kick | Snare/clap | Hats | Tempo |
|---|---|---|---|---|
| Rock backbeat | 1, 3 | 2, 4 | 8ths | 100-140 |
| Four-on-the-floor | every beat | 2, 4 | off-beat open hat | 118-130 |
| Boom bap | 1, "and" of 2, 3 | 2, 4 late | swung 8ths | 85-95 |
| Trap | 1, syncopated 3 | 3 (half-time) | 16ths with triplet rolls, 808 | 130-170 |
| Reggaeton (dembow) | 1, 3 | 1.75, 2.5, 3.75, 4.5 | sparse | 88-100 |
| Bossa nova | 1, 2.5, 3, 4.5 | rim clicks (clave) | brushed | 120-140 |
| Drum and bass | 1, 2.5 | 2, 4 (Amen break) | fast 16ths | 160-180 |
| Afrobeat / Afrobeats | 1, 2.5, 4 | off-beat log drum | shaker 16ths | 95-115 |

Beat position decimals: 2.5 = the "and" of 2.

## Polyrhythm and clave

Polyrhythm layers two pulses (3:2 hemiola, 4:3). Cross-rhythm shifts accents against the meter without changing it. Son clave (3-2): 1, 1.75, 2.5, 3.5, 4 in 4/4; the 2-3 version flips the bars. Tresillo = the 3-side alone (1, 1.75, 2.5), the engine of reggaeton, bounce, and much EDM. Euclidean rhythms spread k hits over n steps as evenly as possible (E(3,8) = tresillo, E(5,8) = cinquillo); useful for generative drum programming. Polymeter keeps the same pulse but different bar lengths (7/8 over 4/4 realign every 28 beats). Reference: [Open Music Theory on meter](https://viva.pressbooks.pub/openmusictheory/chapter/meter/).
