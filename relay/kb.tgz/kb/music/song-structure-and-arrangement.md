---
slug: song-structure-and-arrangement
routing_description: Retrieve for song form (verse/chorus/bridge), section lengths, arrangement density, transitions, intros and outros, or how to build a track over time.
built: 2026-10-28
protocol: kb-v1
tags: [music, songwriting, structure, arrangement, form]
---

# Song Structure and Arrangement

## Standard forms

| Form | Layout | Typical use |
|---|---|---|
| Verse-chorus | Intro V1 C V2 C Br C C Out | pop, rock, country |
| With pre-chorus | V PC C V PC C Br C | modern pop, lifts into hook |
| AABA | A A B A (32 bar) | jazz standards, early pop |
| 12-bar blues | I I I I IV IV I I V IV I V | blues, rock and roll |
| Strophic | V V V V | folk, hymns, ballads |
| Through-composed | no repeats | art song, prog, film |
| EDM | Intro Build Drop Break Build Drop Out | dance, 8/16-bar blocks |
| Hip-hop | Intro Hook V1 Hook V2 Hook Br Hook | 16-bar verses, 8-bar hooks |

Section letters: A = verse, B = chorus (or contrasting section in AABA), C = bridge. Radio pop targets 2:30-3:30; chorus by 0:45-1:00.

## Section lengths and jobs

Sections are multiples of 4 bars; 8 is the default, 16 for verses in rap and EDM. Intro: 4-8 bars, sets key, tempo, texture; may be a chorus instrumental. Verse: story, lower melodic range, new lyrics each time. Pre-chorus: 4-8 bars, rising tension, often ends on V or IV. Chorus: title, highest energy and range, same lyrics each time. Post-chorus: wordless hook or chant after the chorus (modern pop). Bridge: new chord or key area, new perspective, 8 bars, then a breakdown or last chorus. Breakdown/drop: EDM contrast pair; drop = full arrangement, break = stripped. Outro: fade, tag repeat of the hook, or hard stop on the downbeat. Rule: each section change should change at least two of harmony, melody range, rhythm, texture.

## Arrangement density

Think in layers: foundation (drums, bass), harmony (chords, pads), lead (vocal or melody), fills (counter-melody, ad-libs), FX (risers, impacts, ear candy). Energy curve: intro 30%, verse 50%, pre 65%, chorus 90%, bridge 40%, final chorus 100%. Add or remove one layer per 4-8 bars to keep motion. Subtractive arranging: mute the kick for the last bar before a drop, drop the bass in verse 2's first half, pull drums for a bridge. Frequency allocation: give each layer its own octave; low end mono and solo (one bass or one 808). Contrast beats volume: if everything is loud nothing is. Negative example: a pad holding all the way through makes the chorus feel no bigger; cut it in the verse.

## Transitions and fills

Drum fill in the last bar (or last 2 beats) of a section. Reverse cymbal or white-noise riser over 2-4 bars into a chorus/drop. Snare build: 8ths -> 16ths -> 32nds. Filter sweep: high-pass the full mix during a break, open before the drop. Silence or a single hit on the downbeat before the chorus (the "drop-out"). Pickup notes: start the vocal of the next section a beat early. Key change for the final chorus: up a half or whole step (truck-driver modulation). Half-time or double-time switch in a bridge. Tag the hook title line twice at the end. Keep automation (reverb send up, delay feedback up) for the last bar so the tail bleeds into the next section.

## Song-length planning

At 120 BPM, one 4/4 bar = 2 s; 8 bars = 16 s; a 3:00 song is about 90 bars. At 90 BPM a bar = 2.67 s; at 140 BPM 1.71 s. Convert bars to seconds = bars x 4 x 60 / BPM. Use this when a generator asks for duration in seconds: for a 2-verse pop song with intro, pre, chorus x3, bridge at 120 BPM plan about 100 bars = 200 s. Reference: [Berklee Online on song form](https://online.berklee.edu/takenote/songwriting-form/).
