---
slug: ear-training-and-analysis
routing_description: Retrieve when asked to analyze a track or reference song: find key, tempo, form, chord changes, texture, instrumentation, or to build ear-training exercises.
built: 2026-10-28
protocol: kb-v1
tags: [music, analysis, ear-training, key-detection, tempo, form, texture]
---

# Ear Training and Track Analysis

## Analysis checklist

Work in this order, writing one line per item: 1) tempo and meter, 2) key and mode, 3) form with timestamps, 4) chord progression per section in Roman numerals, 5) melody range and contour, 6) instrumentation and texture per section, 7) production traits (space, dynamics, stereo image), 8) the hook and what makes it memorable. Produce a timeline table: `time | section | bars | chords | texture notes`. This output is also the best brief for a generator: tags come from steps 1, 2, 6, 7; structure from step 3.

## Tempo and meter

Tap along and count 8 taps against a stopwatch: BPM = taps x 60 / seconds. Decide if the snare falls on 2 and 4 (standard) or only on 3 (half-time; double the count if it feels too slow). Check for triple subdivision (6/8, 12/8 shuffle) by counting "1-2-3" inside each beat. Odd meters reveal themselves when the phrase never lands evenly on 4. Tools: a DAW tap-tempo, or `librosa.beat.beat_track` for a numeric estimate; verify by ear because algorithms octave-error (report 70 instead of 140).

## Key and mode

Hum the note the song wants to rest on; that is the tonic. Play a major and a minor triad on it to pick mode. Confirm with the bass note at section ends and the last chord. Mode clues: b7 in a major-sounding song means Mixolydian; a raised 6 in a minor song means Dorian; b2 means Phrygian; #4 means Lydian. Key signature from the circle of fifths once tonic and mode are known. Relative major/minor ambiguity (C vs Am) is resolved by which chord feels like home, not by which appears first. Modulations: listen for a chorus or final section that sits a half or whole step higher.

## Form and chords

Mark every section change with a timestamp. Count bars per section (most are 8 or 16). Label with letters or names. For chords, find the bass note on the downbeat of each bar, then decide quality by singing the 3rd. Write in Roman numerals relative to the tonic so the analysis transfers to any key. Common tells: V at the end of a pre-chorus; vi at the start of a wistful section; bVII in rock; ii-V in jazz. Check whether the chorus and verse share the progression (loop songs) or contrast. Note repeated 2- or 4-chord loops versus functional progressions.

## Texture and production

Describe each layer: drums (acoustic, programmed, breakbeat), bass (electric, synth, 808), harmony (guitar, piano, pad, strings), lead (vocal type, range, processing), fills and FX. Texture vocabulary: monophonic (single line), homophonic (melody plus chords), polyphonic (independent lines), heterophonic (variants of one line together). Density: sparse, medium, wall-of-sound. Space: dry/close vs reverberant; stereo width narrow or wide; low end mono. Dynamics: loudness contour per section (does the chorus actually get louder, or just wider?). Era tells: gated reverb snare (1980s), 808 cowbell (1980s/2010s), sidechain pumping (2000s+), Auto-Tune as effect (2010s+).

## Ear-training drills

Intervals: anchor each to a melody start (m2 Jaws, M2 Happy Birthday, m3 Greensleeves, M3 Oh When the Saints, P4 Here Comes the Bride, tritone The Simpsons, P5 Star Wars, m6 The Entertainer, M6 My Bonnie, m7 Star Trek, M7 Take On Me, P8 Somewhere Over the Rainbow). Chords: sing root, 3rd, 5th of every chord you hear; then identify major/minor/dim/dom7 blind. Progressions: learn I, IV, V, vi by feel (home, lift, tension, sad). Rhythm: clap back 2-bar patterns, then write them. Daily 10 minutes beats weekly hours. Tools: [musictheory.net exercises](https://www.musictheory.net/exercises) and [Teoria](https://www.teoria.com/en/exercises/).
