---
slug: production-mixing-basics
routing_description: Retrieve for gain staging, EQ frequency ranges, compression settings, reverb/delay, loudness (LUFS) targets, or mix/master troubleshooting.
built: 2026-10-28
protocol: kb-v1
tags: [music, production, mixing, mastering, eq, compression, lufs]
---

# Production and Mixing Basics

## Gain staging

Record and mix with peaks around -18 to -12 dBFS per track; 24-bit gives about 144 dB of range so there is no benefit to tracking hot. Keep the mix bus peaking at or below -6 dBFS before mastering. Use a trim/gain plugin first in the chain, not the fader, so plugins receive their intended level (analog-modelled plugins expect roughly -18 dBFS RMS = 0 VU). Check mono compatibility with a mono switch; the low end should stay solid. Phase-align multi-mic sources (drums, DI plus amp) before EQ. Clip indicators that never light are the goal inside a 32-bit float DAW mixer, but the output stage and any fixed-point plugin still clip.

## EQ ranges

| Band | Hz | Content and moves |
|---|---|---|
| Sub | 20-60 | 808 fundamental, kick weight; high-pass everything else |
| Bass | 60-250 | bass body, kick punch (60-100), boxiness around 200-300 |
| Low mid | 250-500 | mud; cut 1-3 dB on guitars, pads, vocals |
| Mid | 500-2k | vocal presence 1-2k, nasal 800-1k, snare crack 1-2k |
| High mid | 2-6k | clarity, edge, harshness 3-5k, vocal sibilance 5-8k |
| Air | 6-20k | sparkle, shelf +1-3 dB, cymbal wash |

Subtractive before additive. High-pass non-bass tracks at 80-120 Hz. Narrow Q for cuts, wide Q for boosts. Dynamic EQ or de-esser for sibilance rather than static cuts. Sweep a boosted narrow band to find a resonance, then cut it.

## Compression

| Control | Starting point |
|---|---|
| Ratio | 2:1 glue, 4:1 vocals/bass, 8:1+ limiting |
| Attack | fast (1-10 ms) controls transients; slow (30+ ms) keeps punch |
| Release | 50-250 ms, or timed to the tempo so it breathes with the groove |
| Gain reduction | 2-4 dB on tracks, 1-2 dB on the bus |

Vocals: two stages (4:1 steady, then fast peak catcher) beat one heavy stage. Drums: parallel compression (crushed bus blended under) for density without losing transients. Sidechain: duck bass or pads under the kick 2-6 dB in dance music; use a fast attack, release before the next kick. Bus compression: 2:1, 30 ms attack, auto release, 1-2 dB. Multiband only when one band misbehaves. Negative example: fast attack on a snare removes the crack and makes it flat.

## Reverb, delay, space

Pre-delay 10-30 ms separates the source from its reverb and keeps vocals forward. Short rooms (0.4-0.8 s) for drums, plates (1-2 s) for vocals, halls (2-4 s) for pads and strings. High-pass the reverb return at 200-400 Hz and low-pass at 6-10 kHz to keep the mix clean. Delay times from tempo: ms = 60000 / BPM for a quarter note; dotted eighth = x0.75, eighth = x0.5. Slapback 80-120 ms for rockabilly/country vocals. Panning: kick, bass, lead vocal centre; double-tracked guitars hard left/right; hats slightly off-centre. Use send/return buses so several tracks share one space.

## Loudness targets

| Destination | Integrated LUFS | True peak |
|---|---|---|
| Streaming (Spotify, Apple, YouTube) | -14 | -1 dBTP |
| Spotify loud mode | -11 | -2 dBTP |
| Podcast / spoken word | -16 stereo, -19 mono | -1 dBTP |
| Broadcast EBU R128 | -23 | -1 dBTP |
| Broadcast ATSC A/85 (US TV) | -24 LKFS | -2 dBTP |
| Club / DJ masters | -8 to -6 | -0.3 dBTP |

Streaming platforms normalize to about -14 LUFS, so louder masters are turned down and lose dynamics for nothing. Measure integrated loudness over the whole track, short-term for sections, and keep loudness range (LRA) 4-9 LU for pop. Mastering chain order: corrective EQ, compression, saturation, stereo width, limiter last. Reference: [Spotify loudness normalization](https://support.spotify.com/us/artists/article/loudness-normalization/) and [EBU R128](https://tech.ebu.ch/publications/r128).
