---
slug: comfyui-audio-nodes
routing_description: Retrieve when building or debugging a ComfyUI audio workflow: ACE-Step, HeartMuLa, Stable Audio nodes, audio load/save, VideoHelperSuite audio, or ffmpeg loudness normalization.
built: 2026-10-28
protocol: kb-v1
tags: [music, comfyui, nodes, ace-step, heartmula, stable-audio, ffmpeg, loudness]
---

# ComfyUI Audio Nodes

## Core audio nodes (built in)

| Node | Role |
|---|---|
| `LoadAudio` | reads wav/mp3/flac from `input/`, outputs AUDIO |
| `SaveAudio` / `PreviewAudio` | writes to `output/audio/` (flac default); MP3/Opus variants exist in newer builds |
| `EmptyLatentAudio` | blank latent of N seconds for Stable Audio |
| `VAEEncodeAudio` / `VAEDecodeAudio` | audio <-> latent |
| `CheckpointLoaderSimple` | loads audio checkpoints with bundled VAE |
| `KSampler` | shared sampler for all audio diffusion models |

AUDIO is a dict of waveform tensor plus sample_rate; nodes that expect IMAGE will reject it. Keep sample rate consistent when chaining models (ACE-Step and Stable Audio Open both run at 44.1 kHz).

## ACE-Step workflow

Nodes per the [ComfyUI ACE-Step tutorial](https://docs.comfy.org/tutorials/audio/ace-step/ace-step-v1): `Load Checkpoints` (`ace_step_v1_3.5b.safetensors` in `models/checkpoints/`) -> `TextEncodeAceStepAudio` (fields `tags`, `lyrics`) -> `EmptyAceStepLatentAudio` (seconds) -> `KSampler` -> VAE decode -> `SaveAudio`. `LatentOperationTonemapReinhard` sits between sampler and decode; its `multiplier` raises vocal prominence. Audio-to-audio: feed `LoadAudio` -> `VAEEncodeAudio` into the sampler latent and set `denoise` below 1.0 (0.3-0.6 keeps the source groove; 1.0 ignores it). Lyrics use `[verse]` `[chorus]` `[bridge]` `[outro]` tags and `[zh]`/`[ko]`/`[ja]` language prefixes. Typical failure: lyrics in a non-romanized script produce mumbling; romanize first.

## HeartMuLa workflow

HeartMuLa is a lyrics-plus-tags song model with several community ComfyUI packs (`HeartMuLa_ComfyUI`, `ComfyUI_FL-HeartMuLa`, `CRT-HeartMuLa`). The FL pack chain is `FL HeartMuLa Model Loader` -> `FL HeartMuLa Tags Builder` (genre, vocal_type, mood, tempo, secondary_genre, instruments, additional_tags; outputs one comma-separated `tags` string) -> `FL HeartMuLa Conditioning` (tags + lyrics) -> `FL HeartMuLa Sampler` -> `FL HeartMuLa Decode` -> `SaveAudio`; a `FL HeartMuLa Transcribe` node returns lyrics from audio ([node reference](https://www.runcomfy.com/comfyui-nodes/ComfyUI_FL-HeartMuLa)). Tags Builder rejects an unknown genre value and badly formatted extra tags (stray spaces or symbols). Pack APIs change quickly; read the pack README for current field names before wiring.

## Stable Audio Open workflow

Per the [ComfyUI Stable Audio tutorial](https://docs.comfy.org/tutorials/audio/stable-audio/stable-audio-1): `CheckpointLoaderSimple` (`stable-audio-open-1.0.safetensors`, 2.3 GB, in `models/checkpoints/`) plus `t5-base.safetensors` in `models/text_encoders/` -> `CLIPTextEncode` positive and negative -> `EmptyLatentAudio` (default 47.6 s) -> `KSampler` -> `VAEDecodeAudio` -> `SaveAudio`. Prompts are short descriptive phrases ("heaven church electronic dance music"). Best for sound effects, drum loops, ambiences and instrumental textures; it has no lyric input and vocals come out as gibberish. For seamless loops set the length to an exact bar multiple (seconds = bars x 240 / BPM) and trim in a DAW.

## VideoHelperSuite and I/O

ComfyUI-VideoHelperSuite (VHS) handles audio for video: `VHS_LoadAudio` / `Load Audio (Path)` reads a file or URL, `VHS_VideoCombine` accepts an AUDIO input and muxes it into mp4/webm/gif output, and `VHS_LoadVideo` exposes the source audio track as an output so it can be re-attached after frame processing ([VHS repo](https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite)). Match frame_rate x frame count to audio length or the end will be clipped. For stems and extraction, community packs wrap Demucs; for pitch/tempo use `audio-separation-nodes-comfyui` or process externally.

## ffmpeg loudness and conversion

Two-pass EBU R128 normalization to streaming level:

```bash
ffmpeg -i in.wav -af loudnorm=I=-14:TP=-1:LRA=11:print_format=json -f null -
ffmpeg -i in.wav -af loudnorm=I=-14:TP=-1:LRA=11:measured_I=<I>:measured_TP=<TP>:measured_LRA=<LRA>:measured_thresh=<T>:linear=true -ar 44100 out.wav
```

Expected: pass 1 prints measured values; pass 2 writes `out.wav` at about -14 LUFS, -1 dBTP. Use `I=-16` for podcast. Failure: single-pass loudnorm resamples to 192 kHz internally, so always set `-ar`. Encode: `ffmpeg -i out.wav -c:a libmp3lame -b:a 320k out.mp3`; `-c:a libopus -b:a 128k out.opus`; `-c:a flac out.flac`. Measure only: `-af ebur128=peak=true -f null -`. Docs: [ffmpeg loudnorm](https://ffmpeg.org/ffmpeg-filters.html#loudnorm).
