---
slug: music-theory-core
routing_description: Retrieve when a question involves intervals, scales, modes, chord construction, chord function, or cadences.
built: 2026-10-28
protocol: kb-v1
tags: [music, theory, intervals, scales, modes, harmony, cadences]
---

# Music Theory Core

## Intervals

Distance between two pitches, counted in semitones (st). Quality + number names the interval.

| Interval | st | Quality notes |
|---|---|---|
| Unison / P1 | 0 | |
| m2 / M2 | 1 / 2 | step |
| m3 / M3 | 3 / 4 | defines minor/major triad |
| P4 | 5 | perfect |
| A4 / d5 (tritone) | 6 | dissonant, drives V7 to I |
| P5 | 7 | perfect |
| m6 / M6 | 8 / 9 | |
| m7 / M7 | 10 / 11 | M7 = leading tone to octave |
| P8 | 12 | |

Inversion rule: interval + its inversion = 9; major becomes minor, augmented becomes diminished, perfect stays perfect. Compound intervals (9th, 11th, 13th) = simple interval + 12 st. Consonant: P1, P5, P8, 3rds, 6ths. Dissonant: 2nds, 7ths, tritone (resolve by step).

## Scales

Major: W W H W W H W (C D E F G A B). Natural minor: W H W W H W W. Harmonic minor raises degree 7 (creates V7 in minor); melodic minor raises 6 and 7 ascending. Pentatonic major = degrees 1 2 3 5 6; minor pentatonic = 1 b3 4 5 b7; blues = minor pentatonic + b5. Chromatic = all 12. Whole-tone = 6 notes, all W. Octatonic/diminished alternates H W.

Key signatures follow the circle of fifths: each sharp added moves up a 5th (G D A E B F# C#), each flat down a 5th (F Bb Eb Ab Db Gb Cb). Relative minor sits a m3 below the major tonic (C major / A minor). Parallel minor shares the tonic (C major / C minor).

## Modes

Seven rotations of the major scale. Characteristic degree in bold.

| Mode | Formula | Character |
|---|---|---|
| Ionian | 1 2 3 4 5 6 7 | major, bright |
| Dorian | 1 2 b3 4 5 **6** b7 | minor with raised 6, jazz/funk |
| Phrygian | 1 **b2** b3 4 5 b6 b7 | dark, flamenco/metal |
| Lydian | 1 2 3 **#4** 5 6 7 | dreamy, film score |
| Mixolydian | 1 2 3 4 5 6 **b7** | major with b7, rock/blues |
| Aeolian | 1 2 b3 4 5 b6 b7 | natural minor |
| Locrian | 1 b2 b3 4 **b5** b6 b7 | unstable, rare as tonic |

Modal writing: avoid the dominant V-I pull; emphasize the characteristic degree and use a drone or pedal on the tonic.

## Chord construction

Triad = root + 3rd + 5th. Major (M3+m3), minor (m3+M3), diminished (m3+m3), augmented (M3+M3). Seventh chords stack another 3rd: maj7 (M triad + M7), dom7 (M triad + m7), min7, m7b5 (half-diminished), dim7 (all m3), minMaj7. Extensions: 9, 11, 13 (add tones above the 7th; "add9" omits the 7th). Sus chords replace the 3rd with 2 or 4. Slash chord C/E = C major with E in the bass (first inversion). Inversions: root, 1st (3rd in bass), 2nd (5th in bass), 3rd (7th in bass). Shell voicing = root, 3rd, 7th; guide tones = 3rd and 7th (carry the harmony in jazz).

## Chord function

Diatonic chords in a major key: I ii iii IV V vi vii°. Functional groups: Tonic (I, vi, iii) rest; Predominant/Subdominant (IV, ii) prepare; Dominant (V, vii°) demand resolution. In minor: i ii° III iv v(V) VI VII; V is usually borrowed from harmonic minor to get a leading tone. Secondary dominants (V/V = II7, V/ii, V/vi) tonicize a diatonic chord. Borrowed chords (modal mixture) pull from the parallel mode: bVI, bVII, iv in major. Tritone substitution: replace V7 with the dominant 7th a tritone away (G7 -> Db7); guide tones are shared. Negative example: writing vii° as a resting chord; it is dominant-function and must move.

## Cadences

| Cadence | Motion | Effect |
|---|---|---|
| Perfect authentic (PAC) | V(7) -> I, both root position, tonic in melody | full stop |
| Imperfect authentic (IAC) | V -> I with inversion or 3rd/5th on top | softer close |
| Half | any -> V | question, phrase end |
| Plagal | IV -> I | "amen", gentle |
| Deceptive | V -> vi | surprise, extends phrase |
| Phrygian half | iv6 -> V in minor | baroque, b6 descends to 5 |
| Backdoor | bVII7 -> I | jazz/soul alternative to V7 |

Voice leading: resolve the leading tone up to the tonic and the 7th of V7 down by step; avoid parallel 5ths/8ves in strict styles; keep common tones. Reference: [Open Music Theory](https://viva.pressbooks.pub/openmusictheory/).
