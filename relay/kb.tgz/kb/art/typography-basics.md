---
slug: typography-basics
routing_description: Retrieve for font classification, pairing, type scale, line length and leading, hierarchy, kerning, or web font performance questions.
built: 2026-10-28
protocol: kb-v1
tags: [art, typography, fonts, layout, design, web]
---

# Typography Basics

## Anatomy and measurement

Baseline (where letters sit), x-height (height of lowercase x), cap height, ascender and descender. Point size measures the em box, not the visible letter, so two fonts at 16 px can look very different; compare by x-height. Leading = line spacing, set as line-height 1.4-1.6 for body text, 1.0-1.2 for headlines. Tracking = uniform letter spacing (loosen small caps and all-caps by 5-10%, tighten large display type slightly). Kerning = spacing between specific pairs; turn on font kerning and OpenType features (`font-kerning: normal`, `font-feature-settings`). Measure = line length; 45-75 characters per line (about 66 ideal) for comfortable reading, 35-50 for narrow columns. Widows (single word on last line) and orphans (lone line at a page/column top) are fixed by rewriting or `text-wrap: balance`/`pretty`.

## Classification

| Class | Traits | Examples | Voice |
|---|---|---|---|
| Humanist serif | calligraphic stress, low contrast | Garamond, Jenson | literary, warm |
| Transitional serif | more contrast, vertical stress | Baskerville, Times | authoritative |
| Didone / modern serif | hairline serifs, high contrast | Bodoni, Didot | fashion, luxury |
| Slab serif | heavy block serifs | Rockwell, Roboto Slab | sturdy, editorial |
| Grotesque sans | early sans, quirky | Franklin Gothic, Akzidenz | industrial |
| Neo-grotesque | neutral, closed apertures | Helvetica, Inter, Arial | corporate, plain |
| Humanist sans | open apertures, calligraphic | Gill Sans, Source Sans | friendly, legible |
| Geometric sans | circles and lines | Futura, Montserrat, Poppins | modern, tech |
| Monospace | fixed width | JetBrains Mono, Courier | code, technical |
| Script / display | decorative, single use | Pacifico, Playfair Display | headline only |

## Pairing and hierarchy

Pair by contrast with shared bones: a serif for body with a sans for headings (or the reverse), matching x-height and width. Avoid two fonts from the same class (two geometric sans) unless they are one superfamily. Limit to two families plus a monospace if code appears. Hierarchy comes from size, weight, case, color and space; change at most two variables per level. Modular type scale: pick a base (16 px) and ratio (1.25 major third, 1.333 perfect fourth, 1.5 perfect fifth) and derive sizes: 16, 20, 25, 31, 39 for 1.25. Headline tracking tightens as size grows. Minimum body size on screens 16 px; captions 12-13 px; touch UI labels 14 px+. Use real small caps and old-style numerals in running text, lining numerals in tables.

## Legibility and accessibility

Contrast per WCAG (4.5:1 body, 3:1 large). Avoid light grey on white below 4.5:1. Left-align ragged-right for long text; justified needs hyphenation to avoid rivers. Do not set long passages in all caps, italics, or ultra-light weights. Distinguish I, l and 1 and O and 0 in UI and code fonts. Dyslexia-friendly measures: generous letter spacing, line-height 1.5, clear word spacing; no single font fixes it. Respect user zoom: use rem/em, not px, for text; never disable pinch zoom. Reading order in the DOM must match the visual order.

## Web font delivery

Prefer variable fonts (one file, all weights) in WOFF2. Subset to needed scripts (Latin only shrinks a file to 15-30 KB). Load critical fonts with `<link rel="preload" as="font" type="font/woff2" crossorigin>` and `font-display: swap` or `optional`; set a metric-matched fallback (`size-adjust`, `ascent-override`) to avoid layout shift. Self-host when you control caching; Google Fonts is acceptable for prototypes. Test at 320 px wide and at 200% zoom. Keep headings as live text, never images, for SEO and accessibility. Reference: [Butterick's Practical Typography](https://practicaltypography.com/) and [MDN font-display](https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/font-display).
