---
slug: ai-image-prompting
routing_description: Retrieve when writing or fixing image-generation prompts for FLUX.2, FLUX.1, Qwen-Image, SDXL or similar: prompt anatomy, negative prompts, aspect ratios, seeds, CFG/guidance, LoRA weights, per-model behavior.
built: 2026-10-28
protocol: kb-v1
tags: [art, ai, prompting, flux, qwen-image, sdxl, lora, comfyui]
---

# AI Image Prompting

## Prompt anatomy

Order: subject (who/what, count, pose, expression), setting (where, time), medium and style (photo, oil, 3D render, movement), lighting (direction, quality, source), camera (lens, angle, DOF), palette and mood, then any text to render in quotes. One clear subject per prompt; describe relationships explicitly ("a red fox standing left of a blue mailbox"). Specifics beat adjectives: "weathered brass compass" over "beautiful detailed object". Avoid contradictory stacks (three art movements at once) and vague quality words ("masterpiece, 8k") on modern models; they shift style toward stock imagery. Length: 1-3 sentences for Qwen-Image per [Segmind's guide](https://blog.segmind.com/qwen-image-prompt-parameter-guide/); FLUX models take long natural-language paragraphs; SDXL prefers comma-separated phrases with the most important first.

## Model family behavior

| Family | Encoder / input | Responds to | Negative prompt |
|---|---|---|---|
| FLUX.2 dev (32B) | Mistral-3 Small text encoder (`mistral_3_small_flux2_bf16`), up to 10 reference images, up to 4 MP | long natural prose, structured/JSON-style prompts, hex color codes for brand colors | not used; guidance distilled; describe what you want |
| FLUX.1 dev / schnell | T5-XXL + CLIP-L | natural language, legible short text | none (guidance embedded); schnell 4 steps |
| Qwen-Image (20B MMDiT) | Qwen2.5-VL 7B | plain 1-3 sentence prompts, exact text in double quotes, posters and layouts | via CFG; cfg 4-5, 20-30 steps draft, 50 final |
| SDXL 1.0 and fine-tunes | CLIP-L + CLIP-G, 77 tokens per chunk | tag-like phrases, weights `(word:1.2)`, style LoRAs | yes, essential; cfg 5-8, 25-35 steps |

Sources: [ComfyUI FLUX.2 docs](https://github.com/Comfy-Org/docs/pull/596/files), [ComfyUI Wiki](https://comfyui-wiki.com/en/models/flux/flux-2).

## Negative prompts and weights

SDXL: keep negatives short and relevant ("blurry, extra fingers, watermark, text, low contrast"); long generic negatives reduce diversity. Prompt weights `(word:1.3)` or `[word]` (0.9) work in SDXL via the CLIP encoder; FLUX and Qwen read natural language and mostly ignore parenthesis weights, so use emphasis words and sentence order instead. For distilled models with no negative input (FLUX dev/schnell), put the exclusion into the positive ("empty hands", "clean background"). CFG: too high gives oversaturated, crunchy output; too low ignores the prompt. FLUX uses `guidance` 3.5 default (lower 2-3 for photoreal, higher for graphic). Qwen-Image cfg 4-5. SDXL cfg 5-8.

## Aspect ratio, resolution, seeds

| Model | Native sizes |
|---|---|
| SDXL | 1024x1024, 1152x896, 896x1152, 1216x832, 832x1216, 1344x768, 768x1344 (about 1 MP) |
| FLUX.1 | 0.5-2 MP, any ratio, multiples of 16 |
| FLUX.2 | up to 4 MP (2048x2048), any ratio |
| Qwen-Image | 1328x1328, 1664x928, 928x1664, 1472x1140, 1140x1472 |

Generating far from native size causes doubled subjects (SDXL) or soft detail; upscale afterwards instead. Seed: fix it to compare prompt edits one variable at a time; vary it to explore; record seed plus full prompt and sampler for reproducibility. Batch 4 at low steps for triage, then re-render the winner at full steps. Samplers: euler/simple for FLUX and Qwen; dpmpp_2m karras for SDXL.

## LoRA use

Load with `LoraLoader` (model and clip strengths) or `LoraLoaderModelOnly` for FLUX/Qwen. Typical strength 0.6-0.9; above 1.0 overfits and warps anatomy; stack two or three LoRAs with total weight under about 1.8. Include the LoRA's trigger word from its model card. Style LoRA plus character LoRA: lower each to 0.6-0.7. Check the LoRA's base model matches your checkpoint (SDXL LoRAs do not load into FLUX). For text-heavy images prefer the base model over style LoRAs, which degrade text rendering.

## Templates

Photo (FLUX): "A candid 35mm photograph of a woman in her sixties repairing a bicycle in a sunlit garage, soft window light from the left, shallow depth of field, Kodak Portra colors, dust in the air."

Poster (Qwen-Image): "A minimalist concert poster, flat vector style, teal and orange. The headline text reads "NIGHT SIGNALS" in bold geometric sans-serif; smaller text below reads "OCT 28 - THE LATTICE"."

SDXL: "portrait of a knight, intricate armor, cinematic lighting, dramatic sky, oil painting, by the style of Baroque masters, highly detailed" with negative "blurry, deformed, extra limbs, text, watermark".
