---
slug: INDEX
routing_description: Index of the art knowledge bank; retrieve to decide which art or design file answers a question.
built: 2026-10-28
protocol: kb-v1
tags: [art, index]
---

# Art Bank Index

| File | Retrieve when |
|---|---|
| art-history-timeline.md | movements with dates, traits, key figures; era words for style prompts |
| composition-principles.md | rule of thirds, golden ratio, leading lines, negative space, hierarchy, aspect ratios |
| color-theory.md | color wheel harmonies, temperature, value, OKLCH palettes, WCAG contrast ratios |
| light-and-shadow.md | key/fill/rim, hard vs soft, shadow anatomy, time of day, volumetrics, lighting prompt words |
| perspective-and-form.md | 1/2/3-point perspective, form construction, figure proportion, lens and camera language |
| visual-styles-glossary.md | 40 styles and media with traits and three descriptor words each |
| typography-basics.md | font classes, pairing, type scale, legibility, web font delivery |
| illustration-and-character-design.md | shape language, silhouette, color script, turnarounds, character consistency |
| ai-image-prompting.md | prompt anatomy and settings for FLUX.2, FLUX.1, Qwen-Image, SDXL; negatives, ratios, seeds, LoRA weights |
| comfyui-image-nodes.md | FaceDetailer, controlnet_aux, IPAdapter, InstantID, upscalers, KJNodes and when to use each |
| svg-and-vector-craft.md | SVG paths, strokes, viewBox, defs, optimization, accessibility, animation; SVG vs raster |
| critique-vocabulary.md | giving and receiving design critique, fault/fix table, critique terms |
