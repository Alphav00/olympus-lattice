---
slug: composition-principles
routing_description: Retrieve for image layout questions: rule of thirds, golden ratio, leading lines, negative space, visual hierarchy, balance, framing, or why a composition feels off.
built: 2026-10-28
protocol: kb-v1
tags: [art, composition, layout, design, hierarchy]
---

# Composition Principles

## Grids and placement

Rule of thirds: divide the frame 3x3; place the subject on a line or intersection, horizon on the upper or lower third. Golden ratio (1:1.618): the phi grid puts the strongest point about 38% in from an edge instead of 33%; the golden spiral guides the eye along a curve to a focal point. Centered composition works for symmetry, confrontation and icons; off-center for narrative and motion. Triangles stabilize groups of three; the pyramid (wide base, apex at the face) is the classic portrait structure. Dynamic symmetry (root rectangles, reciprocals and diagonals) underlies much classical painting. Leave headroom and lead room: more space in front of a moving subject or a gaze than behind it. Negative example: a horizon exactly at centre splits the image into two competing halves.

## Leading lines and flow

The eye enters where contrast is highest, then follows edges, lines, gazes and gradients. Diagonals add energy; horizontals calm; verticals assert; S-curves invite a slow stroll. Converging lines (roads, rails, architecture) pull toward a vanishing point; put the subject there or just before it. Implied lines come from eye direction and pointing gestures; characters looking out of frame leak attention. Design a path: entry (bottom-left in left-to-right cultures), travel, focal point, rest, exit or loop. Frame within a frame (doorway, window, foliage) tightens focus. Repetition with one break (pattern interrupt) makes the exception the subject.

## Negative space and balance

Negative space is the empty area around subjects; it gives scale, breath and emphasis. Figure-ground: strong silhouettes read against simple backgrounds; busy backgrounds need value separation. Balance types: symmetric (formal), asymmetric (a large light shape balanced by a small dark one), radial (spokes from a centre). Visual weight increases with size, darkness, saturation, detail, isolation and proximity to edges. Tangents (an edge just touching another, a horizon cutting through a neck) create accidental tension; overlap or separate clearly. Crop decisions: cut through limbs between joints, never at joints; keep the chin or the eyes away from the exact centre line.

## Hierarchy and focal point

One primary focal point, one or two secondary, everything else subordinate. Build hierarchy with contrast of value (the strongest tool), saturation, size, sharpness (depth of field), detail density, color temperature and isolation. Squint test: blur the image; the subject must still read. Notan (two-value study) checks the light/dark pattern before rendering. Three-value plan: dark, mid, light, with the subject carrying the largest value jump. In UI and poster work the same rules give a reading order: headline, image, body, call to action. Edges: soft and lost edges push things back; hard, lit edges come forward.

## Aspect ratios and formats

| Ratio | Use |
|---|---|
| 1:1 | social feeds, icons, album art |
| 4:5 / 5:4 | portrait feed posts, prints |
| 3:2 / 2:3 | 35 mm photo, book covers |
| 4:3 | classic screens, illustration |
| 16:9 / 9:16 | video, wallpapers, stories and reels |
| 2.39:1 | anamorphic cinema |
| 1:1.414 (A-series) | print documents |

Compose for the delivery crop; keep key elements inside a safe zone (about 10% margin) so platform overlays and crops do not clip them. Reference: [Kimon Nicolaides and Andrew Loomis via Internet Archive](https://archive.org/details/creativeillustration) and [Google Arts & Culture composition primer](https://artsandculture.google.com/story/the-rule-of-thirds/).
