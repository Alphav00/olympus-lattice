---
slug: light-and-shadow
routing_description: Retrieve for lighting setups (key/fill/rim), hard vs soft light, shadow terminology, time-of-day light, volumetrics, or lighting words for image prompts.
built: 2026-10-28
protocol: kb-v1
tags: [art, lighting, shadow, cinematography, rendering, prompts]
---

# Light and Shadow

## Form shadow anatomy

On a lit sphere, from light to dark: highlight (specular, reflects the source), light (direct), halftone (grazing light), terminator (the turn where light ends), core shadow (darkest part of the form shadow, just past the terminator), reflected light (bounce from the environment, never brighter than the lit side), and the cast shadow on the ground, darkest at the occlusion point where the object touches the surface and softer toward its edge. Form shadows describe volume; cast shadows describe position and the light's direction. Shadow color = local color darkened and shifted toward the ambient light's complement; shadows under a blue sky lean cool. Negative example: a cast shadow lighter than the core shadow flattens the object.

## Three-point and studio setups

| Light | Position | Job |
|---|---|---|
| Key | 30-45 deg off camera axis, above eye line | main form and mood |
| Fill | opposite side, lower intensity | controls shadow depth (key:fill ratio 2:1 soft, 8:1 dramatic) |
| Rim / back | behind subject, aimed at edges | separates subject from background, hair light |
| Background / kicker | on the set | depth, color wash |

Named looks: Rembrandt (triangle of light on the shadow cheek), butterfly/paramount (key high and frontal, shadow under nose), split (key at 90 deg, half face dark), loop (small nose shadow), broad vs short lighting (lit side toward or away from camera). High-key = bright, low contrast, airy; low-key = dark, high contrast, noir. Clamshell (key above, reflector below) for beauty.

## Hard, soft, and direction

Hardness depends on the source's apparent size: small or distant sources (sun, bare bulb) give crisp shadows and sharp highlights; large or diffused sources (overcast sky, softbox, window with sheer) give gradual terminators and broad highlights. Distance to subject also matters: the closer a softbox, the softer. Direction words for prompts: front-lit (flat, detail), side-lit (texture, form), backlit (silhouette, glow, lens flare), top-lit (noon, heavy eye sockets), under-lit (uncanny, horror). Overhead soft light flatters interiors; a single hard side light reads as drama. Specular materials (metal, wet skin) show the source's shape; matte materials spread it.

## Time of day and natural light

| Time | Light quality | Palette |
|---|---|---|
| Blue hour (pre-dawn, post-sunset) | soft, shadowless, cool | deep blue, magenta, artificial lights pop |
| Golden hour | low, warm, long shadows, rim glow | orange-gold key, blue-violet shadows |
| Midday | hard, overhead, short shadows | neutral, high contrast, washed sky |
| Overcast | giant softbox, low contrast | desaturated, cool grey, saturated local color |
| Night (moon) | dim, hard but low contrast | painted as cool blue, warm practicals |
| Window light | directional soft, falls off fast | neutral or cool, warm interior bounce |

Atmospheric perspective: distant objects lighter, bluer, lower contrast. Sky dome is a cool fill from above; ground bounce is a warm fill from below.

## Volumetrics and effects

God rays (crepuscular rays) need a bright source, an occluder (trees, blinds, clouds) and particles (dust, fog, smoke). Fog or haze compresses value range with distance and halos lights. Subsurface scattering lights skin, wax, leaves and marble from within at thin edges (ears, fingers, petals); its color is the material's transmission color (red-orange for skin). Caustics are focused light patterns under water or glass. Bloom is highlight glow in camera. Lens flare and anamorphic streaks come from bright sources in frame. Practical lights (lamps, screens, neon) motivate color contrast: warm practical against cool ambient is the default cinematic pairing.

## Prompt vocabulary and references

Lighting words that transfer across image models: "soft window light", "golden hour backlight", "hard noon sun", "volumetric fog", "rim light", "chiaroscuro", "low-key", "high-key", "overcast diffuse", "Rembrandt lighting", "neon practicals", "subsurface scattering". Combine one direction word, one quality word and one time or source word. Reference: [James Gurney, Color and Light](https://jamesgurney.com/products/color-and-light-a-guide-for-the-realist-painter) and [Blain Brown, Cinematography](https://www.routledge.com/Cinematography-Theory-and-Practice/Brown/p/book/9780367373467).
