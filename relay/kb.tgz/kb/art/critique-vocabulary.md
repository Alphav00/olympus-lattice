---
slug: critique-vocabulary
routing_description: Retrieve when giving or receiving art or design critique: structure, vocabulary, common faults and their fixes, and how to turn feedback into actions.
built: 2026-10-28
protocol: kb-v1
tags: [art, critique, feedback, design-review, vocabulary]
---

# Critique Vocabulary

## Structure of a useful critique

1. State the goal as you understand it (audience, medium, intent); confirm before judging. 2. Describe what you see neutrally (describe-analyze-interpret-evaluate, the Feldman method). 3. Name what works and why, tied to a principle. 4. Name the highest-leverage problems, at most three, each with evidence in the image and a concrete fix. 5. Separate taste from craft: craft issues (tangents, value muddle, unreadable type) are objective; taste (palette preference) is labelled as such. 6. End with the one change that would most improve it. Write critique in the imperative with location: "Lower the value of the background behind the head so the silhouette reads." Avoid "I like/I don't like" without a reason.

## Vocabulary: form and composition

| Term | Meaning |
|---|---|
| Read / readability | whether the subject and intent are understood at a glance |
| Focal point | where the eye lands first; competing focal points split attention |
| Hierarchy | ordered importance of elements |
| Tangent | edges touching or aligning accidentally, creating confusion |
| Value structure / notan | the light-dark pattern; "muddy" means too many mid-values |
| Silhouette | outline readability |
| Flow / eye path | the route the viewer's eye travels |
| Dead space vs negative space | empty area that does nothing vs empty area that frames |
| Crowding | elements too close to edges or each other |
| Scale and proportion | relative size relationships; "off-model" when a character deviates |
| Rendering vs design | finish quality vs underlying decisions; polish cannot fix design |

## Vocabulary: color, light, surface

Chroma/saturation: "oversaturated" (everything at full chroma competes), "chalky" (too much white in shadows), "muddy" (complement-mixed greys everywhere). Temperature: "warm/cool conflict" when light and shadow temperature are the same. "Flat lighting" lacks form shadow; "floating" means a missing contact shadow. "Local color only" means no influence of light or environment. Edges: "all hard" looks cut-out, "all soft" looks blurry; aim for varied edges. "Over-rendered" means detail everywhere, no rest areas. Texture: "noisy" (visual static), "plastic" (uniform specular), "stock" (generic, template-like). Type: "widows", "rivers", "tight leading", "weak hierarchy", "mismatched x-heights". For AI output: "artifacting", "melted hands", "prompt bleed" (attributes leaking to the wrong object), "sameface".

## Common faults and fixes

| Fault | Fix |
|---|---|
| No focal point | increase value contrast at one spot, lower it elsewhere |
| Tangents | overlap decisively or separate by a clear gap |
| Muddy values | reduce to three value groups; squint test |
| Oversaturation | desaturate 80% of the image, keep chroma at the focal point |
| Flat forms | add core shadow and contact shadow; vary edge hardness |
| Busy background | blur, simplify, or lower contrast behind the subject |
| Weak type hierarchy | change two variables (size and weight) between levels |
| Cluttered layout | align to a grid, increase margins, remove one element |
| Inconsistent style | one medium, one light source, one era per image |

## Receiving critique

Restate the feedback to confirm understanding before responding. Ask for the goal the critic assumed; mismatch there explains most disagreement. Separate the three kinds: factual (a tangent exists), principle-based (hierarchy is weak), preference (they would use blue). Act on the first two; weigh the third against the brief. Collect feedback from several people and look for repeats; a note heard once is data, three times is a pattern. Keep a change log tied to each note so the critic can see what moved. Do not defend in the moment; thank, note, decide later. Reference: [Feldman's method summary (Art Education)](https://www.incredibleart.org/files/feldman.htm) and [Discussing Design, Connor and Irizarry](https://www.oreilly.com/library/view/discussing-design/9781491902394/).
