---
slug: illustration-and-character-design
routing_description: Retrieve for character design: shape language, silhouette, proportion, costume and color scripts, turnarounds, expression sheets, and consistency across images.
built: 2026-10-28
protocol: kb-v1
tags: [art, character-design, illustration, shape-language, silhouette, turnaround]
---

# Illustration and Character Design

## Shape language

Primary shapes carry meaning before detail does: circles read soft, friendly, safe (sidekicks, children, mascots); squares read stable, strong, stubborn (guards, fathers, robots); triangles read sharp, dynamic, dangerous (villains, tricksters, speedsters). Mix a dominant shape with a secondary one for nuance (round body, triangular ears = cute but mischievous). Apply the same shape family to the head, torso, hands, costume motifs and even the font of the name. Contrast characters within a cast by assigning different dominant shapes and sizes so they read apart at a glance. Negative example: every character built on the same oval head and rectangular body looks like one person in different clothes.

## Silhouette and proportion

The silhouette test: fill the character black; it must still be identifiable and its pose readable. Push one or two features (hat brim, hair mass, weapon, cape) so the outline is unique; keep the rest quiet. Avoid symmetry in pose; use line of action (one sweeping C or S curve through the body). Proportion sets genre: 2-3 heads chibi, 4-6 cartoon, 7.5-8 realistic, 9+ heroic. Vary head-to-body ratio across the cast. Big-medium-small: give every design one large mass, one medium, and small details so the eye has a hierarchy. Weight and balance: the centre of gravity must sit over the supporting foot or the figure looks like it is falling (unless that is the point). Hands and feet slightly oversized read better at small scale.

## Color script and costume

Limit each character to 3-4 colors: a dominant (60%), secondary (30%), accent (10%) placed at the face or focal prop. Pick a signature hue no other cast member owns. Values matter more than hues: the character must separate from typical backgrounds (dark character on light sets and vice versa). Costume tells story: era, class, job, climate, wear and tear. Repeat one motif (a stripe, a symbol) across costume pieces. Materials need distinct rendering cues: leather (soft specular), metal (hard specular, reflections), cloth (matte folds). Design for the medium: animation and games need fewer seams and no tiny patterns that shimmer; print can hold detail. Keep hair and clothing shapes as simplified masses, then add a few strands or folds.

## Turnarounds and sheets

A model sheet includes: front, 3/4, side, back views on a shared horizontal guide (eye line, chin, shoulders, waist, knees, ground) so heights match; a scale comparison with other cast members; an expression sheet (neutral, happy, angry, sad, surprised, plus two character-specific faces); a pose sheet showing attitude; hand and prop close-ups; a color callout with hex values. The 3/4 view is the hero view and should be designed first. Check that features visible from the front appear in the side view at the same height. For AI pipelines, generate the 3/4 view, lock it as the reference, then produce other views with image-reference nodes (IPAdapter, InstantID, FLUX.2 multi-reference) and the same seed and prompt skeleton.

## Consistency across images

Write a character bible paragraph that is pasted verbatim into every prompt: name-free physical description (age, build, skin, hair color and shape, eye color, distinctive feature), costume with colors, and style line. Order it the same way every time. Change only the pose/scene clause. Use reference images for identity and a fixed seed for exploration; vary the seed only after the description is stable. Train a small LoRA (20-40 curated images, varied poses, consistent tags) when a character recurs across a project. Audit for drift: eye color, hair part direction, number of accessories, and costume color are the first things to slip. Reference: [Character Design References](https://characterdesignreferences.com/) and [Stephen Silver, Passion for Life (course notes)](https://www.silverdrawingacademy.com/).
