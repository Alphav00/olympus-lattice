---
slug: color-theory
routing_description: Retrieve for color wheel harmonies, temperature, value, saturation, palette building, OKLCH color spaces, or WCAG contrast ratios.
built: 2026-10-28
protocol: kb-v1
tags: [art, color, palette, oklch, wcag, contrast, design]
---

# Color Theory

## Wheel, attributes, mixing

Three attributes: hue (position on the wheel), value (lightness), saturation/chroma (purity). The painter's wheel uses primaries red, yellow, blue; print uses CMY(K) subtractive; screens use RGB additive, where mixing all primaries gives white. Complementary pairs sit opposite (red-green, blue-orange, yellow-violet); mixed, they neutralize to grey, which is how painters desaturate without black. Tint = plus white, shade = plus black, tone = plus grey. Local color is the object's own color; perceived color shifts with light and surroundings (simultaneous contrast: a grey looks warm next to blue). Most believable palettes keep one dominant hue family, one accent, and neutrals that lean toward the dominant.

## Harmonies

| Harmony | Wheel relation | Character |
|---|---|---|
| Monochromatic | one hue, varied value/sat | unified, calm; needs value range |
| Analogous | 3 neighbours (30 deg apart) | natural, harmonious |
| Complementary | opposites | maximum contrast, vibrating edges |
| Split-complementary | hue + the two beside its opposite | contrast with less tension |
| Triadic | 3 at 120 deg | playful, cartoon; mute two |
| Tetradic / rectangle | 2 complementary pairs | rich; pick one dominant |
| Achromatic | black, white, grey plus one accent | editorial, UI |

60-30-10 rule: dominant 60% of the area, secondary 30%, accent 10%. Push harmony by shifting shadows toward one hue and highlights toward its complement (warm light, cool shadow or vice versa).

## Temperature and value

Warm hues (red, orange, yellow) advance; cool (blue, green, violet) recede, so depth can be painted with temperature alone. Every hue has warm and cool versions (cadmium red vs alizarin). Light source temperature decides the key: sunlight warm with cool sky-fill shadows; overcast cool and low contrast; tungsten orange; fluorescent green; moonlight is actually warm-grey but is painted blue by convention. Value does the structural work: a composition that reads in greyscale works in any palette. Plan 3-5 values, assign each hue a value range, and keep saturation highest at the focal point and in mid-values (very light and very dark colors cannot hold chroma). Negative example: pure black shadows kill form; use a dark complement instead.

## OKLCH and digital color

sRGB hex is device-oriented and perceptually uneven: #00FF00 looks far brighter than #0000FF at the same numeric value. OKLCH (lightness 0-1, chroma 0-0.4, hue 0-360) is perceptually uniform, so equal L steps look equal and hue stays constant while you change chroma. Build palettes by fixing L steps (e.g. 0.98, 0.92, 0.80, 0.65, 0.50, 0.35, 0.22) and holding hue; clamp chroma to the sRGB gamut or use `color(display-p3 ...)` for wide-gamut screens. CSS: `oklch(0.65 0.15 250)`; `color-mix(in oklch, a, b)` avoids muddy midpoints. Dark mode: lower L of surfaces, reduce chroma slightly, and keep accent L near 0.7-0.8 for legibility. Reference: [CSS Color Level 4, OKLCH](https://www.w3.org/TR/css-color-4/#ok-lab) and [Evil Martians OKLCH explainer](https://evilmartians.com/chronicles/oklch-in-css-why-quit-rgb-hsl).

## WCAG contrast

Contrast ratio = (L1 + 0.05) / (L2 + 0.05) using relative luminance, from 1:1 to 21:1.

| Requirement | Ratio |
|---|---|
| Body text, AA | 4.5:1 |
| Large text (18 pt / 14 pt bold), AA | 3:1 |
| UI components and graphics, AA (1.4.11) | 3:1 |
| Body text, AAA | 7:1 |
| Large text, AAA | 4.5:1 |

Approximate anchors on white: #767676 is 4.54:1 (the lightest AA grey), #595959 is 7:1. Pure hue accents (orange, yellow, light green) rarely pass on white; darken or use them on dark surfaces. Never rely on color alone to convey state; add icon, text or pattern. APCA (used in WCAG 3 drafts) scores by Lc and favors dark-on-light differently; check both when in doubt. Reference: [WCAG 2.2 1.4.3](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html).
