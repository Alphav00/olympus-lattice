---
slug: svg-and-vector-craft
routing_description: Retrieve for SVG authoring: paths, strokes, viewBox and scaling, optimization, accessibility, animation, and when vector beats raster.
built: 2026-10-28
protocol: kb-v1
tags: [art, svg, vector, paths, optimization, web]
---

# SVG and Vector Craft

## When SVG beats raster

Use SVG for logos, icons, diagrams, charts, UI illustration, type-as-shape, and anything that must scale or be recolored by CSS. Use raster (PNG, WebP, AVIF, JPEG) for photos, painterly textures, noise and gradients with thousands of nodes, and generated images. A rule: if the artwork has more than about 2,000 path nodes or any photographic region, export raster; if it has flat fills, few gradients and needs crisp edges at any DPI, use SVG. SVG inlined in HTML can be styled and animated; as `<img>` it is cached but isolated. For icon sets, inline a `<symbol>` sprite and reference with `<use href="#id">`.

## Coordinate system and viewBox

`viewBox="minX minY width height"` defines the drawing's own units; `width`/`height` attributes (or CSS) set the display size; `preserveAspectRatio` (default `xMidYMid meet`) controls fitting. Omit width/height and set `viewBox` for a fluid SVG that scales with its container. Nested coordinate systems come from `<svg>`, `<symbol>` and `transform`. Transform order matters: `transform="translate(10 20) rotate(45)"` rotates about the new origin. Use `transform-origin` (CSS) or translate-rotate-translate for spinning around a centre. Keep artwork on integer or half-integer coordinates and stroke widths that align to the device pixel to avoid blurry hairlines (`shape-rendering="crispEdges"` for axis-aligned charts).

## Paths and strokes

Path data commands: `M` move, `L` line, `H`/`V` axis lines, `C` cubic Bezier (two control points), `S` smooth cubic, `Q` quadratic, `T` smooth quadratic, `A` arc (rx ry rotation large-arc sweep x y), `Z` close. Lowercase = relative. Build organic shapes with cubics; keep handles tangent across joins for smooth curves. Fill rules: `nonzero` default, `evenodd` for cut-outs. Strokes: `stroke-width`, `stroke-linecap` (butt, round, square), `stroke-linejoin` (miter, round, bevel), `stroke-dasharray`/`stroke-dashoffset` (animate for a draw-on effect), `vector-effect="non-scaling-stroke"` to hold line weight under scaling. `paint-order="stroke fill"` puts the stroke behind the fill for outlined text. Prefer `<path>` over many `<rect>`/`<circle>` when exporting; convert text to paths only when the font cannot ship.

## Color, gradients, reuse

Set `fill="currentColor"` on icons so they inherit text color and theme. Define gradients, patterns, clip paths, masks and filters once in `<defs>` and reference by `url(#id)`; ids must be unique per page, so prefix them when inlining several SVGs. `<linearGradient>` and `<radialGradient>` with `gradientUnits="userSpaceOnUse"` keep stops stable across differently sized shapes. `<clipPath>` cuts hard, `<mask>` uses luminance for soft edges. Filters (`feGaussianBlur`, `feDropShadow`, `feTurbulence` + `feDisplacementMap` for grain or wobble) are powerful but costly; limit to a few elements. CSS variables work inside inline SVG for theming (`fill: var(--accent)`).

## Optimization and accessibility

Run [SVGO](https://github.com/svg/svgo) (`npx svgo icon.svg`) to strip editor metadata, round coordinates (precision 2-3), merge paths and collapse groups; typical savings 30-70%. Expected: a smaller file with identical rendering; failure mode: `removeViewBox` enabled breaks fluid scaling, so disable it. Keep `xmlns` for standalone files. Accessibility: `<title>` as the first child plus `role="img"` and `aria-labelledby`; decorative icons get `aria-hidden="true"`. Avoid `<text>` in logos that must render identically everywhere (fonts may be missing). Validate with the browser devtools and an SVG viewer; Illustrator and Figma exports differ in default precision and clip-path wrapping. Reference: [MDN SVG tutorial](https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial).

## Animation

CSS can animate transform, opacity, fill and stroke properties of inline SVG elements; use `transform-box: fill-box` to rotate about an element's own centre. SMIL (`<animate>`, `<animateTransform>`, `<animateMotion>`) works in all modern browsers for self-contained files. For complex timelines use GSAP or the Web Animations API; for Lottie, export from After Effects via Bodymovin. Draw-on effect: set `stroke-dasharray` to the path length (`getTotalLength()`) and animate `stroke-dashoffset` to 0. Respect `prefers-reduced-motion`.
