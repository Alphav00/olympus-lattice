---
slug: perspective-and-form
routing_description: Retrieve for linear perspective (1/2/3-point), horizon and eye level, foreshortening, constructing forms in space, camera lens and focal length effects, or fixing drawings that look flat or warped.
built: 2026-10-28
protocol: kb-v1
tags: [art, perspective, form, drawing, lens, focal-length, 3d]
---

# Perspective and Form

## Horizon, eye level, vanishing points

The horizon line is the viewer's eye level, not the visible skyline. Parallel lines receding from the viewer converge at a vanishing point (VP) on the horizon; vertical lines stay vertical unless the camera tilts. Everything above eye level shows its underside; everything below shows its top. Objects of the same height as the viewer have their eye-line crossing the horizon regardless of distance, which is how you size a crowd. Cone of vision is about 60 degrees; VPs placed too close to each other cause fisheye distortion at the edges. Station point = where the viewer stands; moving it changes convergence, moving the picture plane only changes scale.

## One, two, three point

| System | VPs | When |
|---|---|---|
| One-point | 1 on horizon | looking straight down a street, hallway, room facing a wall |
| Two-point | 2 on horizon | object seen from a corner; most exterior scenes |
| Three-point | 2 on horizon + 1 above or below | looking up at towers or down from height; verticals converge |
| Five-point / curvilinear | 4 on a circle + centre | fisheye, 180 degree views |
| Isometric / axonometric | none, parallel lines | games, technical, diagrams; 30 degree axes, no foreshortening |

Measuring tricks: diagonals of a rectangle locate its centre for equal division in depth; a measuring line along the picture plane transfers true lengths; the X method extends repeating units (fence posts, windows) in perspective. Ellipses: a circle in perspective is an ellipse whose minor axis aligns with the cylinder's axis; the degree opens as it moves from eye level.

## Form construction

Build from primitives: box, cylinder, sphere, cone; wrap organic subjects around them (head = sphere plus jaw box; torso = two boxes or a bean; limbs = tapered cylinders). Draw through: sketch hidden edges to keep volumes consistent. Cross-contour lines describe surface curvature. Overlap is the strongest depth cue, then scale change, then convergence, then atmospheric fade, then detail density. Foreshortening compresses the length of a form pointed at the viewer while its cross-section stays full size: a pointing arm becomes a large hand, a short upper arm, and the shoulder behind it. Check with the "T" rule (the nearer form's contour crosses the farther one) and keep ellipse degrees consistent along a limb.

## Figure proportion quick reference

Idealized adult = 7.5-8 heads tall; shoulders 2-3 heads wide; elbow at the waist, wrist at the crotch; hand = face length; foot = forearm length. Eyes at the vertical centre of the head; eye-width spacing between eyes; ear from brow to nose base. Children: larger head ratio (toddler about 4 heads, 10-year-old about 6). Stylized ranges: chibi 2-3 heads, heroic 8.5-9 heads. When in doubt, measure in heads and compare to a reference. Reference: [Andrew Loomis, Figure Drawing for All It's Worth (archive)](https://archive.org/details/figure-drawing-for-all-its-worth).

## Camera and lens language

Focal length changes perspective compression, not just field of view, when the subject is reframed to the same size.

| Lens (full frame) | Effect | Use |
|---|---|---|
| 14-24 mm | wide, exaggerated depth, converging verticals | architecture, dramatic interiors |
| 35 mm | natural street view, mild expansion | environmental portraits, documentary |
| 50 mm | near human perspective | general, product |
| 85-135 mm | flattering compression, shallow DOF | portraits |
| 200-400 mm | flat, stacked planes, compressed distance | wildlife, sports, cinematic long shots |


## Aperture and camera height

Aperture: f/1.4-f/2.8 shallow depth of field and bokeh; f/8-f/11 landscape sharpness; f/16+ diffraction softening. Camera height: low angle makes subjects heroic; high angle diminishes; eye level is neutral. Dutch tilt unsettles. These words steer image generators reliably because they appear in photo captions: "35mm, f/2, eye level" or "telephoto compression, low angle". Reference: [Cambridge in Colour, focal length and perspective](https://www.cambridgeincolour.com/tutorials/camera-lenses.htm).
