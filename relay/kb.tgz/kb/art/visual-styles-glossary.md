---
slug: visual-styles-glossary
routing_description: Retrieve when a visual style, medium or rendering look is named and you need its defining traits and descriptor words for prompts or critique.
built: 2026-10-28
protocol: kb-v1
tags: [art, styles, media, glossary, prompts, descriptors]
---

# Visual Styles Glossary

Each row: defining traits, then three descriptor words that steer generators and briefs.

## Traditional media

| Style / medium | Defining traits | Descriptors |
|---|---|---|
| Oil painting | layered glazes, visible brushwork, rich darks | impasto, glazed, painterly |
| Watercolor | transparent washes, white paper as light, blooms | wet-on-wet, granulating, luminous |
| Gouache | opaque matte flat color, crisp edges | matte, flat, poster-like |
| Acrylic | fast, bright, hard edges or thick texture | vivid, graphic, textured |
| Charcoal | soft blacks, smudged tone, paper grain | smoky, tonal, gestural |
| Graphite / pencil | fine hatching, grey range, precise | hatched, delicate, academic |
| Ink line | confident contour, hatching, no tone | inked, crosshatched, calligraphic |
| Ink wash / sumi-e | few strokes, grey gradations, empty space | minimal, brushy, zen |

## Print and graphic

| Style / medium | Defining traits | Descriptors |
|---|---|---|
| Woodcut / linocut | bold carved lines, white-on-black, texture | carved, bold, high-contrast |
| Etching / engraving | fine parallel lines, dense crosshatch | engraved, intricate, antique |
| Screen print | flat spot colors, slight misregistration | flat, layered, halftone |
| Risograph | grainy, limited fluorescent inks, overprint | grainy, overprinted, zine |
| Collage | cut paper, mixed sources, visible edges | cut-out, layered, mixed-media |
| Halftone / comic print | Ben-Day dots, black keyline, CMYK | dotted, pulp, inked |
| Flat vector illustration | geometric shapes, no outlines, limited gradients | flat, geometric, clean |
| Isometric illustration | 30 degree axes, no perspective, tidy | isometric, diagrammatic, toy-like |

## Illustration and animation

| Style / medium | Defining traits | Descriptors |
|---|---|---|
| Anime | large eyes, cel shading, speed lines, sharp hair | cel-shaded, clean, dynamic |
| Ghibli-type painterly anime | soft painted backgrounds, warm light, hand-drawn | painterly, nostalgic, pastoral |
| Western cartoon | thick outlines, rubber-hose or angular | bold-outline, exaggerated, flat |
| Disney/Pixar 3D | appealing stylized proportions, subsurface skin, soft GI | stylized-3D, appealing, polished |
| Children's book | textured media, friendly shapes, gentle palette | whimsical, textured, warm |
| Comic book (US) | inked, dynamic poses, flat color with rendering | heroic, inked, dramatic |
| Manga B&W | screentone, speed lines, expressive line weight | screentoned, kinetic, monochrome |
| Pixel art | hard pixels, limited palette, dithering | 8-bit, dithered, retro |

## Photo and render looks

| Style / medium | Defining traits | Descriptors |
|---|---|---|
| Photorealism | correct optics, skin pores, lens artifacts | photographic, 35mm, raw |
| Cinematic | anamorphic ratio, teal-orange, haze, motivated light | anamorphic, moody, graded |
| Film noir | hard low-key, venetian shadows, B&W | high-contrast, shadowy, monochrome |
| Polaroid / lo-fi | faded, light leaks, soft, white frame | faded, grainy, nostalgic |
| Octane / Redshift CGI | glossy materials, HDRI, perfect caustics | glossy, rendered, hyperreal |
| Claymation / stop motion | fingerprints, matte clay, slight jitter | handmade, tactile, clay |
| Glitch / datamosh | RGB splits, scan lines, compression blocks | glitched, corrupted, digital |
| Vaporwave | pastel pink-teal, Roman busts, grids, Windows 95 | pastel, retro-futurist, surreal |

## Design idioms

| Style / medium | Defining traits | Descriptors |
|---|---|---|
| Swiss / International | grid, Helvetica, asymmetric, white space | gridded, objective, sans-serif |
| Brutalist web | raw HTML look, default type, harsh blocks | raw, unstyled, stark |
| Memphis | squiggles, confetti, pastel plus black | playful, postmodern, patterned |
| Art Deco | symmetry, fans, gold and black | geometric, gilded, streamlined |
| Cyberpunk | neon on wet dark streets, holograms, kanji signs | neon, dystopian, rain-slick |
| Dark fantasy | desaturated, grime, dramatic scale | grim, textured, epic |
| Minimalism | few elements, large negative space | sparse, quiet, essential |
| Maximalism | dense pattern, clashing color, ornament | dense, ornate, saturated |
## Usage

Use one style row plus one lighting phrase and one composition phrase per prompt; stacking many styles averages them out. Reference: [Tate Art Terms](https://www.tate.org.uk/art/art-terms).
