---
slug: art-history-timeline
routing_description: Retrieve when an art movement, period or artist era is named and its dates, defining traits or key figures are needed, including for style prompts.
built: 2026-10-28
protocol: kb-v1
tags: [art, history, movements, timeline, styles]
---

# Art History Timeline

One line per movement: dates, traits, key figures. Dates are approximate.

## Ancient to medieval

| Movement | Dates | Traits | Figures |
|---|---|---|---|
| Egyptian | 3000-300 BCE | profile figures, hierarchical scale, flat color, registers | anonymous workshops |
| Greek Classical | 480-323 BCE | idealized anatomy, contrapposto, proportion canon | Phidias, Polykleitos |
| Roman | 100 BCE-400 CE | realism in portraiture, fresco, mosaic, engineering scale | unknown; Pompeii frescoes |
| Byzantine | 500-1450 | gold ground icons, frontal saints, flat, symbolic | Hagia Sophia mosaics |
| Romanesque | 1000-1200 | heavy stone, rounded arches, stylized relief | Gislebertus |
| Gothic | 1150-1400 | pointed arches, stained glass, verticality, elongated figures | Giotto (proto-Renaissance) |

## Renaissance to Rococo

| Movement | Dates | Traits | Figures |
|---|---|---|---|
| Early Renaissance | 1400-1490 | linear perspective, naturalism, classical revival | Masaccio, Botticelli, Donatello |
| High Renaissance | 1490-1527 | balance, sfumato, ideal composition | Leonardo, Michelangelo, Raphael |
| Northern Renaissance | 1430-1570 | oil detail, symbolism, domestic realism | van Eyck, Durer, Bruegel |
| Mannerism | 1520-1600 | elongated figures, unstable poses, acid color | Parmigianino, El Greco |
| Baroque | 1600-1750 | drama, chiaroscuro, diagonals, movement | Caravaggio, Rembrandt, Rubens, Bernini |
| Dutch Golden Age | 1600-1680 | genre scenes, still life, light studies | Vermeer, Hals |
| Rococo | 1720-1780 | pastel, ornament, playful aristocratic scenes | Fragonard, Boucher, Watteau |

## 18th-19th century

| Movement | Dates | Traits | Figures |
|---|---|---|---|
| Neoclassicism | 1760-1830 | order, clear line, antique subjects, moral tone | David, Ingres, Canova |
| Romanticism | 1800-1850 | emotion, sublime nature, exotic drama | Delacroix, Turner, Friedrich, Goya |
| Realism | 1840-1880 | everyday labor, unidealized, social subjects | Courbet, Millet, Daumier |
| Pre-Raphaelites | 1848-1890 | medieval themes, jewel color, detail | Rossetti, Millais, Waterhouse |
| Impressionism | 1865-1890 | broken color, plein air, light and moment | Monet, Renoir, Degas, Morisot |
| Post-Impressionism | 1885-1910 | structure, symbolic color, expressive form | Van Gogh, Cezanne, Gauguin, Seurat |
| Symbolism | 1880-1910 | dream, myth, mood over realism | Moreau, Redon, Klimt |
| Art Nouveau | 1890-1910 | organic curves, whiplash lines, decorative unity | Mucha, Gaudi, Beardsley |

## Early 20th century

| Movement | Dates | Traits | Figures |
|---|---|---|---|
| Fauvism | 1905-1910 | wild non-local color, flat shapes | Matisse, Derain |
| Expressionism | 1905-1925 | distortion, angst, woodcut edge | Munch, Kirchner, Schiele |
| Cubism | 1907-1920 | fractured planes, multiple viewpoints, muted palette | Picasso, Braque, Gris |
| Futurism | 1909-1918 | speed, machines, motion lines | Boccioni, Balla |
| Dada | 1916-1924 | absurdity, readymades, collage, anti-art | Duchamp, Hoch, Schwitters |

## Interwar design movements

| Movement | Dates | Traits | Figures |
|---|---|---|---|
| Constructivism | 1915-1930 | geometric, red/black, propaganda graphics | Rodchenko, Lissitzky, Tatlin |
| De Stijl | 1917-1931 | primary colors, right angles, grid | Mondrian, van Doesburg |
| Bauhaus | 1919-1933 | function, geometry, sans-serif type, craft plus industry | Gropius, Kandinsky, Klee, Albers |
| Surrealism | 1924-1950 | dream logic, uncanny juxtaposition, hyperreal rendering | Dali, Magritte, Ernst, Kahlo |
| Art Deco | 1920-1940 | streamlined geometry, gold, sunbursts, luxury | Erte, Cassandre, Lempicka |

## Postwar to contemporary

| Movement | Dates | Traits | Figures |
|---|---|---|---|
| Abstract Expressionism | 1943-1960 | gesture, scale, drip, color field | Pollock, Rothko, de Kooning, Krasner |
| Pop Art | 1955-1970 | mass media, Ben-Day dots, commercial color | Warhol, Lichtenstein, Hamilton |
| Minimalism | 1960-1975 | reduction, industrial materials, repetition | Judd, Martin, LeWitt |
| Op Art | 1960-1970 | optical vibration, moire, high contrast | Riley, Vasarely |
| Conceptual | 1965-1980 | idea over object, text, documentation | Kosuth, Weiner, Ono |
| Photorealism | 1968-1985 | camera-like precision, chrome and reflections | Estes, Close |

## 1978 to present

| Movement | Dates | Traits | Figures |
|---|---|---|---|
| Street Art | 1980-present | stencil, wheatpaste, murals, public space | Haring, Basquiat, Banksy |
| Neo-Expressionism | 1978-1990 | raw figuration, large canvases | Baselitz, Kiefer, Schnabel |
| Digital / New Media | 1990-present | code, generative, installation, AI | Reas, Anadol, Ikeda |
| Lowbrow / Pop Surrealism | 1990-present | cartoon figures, glossy finish, dark whimsy | Mark Ryden, Camille Rose Garcia |

## Using the timeline in prompts

Name the movement plus two traits rather than an artist name: "Art Nouveau poster, whiplash curves, flat jewel tones" transfers to any generator and avoids living-artist style mimicry. Pair a movement with a medium ("Bauhaus, risograph") for hybrids. Reference: [The Met Heilbrunn Timeline of Art History](https://www.metmuseum.org/toah/) and [Tate Art Terms](https://www.tate.org.uk/art/art-terms).
