---
slug: comfyui-image-nodes
routing_description: Retrieve when choosing or wiring ComfyUI image nodes: FaceDetailer, ControlNet preprocessors, IPAdapter, InstantID, upscalers, KJNodes, and when each applies.
built: 2026-10-28
protocol: kb-v1
tags: [art, comfyui, nodes, controlnet, ipadapter, instantid, upscale, impact-pack]
---

# ComfyUI Image Nodes

## Core graph

`CheckpointLoaderSimple` (or `UNETLoader` + `DualCLIPLoader`/`CLIPLoader` + `VAELoader` for FLUX and Qwen) -> `CLIPTextEncode` x2 (Qwen edit uses `TextEncodeQwenImageEdit` / `TextEncodeQwenImageEditPlus` with reference images) -> `EmptyLatentImage` (or `EmptySD3LatentImage` for FLUX/Qwen) -> `KSampler` or `SamplerCustomAdvanced` (`BasicGuider`, `FluxGuidance`, `ModelSamplingFlux`/`ModelSamplingAuraFlow` shift) -> `VAEDecode` -> `SaveImage`. Img2img: `LoadImage` -> `VAEEncode` -> sampler latent with denoise 0.3-0.7. Inpaint: `VAEEncodeForInpaint` or `SetLatentNoiseMask` with a mask from `LoadImage`. FLUX.2 models load as diffusion model + `mistral_3_small_flux2_bf16` text encoder + `flux2-vae` per [ComfyUI docs](https://github.com/Comfy-Org/docs/pull/596/files).

## Impact Pack: FaceDetailer and detailers

`FaceDetailer` (ComfyUI-Impact-Pack) finds faces with an `UltralyticsDetectorProvider` bbox model (`face_yolov8m.pt`), crops, upsamples, re-samples each crop with your model and prompt, and pastes back. Key inputs: `guide_size` (crop upscale target, 512-1024), `denoise` 0.3-0.5 (higher changes identity), `feather`, `bbox_threshold`, optional `SAMLoader` for tighter masks. Use after the main generation and before upscaling; add a second pass with a hand detector for hands. `DetailerForEach` does the same for any detector (eyes, hands, logos). `SEGS` is the pack's segment type; `SEGSPreview` shows what will be refined. Failure: a face LoRA with high strength plus FaceDetailer denoise 0.6 overwrites the original face; lower one of them. Repo: [ComfyUI-Impact-Pack](https://github.com/ltdrdata/ComfyUI-Impact-Pack).

## ControlNet and preprocessors

`comfyui_controlnet_aux` supplies preprocessors; pair each with the matching ControlNet model via `ControlNetLoader` + `ControlNetApplyAdvanced` (strength 0.5-1.0, start/end percent 0-0.8).

| Goal | Preprocessor | Notes |
|---|---|---|
| Keep pose | `DWPose` / `OpenPose` | body + hands + face points |
| Keep depth and layout | `DepthAnything V2`, `Zoe`, `MiDaS` | soft structure, allows restyling |
| Keep edges | `Canny`, `HED`, `PiDiNet`, `Lineart` | strict; lower strength for freedom |
| Keep surface normals | `NormalMap BAE` | lighting-aware form |
| Keep segmentation | `OneFormer`, `SAM` | region layout |
| Tile / detail | `Tile` | upscaling and detail refine |

FLUX uses union/Pro ControlNets (one model, mode selector); SDXL uses per-type models. Repo: [comfyui_controlnet_aux](https://github.com/Fannovel16/comfyui_controlnet_aux).

## IPAdapter, InstantID, references

`ComfyUI_IPAdapter_plus`: `IPAdapterUnifiedLoader` (presets PLUS, PLUS FACE, FACEID) + `IPAdapter Advanced` (weight 0.5-0.8, `weight_type` style/composition, start/end). Use for style transfer from a reference image or for soft identity without training. `ComfyUI_InstantID` (SDXL only): `InstantIDModelLoader` + `InstantIDFaceAnalysis` (insightface) + `ApplyInstantID` with a face image and an optional pose image; stronger identity than IPAdapter FaceID, weight 0.6-0.8, pairs with a Canny or depth ControlNet for pose. PuLID is the FLUX-era equivalent (`PuLIDFluxModelLoader`). FLUX.2 and Qwen-Image-Edit take reference images natively (`ReferenceLatent`, `TextEncodeQwenImageEditPlus`), so try the native path before adapters. Repos: [IPAdapter_plus](https://github.com/cubiq/ComfyUI_IPAdapter_plus), [InstantID](https://github.com/cubiq/ComfyUI_InstantID).

## Upscalers

| Method | Nodes | When |
|---|---|---|
| Model upscale | `UpscaleModelLoader` + `ImageUpscaleWithModel` (4x-UltraSharp, RealESRGAN, SwinIR, 4x_NMKD-Siax) | fast, faithful, no new detail |
| Latent upscale + resample | `LatentUpscaleBy` + second `KSampler` denoise 0.3-0.5 | adds detail, can hallucinate |
| Tiled refine | `UltimateSDUpscale` (tile 1024, denoise 0.2-0.35, optional Tile ControlNet) | large prints, consistent detail |
| SUPIR / CCSR | custom packs | photo restoration |

Order: generate at native size, FaceDetailer, then upscale 2x, optional second detail pass. Downscale with `ImageScale` lanczos for delivery.

## KJNodes and utilities

ComfyUI-KJNodes: `ImageResizeKJ` (resize to multiples of 16/64 with keep-proportion), `GetImageSizeAndCount`, `ImageBatchMulti` and `ImageConcanate`, `ColorMatch` (match a reference's color grade), `Set/Get` nodes for clean graphs, `CreateFadeMask`/`GrowMaskWithBlur` for inpaint feathering, `FastPreview`. Other staples: rgthree `Context`/`Power Lora Loader`, `WAS Node Suite` text ops, `ComfyUI-Easy-Use` for compact loaders. Keep one custom-node pack per job; overlapping packs cause import-name collisions. Repo: [ComfyUI-KJNodes](https://github.com/kijai/ComfyUI-KJNodes).
