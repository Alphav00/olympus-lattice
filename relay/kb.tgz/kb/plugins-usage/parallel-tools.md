---
slug: parallel-tools
routing_description: Retrieve when 2+ independent tool calls should run at once instead of OWUI's sequential execution.
built: 2026-10-28
protocol: kb-v1
tags: [owui, tool, parallel, concurrency, skyzi000]
---

## What it does

Batches independent tool calls and runs them concurrently with `asyncio.gather`. OWUI executes tool calls one by one, even when the model emits several at once; this tool is the workaround. It can dispatch regular tools, MCP/tool-server tools, Core subagent tools and Open Terminal tools that are enabled in the chat, honouring OWUI access checks. v0.2.9 by skyzi000.

## Installed as

- OWUI id: `parallel_tools` (type: tool)
- Enabled: yes; attach per chat via the tools (+) menu
- Verdict: ok — no network of its own, reads Chats only

## How to invoke

User phrasing: "Search the web for A, B and C in parallel and merge the results."

Model call: `run_tools_parallel(tool_calls)` where `tool_calls` is a list of `{"name": "<tool_name>", "args": {...}}` objects (a JSON string of that list is also accepted), e.g. `[{"name": "search_web", "args": {"query": "Python"}}]`, for tools already enabled in the chat. Use it whenever 2+ calls do not depend on each other; call tools directly when there is only one or when results chain.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `AVAILABLE_TOOL_IDS` | `` | leave empty: uses tools enabled in the chat UI |
| `EXCLUDED_TOOL_IDS` | `` | optional; not a security boundary |
| `ENABLE_SUBAGENT_TOOLS` | True | off unless Core delegate_task/timer are wanted inside batches |
| `ENABLE_TERMINAL_TOOLS` | True | off unless a terminal is wired |
| `DEBUG` | False | on only while debugging |

## Gotchas

- Needs Native Function Calling on the model; the frontmatter says only high-capability models (GPT-5.2, Claude Opus class) reliably pass the nested `tool_calls` list. MiniMax-M3 tool-call formatting is a known caveat: expect malformed batches on small models.
- The tools inside the batch must be enabled in the same chat; it cannot reach tools that are not attached.
- Uses private OWUI internals (requires 0.7.0+); may break on upgrades.
- Combine with `sub_agent`: parallel sub-agents already exist there (`run_parallel_sub_agents`), so pick one.

## Source

https://raw.githubusercontent.com/Skyzi000/open-webui-extensions/main/tools/parallel_tools.py
