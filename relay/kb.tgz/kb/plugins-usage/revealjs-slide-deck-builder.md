---
slug: revealjs-slide-deck-builder
routing_description: Retrieve when a user asks for a presentation, slide deck or visual summary rendered live in the chat.
built: 2026-10-28
protocol: kb-v1
tags: [owui, tool, slides, revealjs, rich-ui, embed, g30]
---

## What it does

Tool that returns a self-contained Reveal.js 5.0.4 page as a Rich UI embed (FastAPI `HTMLResponse`). The model supplies a title, a list of per-slide HTML strings and a theme; each string is wrapped in a `<section>` and the deck renders in OWUI's sandboxed iframe with reveal.js CSS/JS pulled from cdnjs by the browser. 112 lines, no server network, no DB. v1.0.0 by g30, needs OWUI 0.9.0.

## Installed as

- OWUI id: `revealjs_deck_builder` (type: tool)
- Enabled: yes; attach per chat via the tools (+) menu or pin to a presenter model
- Verdict: ok — model HTML is injected unescaped but only inside the sandboxed embed

## How to invoke

User phrasing: "Make a 6-slide deck on X, dark theme." or "Turn this summary into slides."

Model call: `create_presentation(deck_title, slides_html, theme)` where `slides_html` is a list of strings, each one slide using `<h2>` title, `<ul><li>` bullets, `<p>` text (keep it short), and `theme` one of black, white, league, beige, night, blood, moon, dracula, solarized (invalid names fall back to dracula). Navigate with arrow keys or swipe; the embed can be opened fullscreen from the embed controls.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| none | — | the tool has no Valves or UserValves; theme is chosen per call |

## Gotchas

- Needs Native Function Calling; MiniMax-M3 tool-call caveat: lists of HTML strings with quotes inside are a common place for malformed JSON, so ask for simple markup.
- Does not require the Rich UI same-origin toggle; the embed is a plain sandboxed iframe. Fullscreen behaviour depends on OWUI's embed controls.
- The browser must reach cdnjs.cloudflare.com; offline or blocked CDN leaves an unstyled page.
- No export: to keep the deck, ask the model for the same slides as Markdown or use Export to Word on the reply.
- Slide HTML is unescaped: keep this tool off models that paste untrusted web content into slides.

## Source

https://openwebui.com/posts/revealjs_presentation_slide_deck_builder_rich_ui_59243191
