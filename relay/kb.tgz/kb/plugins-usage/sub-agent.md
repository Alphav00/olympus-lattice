---
slug: sub-agent
routing_description: Retrieve when a task needs 3+ tool steps, deep research, or the main chat context must stay clean — delegate to a sub-agent.
built: 2026-10-28
protocol: kb-v1
tags: [owui, tool, sub-agent, delegation, context, skyzi000]
---

## What it does

Runs tool-heavy work in an isolated sub-agent loop and returns only the final answer to the main chat. The sub-agent gets a fresh context (no chat history), the same tools the chat has enabled, and iterates up to `MAX_ITERATIONS` with automatic context compaction. Two tools: `run_sub_agent` (one task) and `run_parallel_sub_agents` (up to `MAX_PARALLEL_AGENTS` independent tasks at once). v0.6.6 by skyzi000, 9826 lines.

## Installed as

- OWUI id: `sub_agent` (type: tool)
- Enabled: yes; attach per chat via the tools (+) menu or pin to a workspace model
- Verdict: caution — spawns LLM loops that can call any tool the user has; no outbound traffic of its own

## How to invoke

User phrasing: "Delegate this to a sub-agent: research X, compare Y, return a table." or "Run three sub-agents in parallel on A, B, C."

Model call: `run_sub_agent(description, prompt)` — `description` is the short status text shown to the user (user's language); `prompt` must carry ALL context because the sub-agent cannot see the chat. `run_parallel_sub_agents(tasks)` takes `[{"description": ..., "prompt": ...}, ...]`. Docstring rule: tasks of 3+ investigation steps MUST be delegated; 1–2 tool calls stay in the main chat.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `DEFAULT_MODEL` | `` (same as chat) | leave empty, or a cheap local model for research swarms |
| `MAX_ITERATIONS` | 50 | keep; 0 = unlimited (avoid) |
| `EXCLUDED_TOOL_IDS` | `` | add `sub_agent` to block recursion |
| `ENABLE_SUBAGENT_TOOLS` | False | keep off (Core delegate_task bypasses these limits) |
| `ENABLE_SKILLS_WRITE_TOOLS` | False | keep off; it edits saved skills |
| `ENABLE_TERMINAL_TOOLS` | True | off unless a terminal is wired |
| `CONTEXT_COMPACTION_TOKEN_THRESHOLD` | 80000 | lower (e.g. 30000) for small-context local models |
| `LARGE_TOOL_RESULT_MODE` | ref_exec | keep |
| UserValve `SYSTEM_PROMPT` | built-in | per-user override of the sub-agent persona |

## Gotchas

- Requires Native Function Calling on the model (Model > Advanced Params > Function Calling: native). Default mode will not trigger it.
- MiniMax-M3 on bld-golden has a known tool-call formatting caveat; verify a single `run_sub_agent` works before parallel runs.
- The sub-agent cannot see the chat: forgetting to restate context is the usual failure.
- `ENABLE_*_TOOLS` can only disable builtin tools, never enable ones the admin or model config disabled.
- Deep use of private OWUI internals: expect breakage on OWUI upgrades (requires 0.9.6+).
- Outlet filters never run on sub-agent output; inlet filters do if `APPLY_INLET_FILTERS` is on.

## Source

https://raw.githubusercontent.com/Skyzi000/open-webui-extensions/main/tools/sub_agent.py
