---
slug: ask-user
routing_description: Retrieve when the model must ask the user clarifying questions (style, scope, audience) through one modal instead of guessing.
built: 2026-10-28
protocol: kb-v1
tags: [owui, tool, clarification, modal, ux, ichrist]
---

## What it does

Lets the model ask 1–5 clarifying questions in a single themed modal: choice cards, multi-select, "Other", free text, keyboard shortcuts, optional "Recommended" badge. Falls back to plain OWUI input dialogs if the custom modal cannot run. Pure client-side UI via `__event_call__ execute`; no network, DB or env. v2.1.0 by ichrist.

## Installed as

- OWUI id: `ask_user` (type: tool)
- Enabled: yes; attach per chat or pin to a model
- Verdict: ok

## How to invoke

User phrasing: "Ask me what you need before starting." Usually the model decides on its own when a request is vague.

Model call: `get_user_clarification(questions)` with a list of `{"question": str, "header": "Style", "options": ["A", {"label": "B", "description": "...", "recommended": true}]}`; omit `options` for free text. Ask everything in ONE call, only what cannot be inferred. The docstring says ALWAYS prefer this over the builtin `ask_user`.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `max_questions` | 5 | keep |
| `timeout_seconds` | 0 (wait forever) | consider 300 so unattended chats do not hang |
| `allow_skip` | True | keep |
| `fallback_to_input_dialogs` | True | keep; covers browsers where the modal JS fails |
| `accent_color` | #6366f1 | optional brand colour |
| UserValves `theme`, `position`, `width_px`, `font_scale`, `custom_css` | auto, center, 580, 1.0, `` | phone: `position=bottom`, `width_px=360`, `font_scale=1.1` |

## Gotchas

- Needs Native Function Calling for the model to emit the structured `questions` list; MiniMax-M3 may flatten nested option objects (tool-call caveat).
- The modal runs JS in the page context (inherent to the execute event); no same-origin toggle needed.
- One modal per call: a second call opens a second modal; batch questions.
- Timeout 0 blocks the turn until the user answers or closes the modal.

## Source

https://openwebui.com/posts/ask_user_14182520
