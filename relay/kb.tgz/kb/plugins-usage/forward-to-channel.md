---
slug: forward-to-channel
routing_description: Retrieve when a user wants to post a chat reply into an Open WebUI channel (team room, DM) from the message toolbar.
built: 2026-10-28
protocol: kb-v1
tags: [owui, action, channels, share, g30]
---

## What it does

Message action that posts the selected message into an OWUI channel the user is a member of. Dialog flow: pick a channel (or use a default), optionally type `@user` / `@"Model Name"` mentions which are converted to channel mention format (and can trigger model replies), then the message is written through OWUI's own channel router with optional chat title and timestamp. Reads Users/Chats; no external network. v0.1.6 by g30.

## Installed as

- OWUI id: `forward_to_channel` (type: action)
- Enabled: yes; toolbar button under assistant messages
- Verdict: ok — internal API only, version-fragile

## How to invoke

Tap "Forward to Channel" in the message toolbar. Choose the channel in the selection dialog, then add mentions in the next dialog (or leave empty). Set UserValve `default_channel_id` plus `skip_confirmation=True` to make it one tap, and `skip_mentions=True` to drop the second dialog. Channel ids come from the channel URL in OWUI. User-driven only; the model has no tool for it.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `default_channel_id` | `` | admin default channel (e.g. the Pantheon ops channel id) |
| `include_chat_title` | True | keep |
| `include_timestamp` | True | keep |
| `skip_confirmation` | False | keep off globally; users set their own |
| `skip_mentions` | False | on for phone one-tap forwarding |
| `debug` | False | off |
| UserValves (same six) | same | per-user: set `default_channel_id` for the personal log channel |

## Gotchas

- Only channels the user already belongs to appear; DMs are supported (`type == dm`).
- Mentions of a model name make that model answer inside the channel; use quotes for names with spaces.
- Deep coupling to `open_webui.routers.channels` internals: an OWUI upgrade can break it silently (requires 0.8.12+).
- Reasoning blocks are forwarded as-is; strip them manually if unwanted (Forward to Webhook has that option, this does not).

## Source

https://openwebui.com/posts/forward_to_channel_b60c1f03
