---
slug: export-to-excel
routing_description: Retrieve when a user wants the Markdown tables in a reply (or the whole chat) downloaded as a formatted .xlsx workbook.
built: 2026-10-28
protocol: kb-v1
tags: [owui, action, excel, xlsx, tables, export, fu-jie]
---

## What it does

Message action that extracts Markdown tables from the last message or the whole chat, writes one sheet per table with pandas, and formats them: dark header, zebra stripes, type-aware alignment (number/date/sequence/text), CJK-aware widths, bold/italic cell Markdown. Workbook and sheet names come from the nearest Markdown headings; otherwise `user_yyyymmdd.xlsx` and Sheet1.... The file is written to a temp path then pushed to the browser via `__event_call__`. v0.3.11 by Fu-Jie, needs OWUI 0.10.2.

## Installed as

- OWUI id: `export_to_excel` (type: action)
- Enabled: yes; toolbar button under assistant messages
- Verdict: ok — no network; writes/removes a temp file under `app/backend/data/temp/`

## How to invoke

Ask the model for a table first ("Give me the comparison as a Markdown table"), then tap "Export to Excel" in the message toolbar. The .xlsx downloads through the browser. `EXPORT_SCOPE=all_messages` exports every table in the chat into one workbook. A reply without tables shows "No tables found to export!". User-driven; the model cannot call it.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `TITLE_SOURCE` | chat_title | keep; `markdown_title` uses the first h1/h2, `ai_generated` costs a model call |
| `EXPORT_SCOPE` | last_message | keep; switch per need |
| `MODEL_ID` | `` | only for `ai_generated` titles; a cheap local model |
| `ROW_HEIGHT` / `COLUMN_WIDTH` | 0 (auto) | keep auto; set 20/15 for compact sheets |
| `SHOW_STATUS` | True | keep |
| `SHOW_DEBUG_LOG` | False | off |

No UserValves in this version.

## Gotchas

- Requirements line is absent: it imports pandas and needs openpyxl for the writer. Both ship in the OWUI image; if import fails, add `openpyxl` to the function's requirements.
- Temp path is RELATIVE (`app/backend/data/temp/`): it lands inside the container data tree only when the process CWD is `/`; harmless but check disk if exports pile up.
- Tables must be real GFM tables (header + `|---|` line); HTML tables are ignored.
- Sheet names are clamped to 31 chars and stripped of illegal characters.

## Source

https://raw.githubusercontent.com/Fu-Jie/openwebui-extensions/main/plugins/actions/export_to_excel/export_to_excel.py
