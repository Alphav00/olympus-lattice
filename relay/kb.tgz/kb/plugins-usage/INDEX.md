# plugins-usage — Open WebUI community plugin usage bank

Built 2026-10-28, protocol kb-v1. One file per installed plugin (19) plus `_overview.md`. Source of truth: the plugin `.py` frontmatter, Valves/UserValves and tool docstrings, plus `plugins/manifest.json` (ids, verdicts). Every file has the same sections: What it does · Installed as · How to invoke · Valves that matter · Gotchas · Source.

## Tools (model-invoked, need Native Function Calling)

| file | id | retrieve when |
|---|---|---|
| [sub-agent](sub-agent.md) | `sub_agent` | 3+ step research or tool-heavy work should leave the main context |
| [parallel-tools](parallel-tools.md) | `parallel_tools` | several independent tool calls should run at once |
| [mcp-app-bridge](mcp-app-bridge.md) | `mcp_app_bridge` | calling a remote MCP server or rendering an MCP App |
| [ask-user](ask-user.md) | `ask_user` | the model must ask clarifying questions in a modal |
| [revealjs-slide-deck-builder](revealjs-slide-deck-builder.md) | `revealjs_deck_builder` | a slide deck rendered live in chat |
| [ollama-model-card-generator](ollama-model-card-generator.md) | `ollama_model_card_generator` | admin bulk-edits Ollama model entries |

## Filters

| file | id | mode | retrieve when |
|---|---|---|---|
| [task-management-enforcer](task-management-enforcer.md) | `task_management_enforcer_filter` | toggle | forcing task breakdown |
| [vision-bridge](vision-bridge.md) | `vision2text` | toggle | image understanding for text-only models; image egress question |
| [markdown-normalizer](markdown-normalizer.md) | `markdown_normalizer` | global | output formatting fixes |
| [mermaid-doctor](mermaid-doctor.md) | `mermaid_doctor` | global | broken Mermaid diagrams |
| [token-usage-display](token-usage-display.md) | `token_usage_display` | global | the stats line under replies |
| [openrouter-balance-tracker](openrouter-balance-tracker.md) | `openrouter_tracker` | global | OpenRouter cost or credits |

## Pipe

| file | id | retrieve when |
|---|---|---|
| [tool-call-approval-gate](tool-call-approval-gate.md) | `human_in_the_loop` (DISABLED, needs LiteLLM endpoint) | human approval of every tool call |

## Actions (message-toolbar buttons)

| file | id | retrieve when |
|---|---|---|
| [export-to-word-enhanced](export-to-word-enhanced.md) | `export_to_docx` | reply to .docx |
| [export-to-excel](export-to-excel.md) | `export_to_excel` | tables to .xlsx |
| [download-code-blocks](download-code-blocks.md) | `download_code_blocks` | save code blocks as files |
| [forward-to-channel](forward-to-channel.md) | `forward_to_channel` | post reply into an OWUI channel |
| [forward-to-webhook](forward-to-webhook.md) | `forward_to_webhook` | push reply to Discord/Slack (Styx) |
| [add-web-sources-to-knowledge](add-web-sources-to-knowledge.md) | `add_web_sources_to_knowledge` | save web citations to a KB |

## Cross-cutting gotchas

- Tools need Native Function Calling (Model > Advanced Params > Function Calling: native); MiniMax-M3 has a known tool-call formatting caveat.
- Rich UI embeds (reveal.js, MCP apps) do not need the same-origin iframe toggle.
- Only `export_to_docx` declares pip requirements (python-docx, Pygments, latex2mathml, mathml2omml); `export_to_excel` silently needs pandas + openpyxl.
- Valves to set on bld-golden: `vision2text.vision_base_url` → local Ollama; `forward_to_webhook.webhook_urls` → Styx Discord webhook; `openrouter_tracker.openrouter_api_key`; `token_usage_display` models.dev fetch stays opt-in.
