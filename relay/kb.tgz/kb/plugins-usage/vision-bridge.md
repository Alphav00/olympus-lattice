---
slug: vision-bridge
routing_description: Retrieve when a text-only model must understand an uploaded image, or when asked where uploaded images are sent for description.
built: 2026-10-28
protocol: kb-v1
tags: [owui, filter, toggle, vision, images, ollama, egress]
---

## What it does

Toggleable inlet filter ("Vision Describe", posted as Vision Bridge). When on, every image attached to the chat (current message, and earlier turns if `describe_history`) is POSTed as base64 to an OpenAI-compatible `/chat/completions` endpoint with `description_prompt`, and the image is REPLACED in the request by text: `[Image N attached to this message]` followed by the description. Descriptions are cached by hash (`cache_size`), so each image is described once. The chat model never sees pixels. v0.4.0, author placeholder "you" (sciencepond).

## Installed as

- OWUI id: `vision2text` (type: filter, toggle)
- Enabled: yes globally, inactive until toggled on in a chat
- Verdict: caution — default endpoint is Ollama Cloud, so user images leave the host until the admin repoints it

## How to invoke

In a chat with a non-vision model (e.g. a text-only local model), open the controls (+) menu and switch on "Vision Describe" (eye icon), attach the image, then ask: "What is in this screenshot?" The model answers from the injected description. Turn the toggle off for native vision models so they receive the real image. Admins can pin the toggle on in a workspace model's filter list.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `vision_base_url` | https://ollama.com/v1 | MUST change to the local Ollama OpenAI endpoint, e.g. `http://bld-ollama-gpu:11434/v1` (container name per compose), so images stay on-host |
| `vision_model` | minimax-m3 | a local vision model present in that Ollama (e.g. a qwen-vl or llava tag that is pulled) |
| `vision_api_key` | `` | empty for local Ollama; only Ollama Cloud needs a key |
| `description_prompt` | detailed OCR-style prompt | keep; shorten for speed |
| `max_tokens` | 2000 | 800 is plenty for chat use |
| `describe_history` | True | keep (cached) |
| `cache_size` | 100 | keep; cache is in-process memory, lost on restart |

## Gotchas

- Default `vision_base_url` + `vision_api_key` = image egress to ollama.com; verify the valve before letting anyone upload.
- `vision_model` default `minimax-m3` is not a vision model on local Ollama; set a real VL tag or every image comes back "not described".
- Synchronous `requests.post` in the async path blocks the worker while the vision model runs; large images are slow.
- Images are stripped from the request when on: a vision-capable chat model loses direct sight. Toggle per chat.
- No pip requirements; `requests` is bundled.

## Source

https://openwebui.com/posts/vision_bridge_image_text_proxy_ceaceddd
