---
slug: forward-to-webhook
routing_description: Retrieve when a reply should be pushed to Discord, Slack or any JSON webhook (Styx notification path) from the message toolbar.
built: 2026-10-28
protocol: kb-v1
tags: [owui, action, webhook, discord, slack, styx, g30]
---

## What it does

Message action that POSTs the selected message to one or more webhook URLs with httpx. URL type is detected by substring: `discord` sends a Discord payload (embed or plain, username, avatar, footer with model id and timestamp), `slack` and anything else send a generic JSON body. Can strip "Thinking" blocks and keep Markdown. Admin URLs apply to everyone; a user's own `webhook_urls` override them. v0.1.0 by g30.

## Installed as

- OWUI id: `forward_to_webhook` (type: action)
- Enabled: yes; toolbar button under assistant messages
- Verdict: caution — any user can make the server POST to arbitrary URLs through UserValves (no allow-list, no SSRF check)

## How to invoke

Tap "Forward to Webhook" in the message toolbar; the message is sent at once to every configured URL (no dialog). On bld-golden the admin URL is the Styx Discord webhook, so this is the one-tap "send this reply to my phone/Discord" path. Users who want a personal target set UserValve `webhook_urls`. User-driven only; no model tool.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `webhook_urls` | `` | the Styx/Discord webhook URL (separate several with `;` or `,`); fetch from sops, never paste in chat |
| `username` | Open WebUI | e.g. `Lattice` |
| `use_user_name` | True | keep so the sender shows as Chi |
| `send_as_embed` | True | keep (Discord only) |
| `embed_color` | #34d399 | optional |
| `strip_reasoning` | True | keep |
| `forward_as_rich_text` | True | keep |
| `include_metadata` | True | keep (model id + timestamp footer) |
| UserValve `webhook_urls` | `` | leave empty for admin default |

## Gotchas

- UserValves let a non-admin point the server at internal hosts (Charon, Ollama, D1 routes); restrict who can use this action if the instance has untrusted users.
- No confirmation dialog: one tap sends.
- Discord detection is by the string `discord` in the URL; a proxied Discord URL without it gets the generic payload and Discord rejects it.
- Plain Discord content is cut at 2000 chars (`content[:2000]`); embeds follow Discord's own limits, so long replies lose their tail.
- Requires OWUI 0.8.12+; httpx bundled, no pip.

## Source

https://openwebui.com/posts/forward_to_webhook_493add62
