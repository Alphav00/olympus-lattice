---
slug: mermaid-doctor
routing_description: Retrieve when a Mermaid diagram fails to render or a small model keeps producing broken Mermaid syntax.
built: 2026-10-28
protocol: kb-v1
tags: [owui, filter, global, mermaid, diagrams, streaming, h4nn1b4l]
---

## What it does

Global filter that heals Mermaid diagrams from small or hallucinating models. Inlet injects Mermaid few-shot examples into the prompt (as a system message or appended to the last user message); `stream` rewrites the Mermaid fence while tokens arrive (man-in-the-middle sanitiser: quoting labels, fixing arrows, stripping hallucinated `style`/`classDef` colours); outlet cleans up the processor. Pure text, no network. v0.1.7 by Hannibal (h4nn1b4l).

## Installed as

- OWUI id: `mermaid_doctor` (type: filter, global, no toggle)
- Enabled: yes on all models; per-user off switch via UserValve `enabled`
- Verdict: ok

## How to invoke

Automatic. Ask for a diagram as usual: "Draw a Mermaid flowchart of the deploy pipeline." The sanitised fence renders in OWUI's Mermaid viewer. If a diagram still breaks, say "regenerate the diagram with quoted labels and no style lines". To get raw model Mermaid (for debugging), set UserValve `enabled=False` in the chat's user-valve panel, or `strip_styles=False` to keep the model's colours.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| UserValve `enabled` | True | keep |
| UserValve `inject_few_shots` | True | keep for local small models; off for frontier models to save prompt tokens |
| UserValve `inject_as_system_prompt` | False | on if the model ignores appended user text |
| UserValve `strip_styles` | True | keep so diagrams follow the OWUI theme |

There are no admin Valves in this version; all four are UserValves.

## Gotchas

- Few-shots are injected on EVERY request while enabled, not only when a diagram is requested; cost is small but constant.
- `strip_styles` removes intentional colours too.
- Stream-time rewriting means the raw transcript stored in the chat is already sanitised.
- Markdown Normalizer's `enable_mermaid_fix` also touches Mermaid; both on is fine, but turn Normalizer's off when isolating a bug.
- Not needed for export: Export to Word renders Mermaid client-side from the healed text.

## Source

https://openwebui.com/posts/mermaid_doctor_heals_broken_mermaid_diagrams_gener_310d7852
