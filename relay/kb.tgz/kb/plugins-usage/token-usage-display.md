---
slug: token-usage-display
routing_description: Retrieve when asked about the stats line under replies (tokens, context %, tok/s, cost) or how to change what it shows.
built: 2026-10-28
protocol: kb-v1
tags: [owui, filter, global, tokens, cost, context-window, smetdenis]
---

## What it does

Global filter that emits one status line under each AI response: input/output/total tokens, running chat total, reasoning and cached tokens, generation time, tokens/sec, context-window utilisation (coloured at 30 %/70 %), a truncation marker when the model hit its output limit, and message/chat cost. Usage comes from the API when reported, else tiktoken estimates. Context size resolves from override, `context_size_map`, the model's own OWUI connection, optional models.dev fetch, or llama.cpp/llama-swap probes. v2.8.0 by smetdenis.

## Installed as

- OWUI id: `token_usage_display` (type: filter, global, no toggle)
- Enabled: yes on all models; per-user off via UserValve `enabled`
- Verdict: ok — network only when opt-in valves are on

## How to invoke

Automatic; read the line under the reply. Phone users can hide it per account: user valves panel, `enabled=False`. Ask "how full is my context?" and read the `context` item (used/available + %). Admins reorder or trim items with `display_order` (keys: input, output, finish, total, tokens_total, reasoning, cached, audio, context, time, tps, cost ...).

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `priority` | 10 | keep (runs before Normalizer 50) |
| `fetch_context_from_modelsdev` | False | opt-in; leave off unless local models' context is wrong, then prefer `context_size_map` |
| `context_size_map` | `` | set e.g. `{"minimax": 200000, "qwen3": 32768}` for local models |
| `cost_mode` | auto | `auto` shows OpenRouter/LiteLLM-reported cost only; `estimate` fetches models.dev prices |
| `fetch_prices_from_modelsdev` | True | only used in `estimate` mode |
| `compact_numbers` | False | on for phone width |
| `icon_style` | emoji | `simple` for narrow screens |
| `show_cumulative_tokens` | True | off if the line is too long on phone |
| `llamacpp_url` / `llama_swap_url` | `` | leave empty; bld-golden runs Ollama |

## Gotchas

- models.dev lookups (context and prices) are opt-in and cached 24 h; `cost_mode=auto` never calls out.
- `show_finish_reason` needs OWUI 0.12.0+ and a Chat Completions or Ollama model; silent on Responses API.
- Estimated counts are marked `[est.]` only when `show_data_source` is on; estimates are not billing truth.
- Cumulative tokens re-count history every turn, so they grow faster than the context window.
- Overlaps OpenRouter tracker: with both on you get two stats lines; keep this one and set the OpenRouter tracker's `show_tokens=False`.

## Source

https://openwebui.com/posts/token_usage_display_a94ea72f
