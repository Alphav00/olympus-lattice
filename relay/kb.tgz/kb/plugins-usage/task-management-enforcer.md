---
slug: task-management-enforcer
routing_description: Retrieve when a chat should force the model to break every request into OWUI tasks (create_tasks / update_task) before answering.
built: 2026-10-28
protocol: kb-v1
tags: [owui, filter, toggle, tasks, planning, system-prompt]
---

## What it does

Toggleable inlet filter that injects an aggressive system prompt making the builtin `create_tasks` / `update_task` tools mandatory on every request, with optional few-shot examples and a strict mode. Outlet only tidies; it never edits the model's answer. No network, DB or env. Author @cooooookiecrisp; non-standard frontmatter (no version/id line); targets OWUI 0.9.5+.

## Installed as

- OWUI id: `task_management_enforcer_filter` (type: filter, toggle)
- Enabled: yes globally, but inactive until toggled on in a chat
- Verdict: ok

## How to invoke

Toggle: open the chat's controls / integrations (+) menu and switch on "Task Management Enforcer" (checklist icon). Then send any request; the model must call `create_tasks` first and `update_task` as it works. User can say "plan this as tasks" but the filter forces it regardless when on. Per-user off switch: UserValve `enabled_for_chat=False`.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `priority` | 5 | keep; raise to run after other inlet filters |
| `force_mode` | always | `smart` or `multi_step_only` to stop single-line questions becoming task lists |
| `task_detail_level` | standard | keep |
| `inject_position` | prepend | keep; `replace_last_system` overrides model system prompts |
| `include_examples` | True | off for small-context models to save tokens |
| `status_updates` | True | keep |
| UserValve `strict_mode` | False | on only when the model keeps skipping tasks |

## Gotchas

- Needs the builtin Tasks tools enabled for the model (Native Function Calling); without them the injected prompt only produces refusals or prose task lists.
- MiniMax-M3 tool-call caveat: expect occasional malformed `create_tasks` calls.
- `force_mode=always` on every message is noisy; on a phone the task panel adds scroll.
- Frontmatter lacks `version:`; OWUI shows it as unversioned.

## Source

https://openwebui.com/posts/task_management_enforcer_filter_0bb244a1
