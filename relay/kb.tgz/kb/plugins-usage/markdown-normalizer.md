---
slug: markdown-normalizer
routing_description: Retrieve when model output renders badly (broken code fences, LaTeX, headings, tables, leftover XML tags) — the Markdown Normalizer filter is already fixing it.
built: 2026-10-28
protocol: kb-v1
tags: [owui, filter, global, markdown, latex, formatting, fu-jie]
---

## What it does

Global outlet filter that regex-normalises LLM output after generation: closes unclosed code blocks, fixes fence indentation, converts `\[ \]`/`\( \)` LaTeX to `$$`/`$` with command protection, normalises `<think>` to `<thought>`, adds blank lines after `</details>`, fixes `#Header`, missing table pipes, unquoted Mermaid labels and leftover XML tags. Optional (off) fixes for escapes, lists, full-width symbols and emphasis spacing. One page-context JS read of the browser locale for messages. v1.2.9 by Fu-Jie.

## Installed as

- OWUI id: `markdown_normalizer` (type: filter, global, no toggle)
- Enabled: yes; runs on every response of every model
- Verdict: ok — pure text, no network

## How to invoke

Nothing to invoke; it is automatic. A user sees a short status line ("fixes applied") when `show_status` is on. To check whether it changed a message, turn on `show_debug_log` and read the browser console (F12). Per-chat opt-out is not available (no toggle); disable the function globally in Admin > Functions if a model's output must stay raw.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `priority` | 50 | keep high so it runs after content-producing filters (Mermaid Doctor, token display) |
| `enable_escape_fix` | False | keep off; can mangle valid `\n` in code |
| `enable_list_fix` | False | experimental; leave off |
| `enable_mermaid_fix` | True | keep; overlaps Mermaid Doctor, harmless |
| `enable_latex_fix` | True | keep |
| `enable_xml_tag_cleanup` | True | watch: strips stray tags that some prompts use as markers |
| `show_status` | True | off on phone to reduce clutter |

## Gotchas

- Runs on filters' output order: with `priority` 50 it sits after Token Usage (10) and Mermaid Doctor (default), so stats lines pass through it.
- `enable_escape_fix_in_code_blocks` can break code; only for models that double-escape.
- `enable_xml_tag_cleanup` may remove deliberate `<tag>` text in prose; wrap such text in code spans.
- Uses `__event_call__ execute` once per response for locale; harmless but needs a live browser session.

## Source

https://raw.githubusercontent.com/Fu-Jie/openwebui-extensions/main/plugins/filters/markdown_normalizer/markdown_normalizer.py
