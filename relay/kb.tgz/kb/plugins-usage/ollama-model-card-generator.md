---
slug: ollama-model-card-generator
routing_description: Retrieve when an admin wants model cards, display names, tags, avatars, num_ctx or workspace wrappers generated for the Ollama models in OWUI.
built: 2026-10-28
protocol: kb-v1
tags: [owui, tool, admin, ollama, model-cards, workspace-models, destructive, g30]
---

## What it does

Admin-only tool (every method checks `role == admin`) that reads Ollama `/api/show` metadata and turns it into rich model cards, human display names, capability tags, inference params, system and suggestion prompts, avatars (icon dir or generated monogram) and `-workspace` wrapper models. Extras: VRAM-aware `num_ctx` capping or a global context override, hide base models behind wrappers, orphan cleanup, per-method dry-run and reset (undo). Bulk-mutates the Models table by design. 4955 lines, v1.7.0 by g30, needs OWUI 0.9.0.

## Installed as

- OWUI id: `ollama_model_card_generator` (type: tool)
- Enabled: yes; attach only in an admin's chat, never pin to shared models
- Verdict: caution — mass DB mutation power (create/update/reset/delete workspace models); admin-gated

## How to invoke

Admin chat, tool attached. Safe reads: "Generate the model card for qwen3:8b" → `generate_model_card(model)`; "cards for all models" → `generate_all_model_cards()`. Writes, always after a dry run: `apply_model_card(model)`, `apply_all_model_cards()`, `create_workspace_model(model)`, `create_all_workspace_models()`, `apply_context_length_to_all_models()`, `apply_profile_images_to_all_models()`, `apply_base_model_visibility_to_all_models()`. Undo: `reset_model(model)`, `reset_all_models()`, or the per-method `*_reset` valves. Cleanup: `remove_orphaned_workspace_models()` (valve-disabled by default).

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `*_dry_run` (apply, create, images, context, visibility) | False | turn ON before any bulk write; reset/orphan dry runs default True |
| `enable_remove_orphaned_workspace_models` | False | keep off until a dry run lists only true orphans |
| `overwrite_existing` / `overwrite_workspace_models` | False | keep off: Chi's hand-made workspace models (wave-1 Pantheon, chi-self) must not be refreshed |
| `gpu_vram_gib` | 0 | set to the bld GPU VRAM so num_ctx is capped per model |
| `num_parallel`, `kv_cache_quant` | 2, q8_0 | match OLLAMA_NUM_PARALLEL / OLLAMA_KV_CACHE_TYPE in compose |
| `context_length_override` | 0 | leave 0 unless one global num_ctx is wanted |
| `hide_base_models` | False | on only after wrappers exist for every base |
| `profile_image_dir` | `` | container path to PNG/JPEG vendor icons (no SVG) |
| `clear_*` | False | pick fields before any reset |

## Gotchas

- Requires Native Function Calling and an admin user; non-admins get a refusal from every method.
- `reset_all_models` and `apply_context_length_to_all_models` touch EVERY model entry, workspace models included; run dry, read the list, then run live.
- Overwrite flags off means hand-edited descriptions/names/tags/params are left alone; on means they are replaced.
- The tool reads an admin-named directory for avatars; keep `profile_image_dir` inside the data volume.
- MiniMax-M3 tool-call caveat: use a strong model for this tool; a malformed call to a live write method is costly.
- Deletes are real DB deletes (no trash); take a DB backup first.

## Source

https://openwebui.com/posts/ollama_model_card_generator_ee80d7a1
