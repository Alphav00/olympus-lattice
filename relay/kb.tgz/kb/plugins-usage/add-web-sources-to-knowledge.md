---
slug: add-web-sources-to-knowledge
routing_description: Retrieve when a user wants the web pages cited by a web-search reply saved into one of their Knowledge bases.
built: 2026-10-28
protocol: kb-v1
tags: [owui, action, knowledge, rag, web-search, citations, g30]
---

## What it does

Message action that reads the `sources` (web citations) attached to a reply, lets the user pick one of their Knowledge bases, fetches each URL server-side through OWUI's own retrieval pipeline (`get_content_from_url` then `process_file`) and stores it as a file in that KB. Duplicate URLs are skipped when `enable_duplicate_check` is on; at most `max_urls_per_action` per click. Access is checked with `Knowledges.check_access_by_user_id`. v0.1.5 by g30.

## Installed as

- OWUI id: `add_web_sources_to_knowledge` (type: action)
- Enabled: yes; toolbar button under assistant messages that carry web sources
- Verdict: ok — writes Files/Knowledges rows by design, no hosts of its own

## How to invoke

Run a web search in the chat (web search toggle or `search_web` tool) so the reply shows source chips, then tap "Add Web Sources to Knowledge" in the message toolbar. Pick the KB in the dialog, confirm. With UserValve `default_knowledge_base` set (name or id) and `skip_confirmation=True` it is one tap. A reply without web sources answers "No web URLs found in message sources." User-driven only.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `max_urls_per_action` | 10 | keep |
| `enable_duplicate_check` | True | keep |
| `default_knowledge_base` | `` | admin default KB, e.g. a "web-clippings" KB id |
| `skip_confirmation` | False | keep off globally |
| `file_name_prefix` | `` | `web_` makes clippings easy to find in the KB file list |
| UserValves `default_knowledge_base`, `skip_confirmation`, `file_name_prefix` | `` / False / `` | per-user one-tap setup |

## Gotchas

- Fetching is server-side: pages behind logins or bot walls arrive empty or as error text, and embedding cost is paid per page.
- Only URLs present in the message's `sources` are used; links typed in the reply body are ignored.
- The KB must already exist and be writable by the user.
- Requires OWUI 0.8.12+; uses retrieval router internals, so an upgrade can change behaviour.

## Source

https://openwebui.com/posts/add_sources_to_knowledge_action_65d97417
