---
slug: export-to-word-enhanced
routing_description: Retrieve when a user wants a reply exported to a .docx with rendered Mermaid diagrams, Word equations, code highlighting and citations.
built: 2026-10-28
protocol: kb-v1
tags: [owui, action, word, docx, mermaid, latex, export, fu-jie]
---

## What it does

Message action that converts the selected Markdown reply into a Word document: headings, inline formatting, hyperlinks, syntax-highlighted code (Pygments), tables with header/zebra colours, blockquotes, LaTeX blocks and inline math as native Word equations (latex2mathml + mathml2omml), OWUI citations as a References section, embedded chat images, and Mermaid fences rendered client-side in the browser (Mermaid.js to SVG+PNG, patched into the DOCX with JSZip) with captions. Configurable fonts, en/zh UI. v0.5.3 by Fu-Jie, needs OWUI 0.10.2.

## Installed as

- OWUI id: `export_to_docx` (type: action)
- Enabled: yes; toolbar button under assistant messages
- Verdict: ok — external image fetch only when `EMBED_EXTERNAL_IMAGES=True`, via OWUI's SSRF-safe session

## How to invoke

Tap "Export to Word Enhanced" in the message toolbar under the reply. Status messages show progress; the .docx downloads through the browser. For diagrams, make sure the reply has a ```` ```mermaid ```` fence; rendering happens in the browser tab, so keep it open until the download fires. Title source and fonts can be set per user in UserValves. User-driven; the model cannot call it.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `TITLE_SOURCE` | chat_title | keep; `ai_generated` makes a model call |
| `EMBED_EXTERNAL_IMAGES` | False | keep off (no outbound fetch); chat-uploaded images embed regardless |
| `MAX_EMBED_IMAGE_MB` | 20 | keep |
| `FONT_LATIN` / `FONT_CODE` | Times New Roman / Consolas | Calibri / Cascadia Mono if preferred |
| `FONT_ASIAN` | SimSun | irrelevant for English docs |
| `MERMAID_JS_URL`, `MERMAID_JSZIP_URL` | jsdelivr / cdnjs | keep; browser must reach these CDNs |
| `MERMAID_PNG_SCALE` | 3.0 | 2.0 for smaller files |
| `MATH_INLINE_DOLLAR_ENABLE` | True | off if `$` prices get turned into equations |
| `UI_LANGUAGE` | en | keep |
| UserValves (fonts, title, mermaid, math) | None = inherit | per-user overrides |

## Gotchas

- pip requirements: `python-docx, Pygments, latex2mathml, mathml2omml` are declared in the frontmatter and installed by OWUI on save; a failed install shows at function save time, so check Admin > Functions logs.
- Mermaid rendering loads two CDN scripts into the OWUI page via `__event_call__ execute`; blocked CDNs (ad-blocker, offline phone) yield a placeholder instead of the diagram.
- Only the selected message is exported (no all-messages scope valve in this version).
- Large PNG scale plus many diagrams makes big files; lower `MERMAID_PNG_SCALE`.
- 3437 lines, reads Chats/Files/Storage; no DB writes.

## Source

https://raw.githubusercontent.com/Fu-Jie/openwebui-extensions/main/plugins/actions/export_to_docx/export_to_word.py
