---
slug: _overview
routing_description: Retrieve for a one-table map of all 19 installed community plugins — id, type, use, how to invoke.
built: 2026-10-28
protocol: kb-v1
tags: [owui, plugins, overview, index]
---

## All 19 plugins

| id | type | one-line use | invoke |
|---|---|---|---|
| `sub_agent` | tool | delegate 3+ step tool work to an isolated sub-agent | model calls `run_sub_agent` / `run_parallel_sub_agents` |
| `parallel_tools` | tool | run 2+ independent tool calls concurrently | model calls `run_tools_parallel([{name, args}])` |
| `mcp_app_bridge` | tool | call a remote MCP server; render MCP Apps as Rich UI | `list_mcp_tools` → `search_mcp_tools` → `call_mcp_tool` |
| `ask_user` | tool | 1–5 clarifying questions in one modal | model calls `get_user_clarification(questions)` |
| `revealjs_deck_builder` | tool | live Reveal.js slide deck embed | model calls `create_presentation(title, slides_html, theme)` |
| `ollama_model_card_generator` | tool (admin) | model cards, names, tags, avatars, num_ctx, workspace wrappers | admin chat; dry-run then `apply_*` / `create_*` |
| `task_management_enforcer_filter` | filter, toggle | force create_tasks/update_task on every request | toggle on in chat controls |
| `vision2text` | filter, toggle | describe uploaded images for text-only models | toggle on, attach image, ask |
| `markdown_normalizer` | filter, global | fix broken fences, LaTeX, headings, tables | automatic |
| `mermaid_doctor` | filter, global | heal Mermaid while streaming, inject few-shots | automatic; UserValve `enabled` |
| `token_usage_display` | filter, global | tokens, context %, tok/s, cost line under replies | automatic; UserValve `enabled` |
| `openrouter_tracker` | filter, global | OpenRouter cost and remaining credits | automatic on `/` model ids; needs key valve |
| `human_in_the_loop` | pipe (DISABLED) | approve every tool call via dialog | select the pipe as model (after LiteLLM endpoint is set) |
| `export_to_docx` | action | reply → .docx with Mermaid, equations, code | toolbar button "Export to Word Enhanced" |
| `export_to_excel` | action | Markdown tables → formatted .xlsx | toolbar button "Export to Excel" |
| `download_code_blocks` | action | save fenced code blocks as files | toolbar button "Download Code Blocks" |
| `forward_to_channel` | action | post reply into an OWUI channel | toolbar button; pick channel, mentions |
| `forward_to_webhook` | action | POST reply to Discord/Slack/JSON webhook (Styx) | toolbar button; sends at once |
| `add_web_sources_to_knowledge` | action | save a reply's web citations into a KB | toolbar button; pick KB |

Tools need Native Function Calling on the model. Actions are user-driven buttons under assistant messages. Toggle filters live in the chat controls (+) menu; global filters run on every model.
