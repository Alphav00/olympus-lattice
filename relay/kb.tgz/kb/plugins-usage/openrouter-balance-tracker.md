---
slug: openrouter-balance-tracker
routing_description: Retrieve when asked about OpenRouter credits left, per-message OpenRouter cost, or why the balance line is missing.
built: 2026-10-28
protocol: kb-v1
tags: [owui, filter, global, openrouter, cost, balance, credits]
---

## What it does

Global filter ("OpenRouter Complete Cost & Token Tracker") that, for models it judges to be OpenRouter (model id contains `/` or `openrouter`), reads the `usage` block from the response (body, choices or last message), computes cost, reasoning and cached tokens, measures elapsed time, and fetches the remaining credit balance from `https://openrouter.ai/api/v1/credits` with the admin's key (cached 30 s). Emits one status line per message. v1.0.0 by Colin Jones + Deepseek.

## Installed as

- OWUI id: `openrouter_tracker` (type: filter, global, no toggle)
- Enabled: yes; inert on models whose id has no `/` and no `openrouter`
- Verdict: ok — only calls openrouter.ai, only with the key valve set

## How to invoke

Automatic for OpenRouter-routed models (free router / or-free-sync models qualify because their ids contain `/`). Read the status line for tokens, `$cost`, time and `balance`. Ask "how many OpenRouter credits are left?" and the model should quote the last balance line; it has no tool to query live. No balance appears until the admin fills `openrouter_api_key`.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `openrouter_api_key` | `` | REQUIRED for balance: the OpenRouter key (sk-or-...), same one as the OWUI OpenRouter connection; mint via golden-keys |
| `show_balance` | True | keep |
| `show_cost` | True | keep |
| `show_tokens` | True | off to avoid duplicating Token Usage Display |
| `show_timing` | True | off (Token Usage Display already shows time) |
| `enable_caching` | True | keep (30 s balance cache) |
| `cost_precision` | 6 | 4 is enough on phone |
| `debug_mode` | False | on only to inspect raw usage payloads |

## Gotchas

- Admin valve only; the key is shared by all users of the instance.
- Uses synchronous `requests.get` inside async code: a slow openrouter.ai call blocks the worker briefly (performance, not security).
- Detection by model id: a local model named `vendor/model` is wrongly treated as OpenRouter and shows zero cost.
- Cost shows only when OpenRouter returns `usage` with cost; free-router models report `$0`.
- Two stats lines appear when Token Usage Display is also on; trim one.

## Source

https://openwebui.com/posts/openrouter_cost_token_tracker_22d1e74b
