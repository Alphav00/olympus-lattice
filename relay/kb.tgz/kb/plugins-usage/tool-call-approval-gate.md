---
slug: tool-call-approval-gate
routing_description: Retrieve when every tool call should wait for a human Yes/No before it runs — the Human in the Loop pipe (installed but disabled).
built: 2026-10-28
protocol: kb-v1
tags: [owui, pipe, hitl, approval, litellm, disabled]
---

## What it does

A PIPE (it appears as a model), not a filter: it sends the conversation plus the schemas of the chat's enabled OWUI tools to an OpenAI-compatible endpoint (`LITELLM_BASE_URL`), and before executing any tool call the model requests it shows an OWUI confirmation dialog. Approved calls run through `__tools__`; denied calls are reported back to the model. Up to `MAX_TOOL_ROUNDS` rounds. v5.4.0, author field "assistant" (jamolopa on openwebui.com); the Aug-25-2026 newsletter "approval gate" pick is this pipe.

## Installed as

- OWUI id: `human_in_the_loop` (type: pipe)
- Enabled: NO — installed disabled because it needs a LiteLLM (or other OpenAI-compatible) endpoint; default `http://localhost:4000` points nowhere on bld-golden
- Verdict: caution — the pipe IS the model, so all chat content leaves to whatever URL is configured

## How to invoke

Only after an admin enables the function and sets the valves: pick the model named "Human in the Loop" in the model selector, enable the tools you want in the chat (+) menu, then chat normally. Each tool call pops a confirmation dialog; tap Confirm to run it or Cancel to refuse. No special phrasing is needed.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `LITELLM_BASE_URL` | http://localhost:4000 | must be a trusted endpoint reachable from the OWUI container (e.g. a local Ollama `/v1` or Lattice OpenAI-compatible route); never leave default |
| `LITELLM_API_KEY` | `` | key for that endpoint |
| `MODEL_ID` | gemini/gemini-2.0-flash | a tool-capable model on that endpoint |
| `INJECT_TOOL_SYSTEM_PROMPT` | True | keep |
| `MAX_TOOL_ROUNDS` | 10 | keep |
| `AUTO_APPROVE_READ_ONLY` | False | on to skip dialogs for search/get/list/read/fetch/query names (name-based only) |
| `REQUEST_TIMEOUT` | 120 | raise for slow local models |

## Gotchas

- Disabled on bld-golden; enabling without repointing `LITELLM_BASE_URL` fails on connect.
- The endpoint model must support OpenAI function calling; MiniMax-M3 tool-call formatting caveat applies if routed there.
- `AUTO_APPROVE_READ_ONLY` trusts tool names, not behaviour.
- Tools are the chat's enabled OWUI tools (`__tools__`); MCP tools reach it only if exposed as OWUI tools.
- Requires OWUI 0.5.0+.

## Source

https://openwebui.com/posts/human_in_the_loop_2dddf174
