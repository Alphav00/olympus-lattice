---
slug: download-code-blocks
routing_description: Retrieve when a user wants the code blocks of a reply saved as files instead of copy-pasting.
built: 2026-10-28
protocol: kb-v1
tags: [owui, action, code, download, files, silentoplayz]
---

## What it does

Message action that extracts every fenced code block from the selected assistant reply and saves each as a properly named file (170+ language-to-extension mappings via Pygments). Shows a confirmation modal with syntax-highlighted previews, line numbers and editable filenames; files are written client-side (`<a download>`), nothing touches the server disk. v1.1.0 by silentoplayz (posted by g30).

## Installed as

- OWUI id: `download_code_blocks` (type: action)
- Enabled: yes; appears as a button in the toolbar under assistant messages (pin to models in Admin > Functions if hidden)
- Verdict: ok — no network, DB or server file I/O

## How to invoke

Tap the "Download Code Blocks" button in the message toolbar (icons under the reply; on phone, tap the reply then the toolbar). A modal lists each block: edit the filename, untick blocks you do not want, confirm. With `auto_download` on, all blocks save immediately with no modal. The model cannot trigger this; it is user-driven. A reply with no fenced blocks shows "No code blocks found in the response."

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `priority` | 0 | keep (button order) |
| `default_filename` | code | keep; used when a fence has no language |
| `auto_download` | False | keep off; on phone the modal is the only chance to rename |
| UserValves `default_filename`, `auto_download` | same | per-user override |

## Gotchas

- Browser download permissions: mobile Chrome may ask to allow multiple downloads; allow it once.
- Filenames come from the fence language; blocks without a language tag get `code.txt`-style names.
- Runs JS via `__event_call__ execute` in page context; no same-origin iframe toggle involved.
- Does not zip; many blocks mean many separate downloads.

## Source

https://openwebui.com/posts/download_code_blocks_06f51b22
