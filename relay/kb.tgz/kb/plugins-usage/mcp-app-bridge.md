---
slug: mcp-app-bridge
routing_description: Retrieve when a chat should call tools on a remote Streamable-HTTP MCP server or render an MCP App (ui://) as a Rich UI embed.
built: 2026-10-28
protocol: kb-v1
tags: [owui, tool, mcp, mcp-apps, rich-ui, oauth, classic298]
---

## What it does

Wraps one remote MCP server behind three OWUI tools and acts as an MCP Apps (2026-01-26) host: tools that return `ui://` HTML resources render as Rich UI embeds in a nested sandboxed iframe, with JSON-RPC relayed over postMessage through a route the tool mounts at `POST /api/v1/mcp-app-bridge/rpc`. Discovery is paginated (25 per page) plus keyword search (top 5 with full schemas) so the model never loads every schema. Supports bearer, OAuth 2.1 dynamic registration and static-client auth. By Classic298. Installed on bld-golden: v0.6.0 (v1.0.1 fails to import on OWUI 0.12.4: `streamablehttp_client` renamed in the bundled mcp lib; re-try after upstream fix).

## Installed as

- OWUI id: `mcp_app_bridge` (type: tool)
- Enabled: yes; attach per chat or pin to a model; one tool instance = one MCP server (`mcp_server_url`)
- Verdict: caution — injects an HTTP route, signs 15-minute tokens with `WEBUI_SECRET_KEY`, runs OAuth flows; not malice

## How to invoke

User phrasing: "What tools does the MCP server offer?" / "Use the MCP tool `<name>` with ..." / "Open the <app> UI."

Model sequence: `list_mcp_tools(offset=0)` to browse names (follow `next_offset`), `search_mcp_tools(query)` to get a tool's parameter schema (searching the exact name works), then `call_mcp_tool(tool_name, arguments)` where `arguments` is a JSON string (default `"{}"`). The docstring forbids answering "I cannot run this tool": the model CAN, via `call_mcp_tool`. Results are text or a visual embed shown directly to the user.

## Valves that matter

| valve | default | bld-golden |
|---|---|---|
| `mcp_server_url` | `` | the Streamable-HTTP URL of the target server (Lattice/Charon MCP route) |
| `auth_method` | bearer | `bearer` for key-protected servers; `oauth_2.1` only for servers that advertise OAuth |
| `auth_token` | `` | bearer key; empty for an unauthenticated server |
| `oauth_server_url` / `oauth_scope` | `` | leave empty to discover (RFC 9728) |
| `oauth_client_info` | `` | managed automatically; clear to force re-registration |
| `tool_blocklist` | `` | comma list of tool names to hide and block |

## Gotchas

- Needs Native Function Calling; three-step discovery is heavier on small models (MiniMax-M3 tool-call caveat applies).
- Works with the Rich UI same-origin toggle on or off; the nested app iframe never gets `allow-same-origin`. With same-origin on, app prompts skip OWUI's confirm dialog (code comment).
- The RPC token embedded in chat HTML is readable by anyone who can open that chat (15-minute TTL).
- The route is inserted at router position 0 with CORS `*`; it only answers with a valid OWUI bearer or signed token.
- Requires OWUI 0.11.4+; `mcp` and `jwt` come bundled, no pip needed.

## Source

https://raw.githubusercontent.com/Classic298/open-webui-plugins/main/mcp-app-bridge/tool.py
