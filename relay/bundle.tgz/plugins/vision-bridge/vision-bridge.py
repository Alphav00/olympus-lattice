"""
title: Vision Describe
author: you
version: 0.4.0
required_open_webui_version: 0.5.0
"""

import asyncio
import hashlib
from typing import Optional

from pydantic import BaseModel, Field


class Filter:
    class Valves(BaseModel):
        priority: int = Field(
            default=0,
            description="Filter execution priority (lower runs first).",
        )
        vision_model: str = Field(
            default="minimax-m3",
            description="Vision-capable model used to describe images.",
        )
        vision_base_url: str = Field(
            default="https://ollama.com/v1",
            description="Base URL (OpenAI-compatible) of the vision model.",
        )
        vision_api_key: str = Field(
            default="",
            description="Ollama Cloud API key (ollama.com/settings/keys).",
        )
        description_prompt: str = Field(
            default=(
                "Describe this image in extreme detail, including every visible "
                "object, person, text/OCR, colors, layout, and the overall context. "
                "Be thorough and objective."
            ),
            description="Prompt sent to the vision model.",
        )
        max_tokens: int = Field(
            default=2000,
            description="Max tokens for each image description.",
        )
        describe_history: bool = Field(
            default=True,
            description=(
                "Describe images from earlier turns too (cached, so each image "
                "is only sent to the vision model once). Turn off to describe "
                "only images attached to the newest message."
            ),
        )
        cache_size: int = Field(
            default=100,
            description="How many image descriptions to keep in memory.",
        )

    def __init__(self):
        self.valves = self.Valves()
        self._cache = {}
        self.toggle = True
        self.icon = (
            "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIG"
            "ZpbGw9Im5vbmUiIHZpZXdCb3g9IjAgMCAyNCAyNCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZT0iY3"
            "VycmVudENvbG9yIj48cGF0aCBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm"
            "91bmQiIGQ9Ik0yLjAzNiAxMi4zMjJhMS4wMTIgMS4wMTIgMCAwIDEgMC0uNjM5QzMuNDIzIDcuNTEgNy"
            "4zNiA0LjUgMTIgNC41YzQuNjM4IDAgOC41NzMgMy4wMDcgOS45NjMgNy4xNzguMDcuMjA3LjA3LjQzMS"
            "AwIC42MzlDMjAuNTc3IDE2LjQ5IDE2LjY0IDE5LjUgMTIgMTkuNWMtNC42MzggMC04LjU3My0zLjAwNy"
            "05Ljk2My03LjE3OFoiLz48cGF0aCBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj"
            "0icm91bmQiIGQ9Ik0xNSAxMmEzIDMgMCAxIDEtNiAwIDMgMyAwIDAgMSA2IDBaIi8+PC9zdmc+"
        )

    async def inlet(
        self,
        body: dict,
        __user__: Optional[dict] = None,
        __event_emitter__=None,
    ) -> dict:
        messages = body.get("messages") or []
        if not messages:
            return body

        last_user_idx = next(
            (
                i
                for i in range(len(messages) - 1, -1, -1)
                if messages[i].get("role") == "user"
            ),
            None,
        )

        # Map message index -> its images, in conversation order
        per_message = {}
        for i, msg in enumerate(messages):
            imgs = self._images_in(msg)
            if not imgs:
                continue
            if not self.valves.describe_history and i != last_user_idx:
                per_message[i] = []  # strip, but don't describe
                continue
            per_message[i] = imgs

        if not per_message:
            return body

        # Only send images the vision model hasn't already seen
        todo = [
            img
            for imgs in per_message.values()
            for img in imgs
            if self._key(img) not in self._cache
        ]

        for n, img in enumerate(todo, start=1):
            if __event_emitter__:
                await __event_emitter__(
                    {
                        "type": "status",
                        "data": {
                            "description": f"Describing image {n}/{len(todo)}...",
                            "done": False,
                        },
                    }
                )
            self._cache[self._key(img)] = await asyncio.to_thread(
                self._describe_image, img
            )

        self._trim_cache()

        if todo and __event_emitter__:
            await __event_emitter__(
                {"type": "status", "data": {"description": "", "done": True}}
            )

        # Rewrite each message in place, keeping descriptions with their own image
        counter = 0
        for i, msg in enumerate(messages):
            if i not in per_message:
                continue

            text = self._text_only(msg.get("content"))
            msg.pop("images", None)
            blocks = []

            for img in per_message[i]:
                counter += 1
                desc = self._cache.get(self._key(img))
                if desc:
                    blocks.append(f"[Image {counter} attached to this message]\n{desc}")
                else:
                    blocks.append(
                        f"[Image {counter} attached to this message: not described]"
                    )

            msg["content"] = (text + "\n\n" + "\n\n".join(blocks)).strip()

        body["messages"] = messages
        return body

    # ------------------------------------------------------------------ #

    def _images_in(self, msg) -> list:
        """Images attached to a single message, both content shapes."""
        found = []
        content = msg.get("content")
        if isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "image_url":
                    url = (part.get("image_url") or {}).get("url")
                    if url:
                        found.append(url)
        for img in msg.get("images") or []:
            if isinstance(img, str):
                found.append(img)
        return found

    def _text_only(self, content) -> str:
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return "\n".join(
                part.get("text", "")
                for part in content
                if isinstance(part, dict) and part.get("type") == "text"
            ).strip()
        return ""

    def _key(self, img: str) -> str:
        return hashlib.sha256(img.encode("utf-8", "ignore")).hexdigest()

    def _trim_cache(self):
        limit = max(1, self.valves.cache_size)
        while len(self._cache) > limit:
            self._cache.pop(next(iter(self._cache)))

    def _describe_image(self, img: str) -> str:
        try:
            import requests

            data_url = (
                img
                if img.startswith("data:image")
                else ("data:image/png;base64," + img)
            )

            resp = requests.post(
                self.valves.vision_base_url.rstrip("/") + "/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.valves.vision_api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.valves.vision_model,
                    "max_tokens": self.valves.max_tokens,
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "text",
                                    "text": self.valves.description_prompt,
                                },
                                {
                                    "type": "image_url",
                                    "image_url": {"url": data_url},
                                },
                            ],
                        }
                    ],
                },
                timeout=180,
            )

            if resp.status_code != 200:
                return f"[Vision error: HTTP {resp.status_code} - {resp.text[:300]}]"

            return resp.json()["choices"][0]["message"]["content"] or ""
        except Exception as e:
            return f"[Vision error: {type(e).__name__}: {e}]"
