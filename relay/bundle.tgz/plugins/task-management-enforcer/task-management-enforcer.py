"""
Title: Task Management Enforcer Filter
=====================================================
Description: Forces the model to use built-in create_tasks / update_task on EVERY request. Makes task breakdown non-negotiable via aggressive system prompt injection.
Author: @cooooookiecrisp
Target: Open WebUI v0.9.5 (latest as of 2026-05-10)
"""

from pydantic import BaseModel, Field
from typing import Optional, Literal


class Filter:
    """
    Injects a mandatory task-breakdown system prompt before every user request.
    When toggleable and enabled, the model will ALWAYS call create_tasks before
    answering, ensuring structured multi-step execution on every chat turn.
    """

    class Valves(BaseModel):
        """Admin-level configuration — set once, applies globally."""

        priority: int = Field(
            default=5,
            description="Filter execution order. Lower runs first. "
            "Set higher than other filters if you want this to run last in inlet chain.",
        )
        force_mode: Literal["always", "multi_step_only", "smart"] = Field(
            default="always",
            description="When to force task creation. "
            "'always' = every message. "
            "'multi_step_only' = only when query looks complex. "
            "'smart' = use heuristics (length, question marks, keywords).",
        )
        task_detail_level: Literal["brief", "standard", "exhaustive"] = Field(
            default="standard",
            description="How granular the task breakdown should be.",
        )
        inject_position: Literal["prepend", "append", "replace_last_system"] = Field(
            default="prepend",
            description="Where to inject the task-enforcement prompt. "
            "'prepend' = first message. "
            "'append' = last message before user. "
            "'replace_last_system' = replace the most recent system message.",
        )
        include_examples: bool = Field(
            default=True,
            description="Include few-shot examples of good task breakdowns.",
        )
        status_updates: bool = Field(
            default=True,
            description="Emit status events to the UI when the filter activates.",
        )

    class UserValves(BaseModel):
        """Per-chat user settings — adjustable from the chip in the chat input bar."""

        enabled_for_chat: bool = Field(
            default=True,
            description="Enable the task enforcer for this chat session.",
        )
        strict_mode: bool = Field(
            default=False,
            description="If true, the filter adds an ULTRA-STRICT instruction; "
            "the model may refuse to answer without creating tasks first.",
        )
        custom_prefix: str = Field(
            default="",
            description="Optional custom instruction prepended to the task prompt. "
            "Leave empty to use the default.",
        )

    def __init__(self):
        self.valves = self.Valves()
        self.user_valves = self.UserValves()
        self.toggle = True  # User can enable/disable per chat
        self.icon = "https://cdn.jsdelivr.net/npm/@tabler/icons@3.31.0/icons/outline/checklist.svg"
        self.name = "Task Enforcer"

    # ------------------------------------------------------------------
    # Prompt Templates
    # ------------------------------------------------------------------

    @property
    def _base_instruction(self) -> str:
        """Core instruction that forces task creation."""
        return (
            "YOU MUST FOLLOW THIS RULE WITHOUT EXCEPTION:\n"
            "Before providing ANY answer, analysis, or response, you MUST:\n"
            "1. Call the `create_tasks` tool to break down the user's request "
            "into a structured checklist of concrete, ordered steps.\n"
            "2. Mark the first task as `in_progress`.\n"
            "3. Execute each task one at a time, calling `update_task` after "
            "EACH step to mark it `completed` and the next one `in_progress`.\n"
            "4. Only deliver the final answer after ALL tasks are `completed`.\n\n"
            "NEVER skip task creation. Even for simple questions, create at "
            "least 2 tasks (e.g., 'Analyze the question' and 'Formulate answer').\n"
            "This is NON-NEGOTIABLE. The user MUST see your task plan before "
            "your final response."
        )

    @property
    def _strict_instruction(self) -> str:
        """Ultra-strict addendum for strict_mode."""
        return (
            "\n\nCRITICAL — STRICT MODE ACTIVE:\n"
            "If you cannot call create_tasks for any reason, respond ONLY with:\n"
            "'I am unable to comply with the task-breakdown requirement. "
            "Please check that Task Management is enabled in Builtin Tools.'\n"
            "DO NOT provide any other response until tasks are created."
        )

    @property
    def _detail_instructions(self) -> dict:
        """Detail-level modifiers."""
        return {
            "brief": (
                "Keep tasks concise — 2-5 items. Use short names. "
                "Focus only on the critical path."
            ),
            "standard": (
                "Create 3-8 well-named tasks. Include verification steps. "
                "Balance breadth with depth."
            ),
            "exhaustive": (
                "Create 5-15 granular tasks. Include sub-checks, edge-case "
                "handling, validation steps, and a final review task. "
                "Leave no stone unturned."
            ),
        }

    @property
    def _examples(self) -> str:
        """Few-shot examples of good task breakdowns."""
        return (
            "\n\nEXAMPLES OF CORRECT TASK BREAKDOWN:\n\n"
            "---\n"
            "User: 'What's the best way to optimize a React app?'\n"
            "Tasks:\n"
            "1. [in_progress] Identify common React performance bottlenecks\n"
            "2. [pending] Research code-splitting and lazy loading strategies\n"
            "3. [pending] Research memoization (useMemo, useCallback, React.memo)\n"
            "4. [pending] Research virtualisation and bundle analysis tools\n"
            "5. [pending] Synthesize findings into ranked recommendations\n"
            "6. [pending] Deliver final answer with code examples\n"
            "---\n"
            "User: 'Write a Python function to sort a list.'\n"
            "Tasks:\n"
            "1. [in_progress] Clarify sort requirements (in-place vs new list, "
            "ascending vs descending)\n"
            "2. [pending] Write the function with proper type hints\n"
            "3. [pending] Add docstring and edge-case handling\n"
            "4. [pending] Deliver final code with brief explanation\n"
            "---\n\n"
            "Now apply this same pattern to the user's actual request below."
        )

    # ------------------------------------------------------------------
    # Heuristics for smart / multi_step_only modes
    # ------------------------------------------------------------------

    @staticmethod
    def _looks_multi_step(user_content: str) -> bool:
        """Heuristic: does the user's message look like it needs multiple steps?"""
        if not user_content:
            return False
        content_lower = user_content.lower()

        # Explicit multi-part indicators
        multi_step_phrases = [
            "step by step",
            "break down",
            "breakdown",
            "walk me through",
            "how do i",
            "how to",
            "explain how",
            "what are the steps",
            "compare",
            "analyze",
            "debug",
            "fix",
            "optimize",
            "build",
            "create a",
            "design",
            "implement",
            "migrate",
            "refactor",
            "review",
            "audit",
            "investigate",
            "research",
            "summarize",
            "translate",
            "convert",
            "generate",
            "plan",
            "strategy",
            "best practice",
            "recommend",
            "evaluate",
            "assess",
        ]
        if any(phrase in content_lower for phrase in multi_step_phrases):
            return True

        # Multiple questions
        question_mark_count = user_content.count("?")
        if question_mark_count >= 2:
            return True

        # Long messages likely need breakdown
        if len(user_content.split()) > 50:
            return True

        # Numbered/comma-separated lists
        if any(char in user_content for char in ["1.", "2.", "3."]):
            return True

        return False

    # ------------------------------------------------------------------
    # Prompt Builder
    # ------------------------------------------------------------------

    def _build_task_prompt(self, user_valves: "Filter.UserValves") -> str:
        """Assemble the full task-enforcement system prompt."""
        parts = []

        # Base instruction
        parts.append(self._base_instruction)

        # Detail level
        detail = self._detail_instructions.get(
            self.valves.task_detail_level,
            self._detail_instructions["standard"],
        )
        parts.append(f"\n\nDETAIL LEVEL: {detail}")

        # Examples
        if self.valves.include_examples:
            parts.append(self._examples)

        # Strict mode
        if user_valves.strict_mode:
            parts.append(self._strict_instruction)

        # Custom prefix
        if user_valves.custom_prefix.strip():
            parts.insert(0, user_valves.custom_prefix.strip())

        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Inlet — the core logic
    # ------------------------------------------------------------------

    async def inlet(
        self,
        body: dict,
        __event_emitter__=None,
        __user__: Optional[dict] = None,
        __metadata__: Optional[dict] = None,
    ) -> dict:
        """
        Inject a mandatory task-breakdown system prompt before the request
        reaches the model. The model MUST call create_tasks before responding.
        """
        # --- Gate checks ---
        # Respect UserValves: skip if the user disabled it for this chat
        if not self.user_valves.enabled_for_chat:
            return body

        messages = body.get("messages", [])
        if not messages:
            return body

        # Find the last user message for heuristics
        last_user_content = ""
        for msg in reversed(messages):
            if msg.get("role") == "user" and msg.get("content"):
                last_user_content = msg["content"]
                break

        # Mode-based gating
        mode = self.valves.force_mode
        if mode == "multi_step_only" and not self._looks_multi_step(last_user_content):
            return body
        if mode == "smart":
            # In "smart" mode, skip for very short/simple messages
            if (
                len(last_user_content.split()) < 8
                and "?" not in last_user_content
                and not self._looks_multi_step(last_user_content)
            ):
                return body

        # --- Build and inject the prompt ---
        task_prompt = self._build_task_prompt(self.user_valves)
        system_msg = {"role": "system", "content": task_prompt}

        position = self.valves.inject_position

        if position == "prepend":
            messages.insert(0, system_msg)
        elif position == "replace_last_system":
            # Replace the last system message if one exists
            replaced = False
            for i in range(len(messages) - 1, -1, -1):
                if messages[i].get("role") == "system":
                    messages[i] = system_msg
                    replaced = True
                    break
            if not replaced:
                messages.insert(0, system_msg)
        else:  # append — insert just before the last user message
            insert_idx = len(messages)
            for i in range(len(messages) - 1, -1, -1):
                if messages[i].get("role") == "user":
                    insert_idx = i
                    break
            messages.insert(insert_idx, system_msg)

        body["messages"] = messages

        # --- Status feedback ---
        if self.valves.status_updates and __event_emitter__ is not None:
            try:
                await __event_emitter__(
                    {
                        "type": "status",
                        "data": {
                            "description": (
                                "🧩 Task Enforcer: Model instructed to create a "
                                "task plan before responding."
                            ),
                            "done": True,
                            "hidden": False,
                        },
                    }
                )
            except Exception:
                pass  # Never let status emission break the pipeline

        return body

    # ------------------------------------------------------------------
    # Outlet — optional audit: check if model actually used tasks
    # ------------------------------------------------------------------

    async def outlet(
        self,
        body: dict,
        __event_emitter__=None,
        __user__: Optional[dict] = None,
    ) -> dict:
        """
        Post-response check. If task management appears unused, we could log
        or emit a warning. Does NOT modify the response.
        """
        # For now this is a no-op extension point.
        # Future: detect whether create_tasks was called and warn if not.
        return body
