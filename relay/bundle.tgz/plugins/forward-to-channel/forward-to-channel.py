"""
title: Forward to Channel
author: @G30
author_url: https://openwebui.com/u/g30
funding_url: https://github.com/open-webui
version: 0.1.6
license: MIT
required_open_webui_version: 0.8.12
icon_url: data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2224px%22%20height%3D%2224px%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cg%20transform%3D%22translate(-1.8%20-1.8)%20scale(1.15)%22%3E%3Cpath%20fill%3D%22currentColor%22%20fill-rule%3D%22evenodd%22%20d%3D%22M2.46%2016.82a.75.75%200%200%201-.13-.86l.702-1.386a9.75%209.75%200%200%201%208.699-5.345h.345q.037-.82.097-1.638l.068-.931a1.002%201.002%200%200%201%201.539-.771a19.6%2019.6%200%200%201%205.373%205.089l.456.635a.75.75%200%200%201%200%20.875l-.456.635a19.6%2019.6%200%200%201-5.373%205.089a1.002%201.002%200%200%201-1.539-.771l-.068-.93a62%2062%200%200%201-.111-1.957a14%2014%200%200%200-6.27%201.282L3.314%2016.98a.75.75%200%200%201-.854-.16m2.218-2.122l.485-.224a15.5%2015.5%200%200%201%207.682-1.38a.75.75%200%200%201%20.692.725q.038%201.292.132%202.582l.006.075a18.1%2018.1%200%200%200%204.26-4.228l.142-.198l-.142-.197a18.1%2018.1%200%200%200-4.26-4.228l-.006.075a60%2060%200%200%200-.123%202.304a.75.75%200%200%201-.75.725h-1.065a8.25%208.25%200%200%200-7.053%203.969%22%20clip-rule%3D%22evenodd%22/%3E%3C/g%3E%3C/svg%3E
"""

from pydantic import BaseModel, Field
from typing import Optional
from starlette.requests import Request

import asyncio
import re
import shlex
import inspect

from open_webui.models.channels import Channels
from open_webui.models.messages import MessageForm
from open_webui.models.users import UserModel


async def convert_at_mentions(
    request: Request, content: str, current_user: dict
) -> str:
    """
    Convert @username and @modelname mentions to channel mention format.
    Format: <@U:user-id|username> or <@M:model-id|model-name>
    Supports both @username and @"multi word name" formats.
    """
    if not content or "@" not in content:
        return content

    # Find all @mentions - support both @word and @"quoted name" formats
    mention_pattern = re.compile(r'@(?:"([^"]+)"|(\w+))')

    # Find all mentions first
    mentions = mention_pattern.findall(content)
    if not mentions:
        return content

    # Get all models for matching
    try:
        from open_webui.utils.models import get_all_models

        models = await get_all_models(request)
    except Exception:
        models = []

    # Build model lookup dict
    model_lookup = {m.get("name", "").lower(): m for m in models}

    from open_webui.models.users import Users

    # Async Replace function since we need to hit the DB
    async def async_replace_mention(match):
        name = match.group(1) or match.group(2)

        try:
            # 0.9.0 Await DB Call
            result = await Users.get_users(filter={"query": name})
            users = result.get("users", []) if result else []
            for user in users:
                user_name = user.name or ""
                user_username = user.username or ""
                if user_name.lower() == name.lower() or (
                    user_username and user_username.lower() == name.lower()
                ):
                    display_name = user_name or user_username
                    return f"<@U:{user.id}|{display_name}>"
        except Exception:
            pass

        model = model_lookup.get(name.lower())
        if model:
            model_id = model.get("id")
            model_name = model.get("name", name)
            return f"<@M:{model_id}|{model_name}>"

        return match.group(0)

    # Reconstruct the string iteratively since re.sub doesn't support async callables
    parts = []
    last_idx = 0
    for match in mention_pattern.finditer(content):
        parts.append(content[last_idx : match.start()])
        replacement = await async_replace_mention(match)
        parts.append(replacement)
        last_idx = match.end()
    parts.append(content[last_idx:])

    return "".join(parts)


async def post_to_channel(
    channel,
    formatted_message: str,
    user_id: str,
    user_obj,
    request,
    effective_debug: bool = False,
    filtered_models: list = None,
):
    """
    Post a message to a single channel.
    """
    from open_webui.internal.db import get_async_db_context
    from open_webui.routers.channels import (
        new_message_handler,
        model_response_handler,
    )
    from open_webui.models.messages import MessageForm
    from open_webui.utils.channels import extract_mentions

    try:
        mentions = extract_mentions(formatted_message)

        if effective_debug:
            print(
                f"[Forward to Channel] Extracted mentions for channel {channel.id}: {mentions}"
            )

        # 0.9.0 Replace get_db() with async variant
        async with get_async_db_context() as db:
            message_form = MessageForm(content=formatted_message)

            message, result_channel = await new_message_handler(
                request=request,
                id=channel.id,
                form_data=message_form,
                user=user_obj,
                db=db,
            )

            if message and result_channel and mentions and filtered_models:
                model_mentions = [m for m in mentions if m["id_type"] == "M"]

                if model_mentions:
                    if effective_debug:
                        print(
                            f"[Forward to Channel] Found {len(model_mentions)} model mentions, triggering responses"
                        )

                    try:
                        for mention in model_mentions:
                            model_id = mention["id"]
                            model_in_filtered = any(
                                m.get("id") == model_id for m in filtered_models
                            )
                            if effective_debug:
                                print(
                                    f"[Forward to Channel] Model {model_id} in filtered: {model_in_filtered}"
                                )

                            model = next(
                                (m for m in filtered_models if m.get("id") == model_id),
                                None,
                            )
                            if model:
                                if effective_debug:
                                    print(
                                        f"[Forward to Channel] Model info: id={model.get('id')}, owned_by={model.get('owned_by')}, base_url={model.get('base_url')}, urlIdx={model.get('urlIdx')}"
                                    )

                                app_models = (
                                    getattr(request, "app", {}).state.MODELS
                                    if hasattr(request, "app")
                                    and hasattr(request.app.state, "MODELS")
                                    else {}
                                )
                                if effective_debug:
                                    print(
                                        f"[Forward to Channel] request.app.state.MODELS has {len(app_models)} models"
                                    )

                                if model_id not in app_models:
                                    if effective_debug:
                                        print(
                                            f"[Forward to Channel] WARNING: Model not in app.state.MODELS!"
                                        )
                                    request.app.state.MODELS[model_id] = model
                                    if effective_debug:
                                        print(
                                            f"[Forward to Channel] Added model to app.state.MODELS"
                                        )

                        if effective_debug:
                            print(
                                f"[Forward to Channel] Calling model_response_handler..."
                            )
                        result = await model_response_handler(
                            request, result_channel, message, user_obj, db=db
                        )
                        if effective_debug:
                            print(
                                f"[Forward to Channel] model_response_handler returned: {result}"
                            )
                    except Exception as e:
                        if effective_debug:
                            print(
                                f"[Forward to Channel] Model response handler error: {e}"
                            )
                        import traceback

                        traceback.print_exc()
                elif effective_debug:
                    print(
                        f"[Forward to Channel] Only user mentions found ({len(mentions)} mentions), skipping model_response_handler"
                    )

            return (channel, result_channel) if message and result_channel else None
    except Exception as e:
        if effective_debug:
            print(f"[Forward to Channel] Error posting to channel: {e}")
        import traceback

        traceback.print_exc()
        return None


async def lookup_dm_partner(
    channel_id: str, current_user_id: str, debug: bool = False
) -> Optional[str]:
    """
    Look up the DM partner name for a channel.
    """
    from open_webui.models.users import Users
    from open_webui.models.channels import ChannelMember
    from open_webui.internal.db import get_async_db_context
    from sqlalchemy import select

    try:
        if debug:
            print(
                f"[Forward to Channel] Looking up DM partner for channel {channel_id}"
            )

        # 0.9.0 SQLAlchemy 2.0 Syntax + Async Context
        async with get_async_db_context() as db:
            result = await db.execute(
                select(ChannelMember).filter(
                    ChannelMember.channel_id == channel_id,
                    ChannelMember.is_active.is_(True),
                )
            )
            members = result.scalars().all()

            for member in members:
                if member.user_id != current_user_id:
                    # 0.9.0 Await DB call
                    user = await Users.get_user_by_id(member.user_id)
                    if user:
                        result_name = f"@{user.name}"
                        if debug:
                            print(
                                f"[Forward to Channel] DM partner found: {result_name}"
                            )
                        return result_name
        if debug:
            print(f"[Forward to Channel] No DM partner found for channel {channel_id}")
        return None
    except Exception as e:
        if debug:
            print(f"[Forward to Channel] DM partner lookup error: {e}")
        import traceback

        traceback.print_exc()
        return None


async def lookup_user_by_name(
    name: str,
    dm_partner_names: dict,
    debug: bool = False,
) -> Optional[tuple[str, str]]:
    """
    Look up a user by name for @mention conversion.
    """
    from open_webui.models.users import Users

    try:
        if debug:
            print(f"[Forward to Channel] Looking up user: '{name}'")

        # 0.9.0 Await DB call
        result = await Users.get_users(filter={"query": name})
        users = result.get("users", []) if result else []

        if debug:
            print(
                f"[Forward to Channel] Users found: {[(u.name, u.username) for u in users]}"
            )

        for user in users:
            user_name = user.name or ""
            user_username = user.username or ""
            if user_name.lower() == name.lower() or (
                user_username and user_username.lower() == name.lower()
            ):
                user_id = user.id
                display_name = user_name or user_username
                if debug:
                    print(
                        f"[Forward to Channel] Found user: {display_name} (id: {user_id})"
                    )
                return (user_id, display_name)

        if debug:
            print(f"[Forward to Channel] No match for user '{name}', trying DM lookup")

        for channel_id, partner_name in dm_partner_names.items():
            if partner_name == f"@{name}":
                if debug:
                    print(
                        f"[Forward to Channel] Found user via DM lookup: {partner_name}"
                    )
                actual_user_name = partner_name[1:]
                # 0.9.0 Await DB call
                result2 = await Users.get_users(filter={"query": actual_user_name})
                users2 = result2.get("users", []) if result2 else []
                for user in users2:
                    user_name = user.name or ""
                    if user_name.lower() == actual_user_name.lower():
                        user_id = user.id
                        if debug:
                            print(
                                f"[Forward to Channel] Found via DM: {actual_user_name} (id: {user_id})"
                            )
                        return (user_id, actual_user_name)

        if debug:
            print(f"[Forward to Channel] No match found for user '{name}'")
        return None
    except Exception as e:
        if debug:
            print(f"[Forward to Channel] User lookup error: {e}")
        import traceback

        traceback.print_exc()
        return None


async def lookup_model_by_name(
    name: str,
    request: Request,
    debug: bool = False,
    models: list = None,
) -> Optional[tuple[str, str]]:
    """
    Look up a model by name for @mention conversion.
    """
    try:
        if debug:
            print(f"[Forward to Channel] Looking up model: '{name}'")

        if models is None:
            from open_webui.utils.models import get_all_models

            models = await get_all_models(request)

        if debug:
            print(
                f"[Forward to Channel] Models available: {[m.get('name') for m in models]}"
            )

        for model in models:
            if model.get("name", "").lower() == name.lower():
                model_id = model.get("id")
                model_name = model.get("name", name)
                if debug:
                    print(
                        f"[Forward to Channel] Found model: {model_name} (id: {model_id})"
                    )
                return (model_id, model_name)

        if debug:
            print(f"[Forward to Channel] No match found for model '{name}'")
        return None
    except Exception as e:
        if debug:
            print(f"[Forward to Channel] Model lookup error: {e}")
        import traceback

        traceback.print_exc()
        return None


class Action:
    """
    Action function that forwards chat messages to a channel.
    """

    class Valves(BaseModel):
        priority: int = Field(
            default=0,
            description="Priority level for button sorting in the UI (lower numbers appear first).",
        )
        default_channel_id: str = Field(
            default="",
            description="System-wide default channel ID to forward to",
        )
        include_chat_title: bool = Field(
            default=True,
            description="Include the chat title in the forwarded message",
        )
        include_timestamp: bool = Field(
            default=True,
            description="Add timestamp to the forwarded messages",
        )
        skip_confirmation: bool = Field(
            default=False,
            description="System-wide default: skip channel selection dialog",
        )
        skip_mentions: bool = Field(
            default=False,
            description="Skip the @mentions input dialog and send without additional mentions",
        )
        debug: bool = Field(
            default=False,
            description="Enable debug logging for this action",
        )

    class UserValves(BaseModel):
        default_channel_id: str = Field(
            default="",
            description="Default channel ID to forward to. If set, skips the selection dialog.",
        )
        include_chat_title: bool = Field(
            default=True,
            description="Include the chat title in the forwarded message",
        )
        include_timestamp: bool = Field(
            default=True,
            description="Add timestamp to the forwarded messages",
        )
        skip_confirmation: bool = Field(
            default=False,
            description="Skip channel selection dialog and use default channel",
        )
        skip_mentions: bool = Field(
            default=False,
            description="Skip the @mentions input dialog and send without additional mentions",
        )
        debug: bool = Field(
            default=False,
            description="Enable debug logging for this action",
        )

    def __init__(self):
        self.valves = self.Valves()

    async def action(
        self,
        body: dict,
        __user__: dict = None,
        __event_emitter__=None,
        __event_call__=None,
        __request__=None,
    ) -> Optional[dict]:
        """
        Main action handler that forwards messages to a channel.
        """

        user_valves = __user__.get("valves", None)
        if user_valves and isinstance(user_valves, self.UserValves):
            uv = user_valves
        elif user_valves and isinstance(user_valves, dict):
            uv = self.UserValves(**user_valves)
        else:
            uv = self.UserValves()

        effective_default_channel = (
            uv.default_channel_id
            if uv.default_channel_id
            else self.valves.default_channel_id
        )
        effective_include_title = (
            uv.include_chat_title
            if hasattr(uv, "include_chat_title") and uv.include_chat_title is not None
            else self.valves.include_chat_title
        )
        effective_include_timestamp = (
            uv.include_timestamp
            if hasattr(uv, "include_timestamp") and uv.include_timestamp is not None
            else self.valves.include_timestamp
        )
        effective_skip_confirm = uv.skip_confirmation or self.valves.skip_confirmation
        effective_debug = (
            uv.debug
            if hasattr(uv, "debug") and uv.debug is not None
            else self.valves.debug
        )
        effective_skip_mentions = (
            uv.skip_mentions
            if hasattr(uv, "skip_mentions") and uv.skip_mentions is not None
            else self.valves.skip_mentions
        )

        messages = body.get("messages", [])

        chat_title = body.get("title", "")
        if not chat_title:
            chat_id = body.get("chat_id")
            if chat_id and __request__:
                from open_webui.models.chats import Chats

                # 0.9.0 Await DB call
                fetched_title = await Chats.get_chat_title_by_id(chat_id)
                chat_title = fetched_title or "Untitled Chat"
            else:
                chat_title = "Untitled Chat"

        if not messages:
            await __event_emitter__(
                {
                    "type": "notification",
                    "data": {
                        "type": "warning",
                        "content": "No messages found to forward.",
                    },
                }
            )
            return None

        last_message = messages[-1]
        message_content = last_message.get("content", "")

        if not message_content:
            await __event_emitter__(
                {
                    "type": "notification",
                    "data": {
                        "type": "warning",
                        "content": "Empty message - nothing to forward.",
                    },
                }
            )
            return None

        await __event_emitter__(
            {"type": "status", "data": {"description": "Loading channels..."}}
        )

        try:
            # 0.9.0 Await DB call
            channels = await Channels.get_channels_by_user_id(user_id=__user__["id"])

            # 0.10.0 Settings moved from app.state.config to the database
            try:
                from open_webui.models.config import Config

                channels_enabled = await Config.get("channels.enable")
            except ImportError:
                channels_enabled = getattr(
                    __request__.app.state.config, "ENABLE_CHANNELS", False
                )

            if not channels_enabled:
                await __event_emitter__(
                    {"type": "status", "data": {"description": "", "done": True}}
                )
                await __event_emitter__(
                    {
                        "type": "notification",
                        "data": {
                            "type": "error",
                            "content": "Channels are not enabled on this instance.",
                        },
                    }
                )
                return None

            if not channels:
                await __event_emitter__(
                    {"type": "status", "data": {"description": "", "done": True}}
                )
                await __event_emitter__(
                    {
                        "type": "notification",
                        "data": {
                            "type": "error",
                            "content": "No channels found. You need access to at least one channel.",
                        },
                    }
                )
                return None

            selected_channel = None

            if effective_default_channel:
                for channel in channels:
                    if channel.id == effective_default_channel:
                        selected_channel = channel
                        break

                if not selected_channel:
                    await __event_emitter__(
                        {
                            "type": "notification",
                            "data": {
                                "type": "warning",
                                "content": f"Default channel not found. Please select manually.",
                            },
                        }
                    )

            additional_mentions = ""

            if selected_channel and effective_skip_confirm:
                selected_channels = [selected_channel]
            else:
                selected_channels = []

            dm_partner_names = {}

            if (
                selected_channel
                and effective_skip_confirm
                and selected_channel.type == "dm"
            ):
                partner = await lookup_dm_partner(
                    selected_channel.id, __user__["id"], effective_debug
                )
                if partner:
                    dm_partner_names[selected_channel.id] = partner

            num_channels = len(selected_channels)

            def format_channel_name(channel):
                name = channel.name.strip() if channel.name else ""
                if not name and channel.type == "dm":
                    partner = dm_partner_names.get(channel.id, "Unknown")
                    return f"DM with {partner}"
                if not name:
                    return "Unnamed"
                return name

            if not selected_channel or not effective_skip_confirm:
                displayed_channels = channels[:10]

                current_user_id = __user__.get("id") if __user__ else None
                dm_partner_names = {}

                if current_user_id:
                    for channel in displayed_channels:
                        if not channel.name and channel.type == "dm":
                            partner = await lookup_dm_partner(
                                channel.id, current_user_id, effective_debug
                            )
                            if partner:
                                dm_partner_names[channel.id] = partner
                    if effective_debug and dm_partner_names:
                        print(
                            f"[Forward to Channel] DM partners found: {dm_partner_names}"
                        )

                channel_list_numbered = "\n".join(
                    [
                        f"{i+1}. {format_channel_name(channel)}"
                        for i, channel in enumerate(displayed_channels)
                    ]
                )
                if len(channels) > 10:
                    channel_list_numbered += f"\n{len(displayed_channels) + 1}. ...and {len(channels) - 10} more"

                channel_list_numbered = f"```\n{channel_list_numbered}\n```"

                channel_response = await __event_call__(
                    {
                        "type": "input",
                        "data": {
                            "title": "Select Channel(s)",
                            "message": f"Forward message to channel:\n\n{channel_list_numbered}\n\nEnter one or more numbers, '-1', or 'all' to select all channels (e.g., '1', '1,3,5', '-1', or 'all')",
                            "placeholder": "Enter number(s), -1, or all",
                        },
                    }
                )

                if not isinstance(channel_response, str) or not channel_response:
                    await __event_emitter__(
                        {"type": "status", "data": {"description": "", "done": True}}
                    )
                    await __event_emitter__(
                        {
                            "type": "notification",
                            "data": {"type": "info", "content": "Action cancelled"},
                        }
                    )
                    return None

                selected_channels = []

                if channel_response.strip().lower() in ("-1", "all"):
                    selected_channels = channels
                else:
                    try:
                        channel_response = channel_response.replace(",", " ")
                        channel_parts = channel_response.split()

                        for part in channel_parts:
                            channel_index = int(part.strip()) - 1
                            if 0 <= channel_index < len(channels):
                                selected_channels.append(channels[channel_index])
                    except ValueError:
                        pass

                if not selected_channels:
                    await __event_emitter__(
                        {"type": "status", "data": {"description": "", "done": True}}
                    )
                    await __event_emitter__(
                        {
                            "type": "notification",
                            "data": {
                                "type": "error",
                                "content": f"Invalid selection. Please enter number(s) between 1 and {len(channels)}.",
                            },
                        }
                    )
                    return None

                channel_names = ", ".join(
                    [format_channel_name(ch) for ch in selected_channels]
                )
                num_channels = len(selected_channels)

                additional_mentions = ""

                if effective_skip_mentions:
                    mentions_response = True
                else:
                    mentions_response = await __event_call__(
                        {
                            "type": "input",
                            "data": {
                                "title": "Add @Mentions (Optional)",
                                "message": f'Forwarding to {channel_names}\n\nEnter @mentions to ping users or trigger models (e.g., `@username @modelname`). For names with spaces, use quotes: `@"John Doe"`. Leave empty for none.',
                                "placeholder": "@username @gpt-4",
                            },
                        }
                    )

                if mentions_response is False:
                    await __event_emitter__(
                        {"type": "status", "data": {"description": "", "done": True}}
                    )
                    await __event_emitter__(
                        {
                            "type": "notification",
                            "data": {"type": "info", "content": "Action cancelled"},
                        }
                    )
                    return None

                additional_mentions = ""
                if effective_debug:
                    print(
                        f"[Forward to Channel] mentions_response type: {type(mentions_response)}, value: '{mentions_response}'"
                    )
                if isinstance(mentions_response, str) and mentions_response:
                    mentions_text = mentions_response.strip()
                    if effective_debug:
                        print(f"[Forward to Channel] mentions_text: '{mentions_text}'")
                    if mentions_text:
                        if effective_debug:
                            print(
                                f"[Forward to Channel] Parsing mentions: '{mentions_text}'"
                            )

                        tokens = shlex.split(mentions_text)
                        if effective_debug:
                            print(f"[Forward to Channel] Parsed tokens: {tokens}")

                        from open_webui.utils.models import get_all_models

                        models_for_mentions = await get_all_models(__request__)

                        if effective_debug:
                            print(
                                f"[Forward to Channel] Pre-fetched {len(models_for_mentions)} models for mentions parsing"
                            )

                        dm_partner_results = {}
                        tokens_needing_dm_lookup = []

                        for token in tokens:
                            if token.startswith("@"):
                                if token.startswith('@"') and token.endswith('"'):
                                    name = token[2:-1]
                                elif token.startswith("@"):
                                    name = token[1:]
                                else:
                                    continue

                                for (
                                    channel_id,
                                    partner_name,
                                ) in dm_partner_names.items():
                                    if partner_name == f"@{name}":
                                        dm_partner_results[name] = partner_name
                                        break

                        async def process_token(token):
                            """Process a single token and return mention string."""
                            if not token.startswith("@"):
                                return f" {token}"

                            if token.startswith('@"') and token.endswith('"'):
                                name = token[2:-1]
                            elif token.startswith("@"):
                                name = token[1:]
                            else:
                                return None

                            if effective_debug:
                                print(
                                    f"[Forward to Channel] Processing token: '{name}'"
                                )

                            user_result, model_result = await asyncio.gather(
                                lookup_user_by_name(
                                    name, dm_partner_names, effective_debug
                                ),
                                lookup_model_by_name(
                                    name,
                                    __request__,
                                    effective_debug,
                                    models_for_mentions,
                                ),
                            )

                            mentions_str = ""
                            if user_result:
                                user_id, display_name = user_result
                                mentions_str += f" <@U:{user_id}|{display_name}>"

                            if model_result:
                                model_id, model_name = model_result
                                mention_str = f"<@M:{model_id}|{model_name}>"
                                if effective_debug:
                                    print(
                                        f"[Forward to Channel] Converting model to: {mention_str}"
                                    )
                                mentions_str += f" {mention_str}"

                            return mentions_str if mentions_str else None

                        results = await asyncio.gather(
                            *(process_token(token) for token in tokens)
                        )

                        for result in results:
                            if result:
                                additional_mentions += result

                        if effective_debug:
                            print(
                                f"[Forward to Channel] Final additional_mentions: '{additional_mentions}'"
                            )

            from datetime import datetime

            timestamp_str = ""
            if effective_include_timestamp:
                now = datetime.now()
                timestamp_str = f"  \n_Forwarded at {now.strftime('%Y-%m-%d %H:%M')}_"

            title_str = ""
            if effective_include_title:
                chat_id = body.get("chat_id")
                title_str = f"**From chat: [{chat_title}](/c/{chat_id})**  \n"

            clean_content = message_content
            if "<!-- action_button_start -->" in message_content:
                clean_content = message_content.split("<!-- action_button_start -->")[0]

            clean_content = await convert_at_mentions(
                __request__, clean_content, __user__
            )

            # Channels render blank lines inline, and up to 0.11.4 a single
            # newline too, so two trailing spaces mark each line break
            message_line = f"{additional_mentions.strip()} {clean_content.strip()}"
            formatted_message = f"{title_str}{message_line.strip()}{timestamp_str}"

            from open_webui.internal.db import get_db
            from open_webui.models.users import Users
            from open_webui.utils.models import get_all_models, get_filtered_models

            user_id = __user__.get("id") if __user__ else None
            # 0.9.0 Await DB call
            user_obj = await Users.get_user_by_id(user_id) if user_id else None

            all_models = await get_all_models(__request__, user=user_obj)

            # Use inspect for get_filtered_models 0.9.0 failsafe
            filtered_models_raw = get_filtered_models(all_models, user_obj)
            filtered_models = (
                await filtered_models_raw
                if inspect.isawaitable(filtered_models_raw)
                else filtered_models_raw
            )

            if effective_debug:
                print(
                    f"[Forward to Channel] Pre-computed {len(filtered_models)} filtered models"
                )

            if num_channels > 1:
                await __event_emitter__(
                    {
                        "type": "status",
                        "data": {
                            "description": f"Posting to {num_channels} channels...",
                        },
                    }
                )

            channel_tasks = [
                post_to_channel(
                    channel=selected_channel,
                    formatted_message=formatted_message,
                    user_id=user_id,
                    user_obj=user_obj,
                    request=__request__,
                    effective_debug=effective_debug,
                    filtered_models=filtered_models,
                )
                for selected_channel in selected_channels
            ]

            results = await asyncio.gather(*channel_tasks, return_exceptions=True)

            forwarded_channels = []
            for result in results:
                if isinstance(result, tuple):
                    forwarded_channels.append(result)
                elif effective_debug and isinstance(result, Exception):
                    print(f"[Forward to Channel] Channel post failed: {result}")

            await __event_emitter__(
                {
                    "type": "status",
                    "data": {"description": "Message forwarded", "done": True},
                }
            )

            notification_parts = []
            for selected_channel in forwarded_channels:
                if not selected_channel[0].name and selected_channel[0].type == "dm":
                    notification_channel_name = dm_partner_names.get(
                        selected_channel[0].id, "Unknown"
                    )
                    notification_parts.append(f"DM with {notification_channel_name}")
                else:
                    notification_parts.append(f"#{selected_channel[0].name}")

            if len(notification_parts) == 1:
                notification_content = f"Message forwarded to {notification_parts[0]}"
            elif len(notification_parts) == 2:
                notification_content = f"Message forwarded to {notification_parts[0]} and {notification_parts[1]}"
            else:
                notification_content = f"Message forwarded to {', '.join(notification_parts[:-1])} and {notification_parts[-1]}"

            await __event_emitter__(
                {
                    "type": "notification",
                    "data": {
                        "type": "success",
                        "content": notification_content,
                    },
                }
            )

            return None

        except Exception as e:
            await __event_emitter__(
                {"type": "status", "data": {"description": "", "done": True}}
            )
            await __event_emitter__(
                {
                    "type": "notification",
                    "data": {"type": "error", "content": f"Error: {str(e)}"},
                }
            )
            return None
