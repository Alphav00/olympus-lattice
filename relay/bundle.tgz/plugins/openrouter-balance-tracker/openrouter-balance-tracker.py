"""
title: OpenRouter Complete Cost & Token Tracker
author: Colin Jones + Deepseek
version: 1.0.0
required_open_webui_version: 0.5.0
license: MIT
description: Tracks OpenRouter usage with token counts, costs, timing, and balance. Implements comprehensive token tracking.
"""

import logging
import time
import asyncio
from typing import Dict, Optional, Callable, Any
import aiohttp
import requests
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class Filter:
    class Valves(BaseModel):
        openrouter_api_key: str = Field(
            default="",
            description="Your OpenRouter API key (sk-or-...). Get it from https://openrouter.ai/keys",
        )
        show_tokens: bool = Field(
            default=True,
            description="Display detailed token counts (prompt/completion/total)",
        )
        show_cost: bool = Field(
            default=True, description="Display cost in credits for each message"
        )
        show_timing: bool = Field(
            default=True, description="Display elapsed time for each message"
        )
        show_balance: bool = Field(
            default=True, description="Display remaining credits balance"
        )
        show_reasoning_tokens: bool = Field(
            default=True, description="Display reasoning tokens if available"
        )
        show_cached_tokens: bool = Field(
            default=True, description="Display cache read/write token information"
        )
        currency_symbol: str = Field(
            default="$",
            description="Currency symbol to use (default: $)",
            pattern="^[\\$€£¥₹₿💎]$",
        )
        token_precision: int = Field(
            default=0,
            description="Token display precision (0 for whole numbers)",
            ge=0,
            le=2,
        )
        cost_precision: int = Field(
            default=6, description="Cost display precision", ge=2, le=8
        )
        debug_mode: bool = Field(
            default=False, description="Enable debug logging to see API responses"
        )
        enable_caching: bool = Field(
            default=True, description="Cache balance for 30 seconds to reduce API calls"
        )

    def __init__(self):
        self.valves = self.Valves()
        self.start_time = None
        self.is_openrouter = False
        self.balance_cache = {
            "value": None,
            "timestamp": 0,
            "error": None,
            "raw_response": None,
        }
        self.balance_cache_duration = 30

    async def inlet(
        self,
        body: Dict,
        __model__: Optional[dict] = None,
    ) -> Dict:
        """Called before sending request to model"""
        model_id = __model__.get("id", "") if __model__ else ""

        # Check if using OpenRouter (models with / or openrouter in name)
        if "/" in model_id or "openrouter" in model_id.lower():
            self.is_openrouter = True
            self.start_time = time.time()

        return body

    async def _fetch_openrouter_balance(self) -> Optional[float]:
        """Fetch balance from OpenRouter API"""
        if not self.valves.openrouter_api_key:
            logger.warning("No OpenRouter API key provided")
            return None

        api_url = "https://openrouter.ai/api/v1/credits"
        headers = {"Authorization": f"Bearer {self.valves.openrouter_api_key}"}

        try:
            response = requests.get(api_url, headers=headers, timeout=10)
            response.raise_for_status()

            credit_data = response.json()

            if self.valves.debug_mode:
                logger.debug(f"Balance API response: {credit_data}")
                self.balance_cache["raw_response"] = credit_data

            # Parse response
            remaining_credits = None

            # Format 1: {"data": {"total_credits": X, "total_usage": Y}}
            if "data" in credit_data and isinstance(credit_data["data"], dict):
                data = credit_data["data"]
                total_credits = data.get("total_credits", 0.0)
                total_usage = data.get("total_usage", 0.0)
                remaining_credits = total_credits - total_usage

            # Format 2: {"credits": X}
            elif "credits" in credit_data:
                remaining_credits = float(credit_data["credits"])

            # Format 3: Direct value
            elif len(credit_data) == 1:
                for key, value in credit_data.items():
                    if isinstance(value, (int, float)):
                        remaining_credits = float(value)
                        break

            if remaining_credits is None:
                logger.error(f"Could not parse balance from response: {credit_data}")

            return remaining_credits

        except requests.exceptions.RequestException as e:
            error_msg = f"Balance API request failed: {e}"
            if hasattr(e, "response") and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.json()
                    error_msg = f"HTTP {status_code}: {error_body}"
                except:
                    error_msg = f"HTTP {status_code}: {e.response.text}"

            logger.error(error_msg)
            return None
        except Exception as e:
            logger.error(f"Unexpected error fetching balance: {e}")
            return None

    async def _get_balance(self) -> Optional[float]:
        """Get balance with caching"""
        current_time = time.time()

        # Check cache if enabled and valid
        if (
            self.valves.enable_caching
            and self.balance_cache["value"] is not None
            and current_time - self.balance_cache["timestamp"]
            < self.balance_cache_duration
        ):
            return self.balance_cache["value"]

        # Fetch fresh balance
        balance = await self._fetch_openrouter_balance()

        # Update cache
        if balance is not None:
            self.balance_cache = {
                "value": balance,
                "timestamp": current_time,
                "error": None,
                "raw_response": self.balance_cache.get("raw_response"),
            }
        else:
            if self.balance_cache["value"] is None:
                self.balance_cache["error"] = "Failed to fetch balance"

        return balance

    def _extract_usage_details(self, body: Dict) -> Dict:
        """
        Extract detailed usage information from OpenRouter response.
        Similar to Claude's cost tracking API [platform.claude.com](https://platform.claude.com/docs/en/agent-sdk/cost-tracking)
        """
        usage_info = {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "cost": 0.0,
            "reasoning_tokens": 0,
            "cached_tokens": 0,
            "cache_write_tokens": 0,
            "has_usage": False,
        }

        # First, check for usage in the response body
        usage = body.get("usage")

        # If not in root, check choices
        if not usage and body.get("choices"):
            for choice in body["choices"]:
                if choice.get("usage"):
                    usage = choice["usage"]
                    break

        # If still not found, check messages
        if not usage and body.get("messages"):
            messages = body["messages"]
            if messages and isinstance(messages[-1], dict):
                usage = messages[-1].get("usage")

        # If we found usage data, extract it
        if usage:
            usage_info["has_usage"] = True

            # Basic token counts
            usage_info["prompt_tokens"] = usage.get("prompt_tokens", 0)
            usage_info["completion_tokens"] = usage.get("completion_tokens", 0)
            usage_info["total_tokens"] = usage.get("total_tokens", 0)

            # Cost information
            usage_info["cost"] = usage.get("cost", 0.0)

            # Detailed token information
            prompt_details = usage.get("prompt_tokens_details", {})
            completion_details = usage.get("completion_tokens_details", {})

            usage_info["reasoning_tokens"] = completion_details.get(
                "reasoning_tokens", 0
            )
            usage_info["cached_tokens"] = prompt_details.get("cached_tokens", 0)
            usage_info["cache_write_tokens"] = prompt_details.get(
                "cache_write_tokens", 0
            )

        # Debug logging
        if self.valves.debug_mode:
            logger.debug(f"Extracted usage info: {usage_info}")
            if not usage_info["has_usage"]:
                logger.debug(f"Full response body keys: {list(body.keys())}")
                if "choices" in body:
                    logger.debug(
                        f"First choice keys: {list(body['choices'][0].keys()) if body['choices'] else 'No choices'}"
                    )

        return usage_info

    async def outlet(
        self,
        body: Dict,
        __event_emitter__: Optional[Callable] = None,
    ) -> Dict:
        """Called after receiving response from model"""
        if not self.is_openrouter or not self.start_time:
            return body

        try:
            # Show calculating status
            if __event_emitter__:
                await __event_emitter__(
                    {
                        "type": "status",
                        "data": {
                            "description": "Calculating costs and stats...",
                            "done": False,
                        },
                    }
                )

            # Emojis for display
            EMOJI = {
                "tokens": "🪙",
                "time": "⏱️",
                "speed": "⚡",
                "cost": "💸",
                "balance": "💰",
                "prompt": "📥",
                "completion": "📤",
                "reasoning": "🧠",
                "cached": "💾",
                "warning": "⚠️",
                "error": "❌",
            }

            # Extract usage information
            usage_info = self._extract_usage_details(body)

            if self.valves.debug_mode:
                logger.debug(f"Usage extraction result: {usage_info}")

            # Calculate timing
            end_time = time.time()
            elapsed_time = end_time - self.start_time
            tokens_per_sec = (
                usage_info["total_tokens"] / elapsed_time if elapsed_time > 0 else 0
            )

            # Build status message parts
            status_parts = []

            # TOKEN INFORMATION - Critical fix for missing token display
            if self.valves.show_tokens:
                if usage_info["has_usage"] and usage_info["total_tokens"] > 0:
                    # Format token counts
                    token_info = f"{EMOJI['tokens']} {usage_info['total_tokens']:,}t"

                    # Add prompt/completion breakdown
                    if (
                        usage_info["prompt_tokens"] > 0
                        or usage_info["completion_tokens"] > 0
                    ):
                        token_info += f" ({EMOJI['prompt']}{usage_info['prompt_tokens']:,}/{EMOJI['completion']}{usage_info['completion_tokens']:,})"

                    # Add reasoning tokens if available
                    if (
                        self.valves.show_reasoning_tokens
                        and usage_info["reasoning_tokens"] > 0
                    ):
                        token_info += (
                            f" ({EMOJI['reasoning']}{usage_info['reasoning_tokens']:,})"
                        )

                    # Add cache information
                    if self.valves.show_cached_tokens:
                        cache_parts = []
                        if usage_info["cached_tokens"] > 0:
                            cache_parts.append(f"{usage_info['cached_tokens']:,}r")
                        if usage_info["cache_write_tokens"] > 0:
                            cache_parts.append(f"{usage_info['cache_write_tokens']:,}w")
                        if cache_parts:
                            token_info += f" ({EMOJI['cached']}{'/'.join(cache_parts)})"

                    status_parts.append(token_info)
                else:
                    # Show token warning if no usage data found
                    status_parts.append(f"{EMOJI['warning']} Tokens: N/A")

            # COST INFORMATION - Critical fix for missing cost display
            if self.valves.show_cost:
                if usage_info["cost"] > 0:
                    # Format cost with appropriate precision
                    if usage_info["cost"] < 0.0001:
                        cost_str = f"{usage_info['cost']:.8f}".rstrip("0").rstrip(".")
                    else:
                        cost_str = f"{usage_info['cost']:.{self.valves.cost_precision}f}".rstrip(
                            "0"
                        ).rstrip(
                            "."
                        )

                    cost_display = (
                        f"{EMOJI['cost']} {self.valves.currency_symbol}{cost_str}"
                    )
                    status_parts.append(cost_display)
                elif usage_info["has_usage"]:
                    # Has usage data but cost is 0
                    status_parts.append(
                        f"{EMOJI['cost']} {self.valves.currency_symbol}0"
                    )
                else:
                    # No cost information available
                    status_parts.append(f"{EMOJI['warning']} Cost: N/A")

            # TIMING INFORMATION
            if self.valves.show_timing and elapsed_time > 0:
                timing_parts = [f"{EMOJI['time']} {elapsed_time:.1f}s"]

                if tokens_per_sec > 0:
                    timing_parts.append(f"{EMOJI['speed']} {tokens_per_sec:.0f}t/s")

                status_parts.append(" ".join(timing_parts))

            # BALANCE INFORMATION
            if self.valves.show_balance:
                balance = await self._get_balance()

                if balance is not None:
                    # Format balance with appropriate precision
                    if balance < 0.0001:
                        balance_str = f"{balance:.8f}".rstrip("0").rstrip(".")
                    else:
                        balance_str = (
                            f"{balance:.{self.valves.cost_precision}f}".rstrip(
                                "0"
                            ).rstrip(".")
                        )

                    balance_display = (
                        f"{EMOJI['balance']} {self.valves.currency_symbol}{balance_str}"
                    )

                    # Add warning for very low balance
                    if balance < 0.1:
                        balance_display = f"{EMOJI['warning']}{balance_display}"

                    status_parts.append(balance_display)
                else:
                    # Balance fetch failed
                    if self.balance_cache["value"] is not None:
                        cached_balance = self.balance_cache["value"]
                        cached_str = (
                            f"{cached_balance:.{self.valves.cost_precision}f}".rstrip(
                                "0"
                            ).rstrip(".")
                        )
                        status_parts.append(
                            f"{EMOJI['warning']} {self.valves.currency_symbol}{cached_str} (cached)"
                        )
                    else:
                        status_parts.append(f"{EMOJI['error']} Balance: N/A")

            # Send final status
            if status_parts and __event_emitter__:
                status_message = " • ".join(status_parts)

                # Debug logging
                if self.valves.debug_mode:
                    logger.debug(f"Status message: {status_message}")
                    logger.debug(f"Usage data available: {usage_info['has_usage']}")
                    logger.debug(f"Response structure: {list(body.keys())}")

                await __event_emitter__(
                    {
                        "type": "status",
                        "data": {"description": status_message, "done": True},
                    }
                )

            # Debug info for troubleshooting
            if self.valves.debug_mode and not usage_info["has_usage"]:
                logger.warning("No usage data found in response!")
                logger.warning(f"Response keys: {list(body.keys())}")
                if "choices" in body and body["choices"]:
                    logger.warning(
                        f"First choice keys: {list(body['choices'][0].keys())}"
                    )
                    logger.warning(f"First choice content: {body['choices'][0]}")

        except Exception as e:
            logger.error(f"Error in outlet: {str(e)}", exc_info=True)
            if __event_emitter__:
                await __event_emitter__(
                    {
                        "type": "status",
                        "data": {
                            "description": f"{EMOJI.get('error', '❌')} Error calculating stats",
                            "done": True,
                        },
                    }
                )

        return body
