"""
title: Ask User
author: ichrist
version: 2.1.0
license: MIT
description: Lets the LLM ask 1-5 clarifying questions in ONE themed modal (choice cards, multi-select, "Other", free text, keyboard shortcuts). Falls back to plain input dialogs if the custom modal can't run.
"""

import json
from typing import Any, List, Optional

from pydantic import BaseModel, Field

# --------------------------------------------------------------------------- #
# Browser-side modal. Runs via the Open WebUI `execute` event, which evaluates
# this as an async function body in the page and sends the returned value back
# to Python. __CFG__ is replaced with a JSON blob (ASCII-escaped, so safe).
# All dynamic text goes through textContent, never innerHTML.
# --------------------------------------------------------------------------- #
_JS = r"""
return new Promise((resolve) => {
  let cleanup = () => {};
  const fail = (e) => {
    try { cleanup(); } catch (_) {}
    resolve({ error: String((e && e.message) || e) });
  };
  try {
    const CFG = __CFG__;
    const Q = CFG.questions;
    const N = Q.length;

    // ---- theme ----------------------------------------------------------
    const root = document.documentElement;
    const prefersDark = !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    const dark = CFG.theme === 'dark' ||
      (CFG.theme === 'auto' && (root.classList.contains('dark') || (!root.classList.contains('light') && prefersDark)));
    const P = dark
      ? { bg: '#171717', surface: '#202020', border: '#343434', text: '#ececec', muted: '#9a9a9a', hover: '#2b2b2b' }
      : { bg: '#ffffff', surface: '#f7f7f8', border: '#e2e2e5', text: '#1a1a1a', muted: '#6b6b73', hover: '#efeff1' };

    document.querySelectorAll('#owa-overlay, #owa-style').forEach((n) => n.remove());

    const style = document.createElement('style');
    style.id = 'owa-style';
    style.textContent = `
.owa-overlay{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.55);backdrop-filter:blur(4px);animation:owa-fade .15s ease-out}
.owa-card{width:100%;max-width:var(--width);max-height:calc(100vh - 32px);font-size:calc(16px*var(--fs));display:flex;flex-direction:column;background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:var(--radius);box-shadow:0 24px 64px rgba(0,0,0,.35);overflow:hidden;animation:owa-pop .18s ease-out}
.owa-head{padding:18px 22px 0}
.owa-meta{display:flex;align-items:center;gap:10px;font-size:.75em;color:var(--muted)}
.owa-chip{padding:2px 9px;border-radius:999px;background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent);font-weight:600}
.owa-bar{display:flex;gap:5px;margin-top:12px}
.owa-seg{flex:1;height:4px;border-radius:2px;background:var(--border);transition:background .2s}
.owa-seg.done{background:var(--accent)}
.owa-seg.cur{background:color-mix(in srgb,var(--accent) 55%,var(--border))}
.owa-body{padding:16px 22px;overflow-y:auto}
.owa-q{font-size:1.125em;font-weight:600;line-height:1.35;margin:0 0 4px}
.owa-hint{font-size:.78em;color:var(--muted);margin:0 0 14px}
.owa-opts{display:flex;flex-direction:column;gap:8px}
.owa-opt{display:flex;align-items:flex-start;gap:12px;width:100%;box-sizing:border-box;text-align:start;padding:12px 14px;border-radius:12px;border:1px solid var(--border);background:var(--surface);color:inherit;cursor:pointer;font:inherit;transition:border-color .12s,background .12s}
.owa-opt:hover{background:var(--hover)}
.owa-opt:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.owa-opt.sel{border-color:var(--accent);background:color-mix(in srgb,var(--accent) 12%,var(--surface))}
.owa-key{flex:none;width:1.4em;height:1.4em;border-radius:6px;border:1px solid var(--border);font-size:.69em;display:flex;align-items:center;justify-content:center;color:var(--muted);margin-top:1px}
.owa-opt.sel .owa-key{background:var(--accent);border-color:var(--accent);color:#fff}
.owa-txt{flex:1;min-width:0}
.owa-label{font-size:.9em;font-weight:500}
.owa-desc{font-size:.78em;color:var(--muted);margin-top:2px;line-height:1.4}
.owa-rec{flex:none;align-self:center;font-size:.69em;padding:2px 8px;border-radius:999px;background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent);font-weight:600}
.owa-other{cursor:text;align-items:center}
.owa-input{width:100%;box-sizing:border-box;padding:10px 12px;border-radius:10px;border:1px solid var(--border);background:var(--bg);color:inherit;font:inherit;font-size:.875em;resize:vertical}
.owa-other .owa-input{border:none;background:transparent;padding:2px 0;outline:none}
.owa-input:focus{outline:2px solid var(--accent);outline-offset:0}
.owa-foot{display:flex;align-items:center;gap:8px;padding:12px 22px 18px}
.owa-sp{flex:1}
.owa-btn{padding:9px 16px;border-radius:10px;border:1px solid var(--border);background:transparent;color:inherit;font:inherit;font-size:.875em;cursor:pointer}
.owa-btn:hover{background:var(--hover)}
.owa-btn:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.owa-btn.pri{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600}
.owa-btn.pri:hover{filter:brightness(1.08)}
.owa-btn.ghost{border-color:transparent;color:var(--muted)}
.owa-btn[disabled]{opacity:.4;cursor:default;filter:none}
.owa-kbd{font-size:.69em;color:var(--muted);padding:0 22px 14px}
.owa-overlay.nodim{background:transparent}
.owa-overlay.noblur{backdrop-filter:none}
.owa-overlay.bottom{align-items:flex-end}
@keyframes owa-fade{from{opacity:0}to{opacity:1}}
@keyframes owa-pop{from{opacity:0;transform:translateY(8px) scale(.98)}to{opacity:1;transform:none}}
@media (max-width:640px){.owa-overlay{align-items:flex-end;padding:0}.owa-card{max-width:none;border-radius:var(--radius) var(--radius) 0 0}.owa-kbd{display:none}}
@media (prefers-reduced-motion:reduce){.owa-overlay,.owa-card{animation:none}}
`;
    if (CFG.customCss) style.textContent += '\n' + CFG.customCss;
    document.head.appendChild(style);

    // ---- helpers --------------------------------------------------------
    const h = (tag, cls, text) => {
      const e = document.createElement(tag);
      if (cls) e.className = cls;
      if (text != null) { e.textContent = text; e.dir = 'auto'; }
      return e;
    };

    // ---- state ----------------------------------------------------------
    const A = Q.map(() => ({ sel: new Set(), other: '' }));
    let step = 0;
    let closed = false;
    let timer = null;
    const prevFocus = document.activeElement;
    let optEls = [];
    let otherInput = null;

    const overlay = h('div', 'owa-overlay');
    overlay.id = 'owa-overlay';
    overlay.style.setProperty('--bg', P.bg);
    overlay.style.setProperty('--surface', P.surface);
    overlay.style.setProperty('--border', P.border);
    overlay.style.setProperty('--text', P.text);
    overlay.style.setProperty('--muted', P.muted);
    overlay.style.setProperty('--hover', P.hover);
    overlay.style.setProperty('--accent', CFG.accent);
    overlay.style.setProperty('--radius', CFG.radius + 'px');
    overlay.style.setProperty('--width', CFG.width + 'px');
    overlay.style.setProperty('--fs', String(CFG.fontScale));
    if (!CFG.dim) overlay.classList.add('nodim');
    if (!CFG.blur) overlay.classList.add('noblur');
    if (CFG.position === 'bottom') overlay.classList.add('bottom');

    const card = h('div', 'owa-card');
    card.setAttribute('role', 'dialog');
    card.setAttribute('aria-modal', 'true');
    card.setAttribute('aria-label', 'Clarifying questions');
    const head = h('div', 'owa-head');
    const body = h('div', 'owa-body');
    const foot = h('div', 'owa-foot');
    const kbd = h('div', 'owa-kbd', 'Press 1-9 to choose, Enter to continue, Esc to dismiss');
    card.append(head, body, foot);
    if (CFG.hints) card.appendChild(kbd);
    overlay.appendChild(card);

    const btnCancel = h('button', 'owa-btn ghost', 'Dismiss');
    const btnBack = h('button', 'owa-btn', 'Back');
    const btnNext = h('button', 'owa-btn pri', 'Next');
    [btnCancel, btnBack, btnNext].forEach((b) => b.setAttribute('type', 'button'));
    foot.append(btnCancel, h('div', 'owa-sp'), btnBack, btnNext);

    const answered = (i) => A[i].sel.size > 0 || A[i].other.trim() !== '';

    const refresh = () => {
      const q = Q[step];
      optEls.forEach((el, i) => {
        const on = A[step].sel.has(i);
        el.classList.toggle('sel', on);
        el.setAttribute('aria-checked', on ? 'true' : 'false');
      });
      const last = step === N - 1;
      const has = answered(step);
      btnBack.style.display = step === 0 ? 'none' : '';
      btnNext.textContent = has ? (last ? 'Send answers' : 'Next') : (last ? 'Skip & send' : 'Skip');
      btnNext.disabled = !has && !CFG.allowSkip;
    };

    const finish = (result) => {
      if (closed) return;
      closed = true;
      cleanup();
      resolve(result);
    };

    const buildResult = () => ({
      cancelled: false,
      answers: Q.map((q, i) => ({
        question: q.question,
        selected: Array.from(A[i].sel).sort((x, y) => x - y).map((j) => q.options[j].label),
        text: A[i].other.trim(),
      })),
    });

    const next = () => {
      if (btnNext.disabled) return;
      if (step < N - 1) { step += 1; render(); } else { finish(buildResult()); }
    };
    const back = () => { if (step > 0) { step -= 1; render(); } };

    const pick = (i) => {
      const q = Q[step];
      const a = A[step];
      if (q.multi) {
        if (a.sel.has(i)) a.sel.delete(i); else a.sel.add(i);
      } else if (a.sel.has(i)) {
        a.sel.delete(i);
      } else {
        a.sel.clear(); a.sel.add(i);
        a.other = '';
        if (otherInput) otherInput.value = '';
      }
      refresh();
      if (!q.multi && CFG.autoAdvance && a.sel.has(i)) {
        const s = step;
        setTimeout(() => { if (!closed && step === s) next(); }, 240);
      }
    };

    // ---- render one question -------------------------------------------
    const render = () => {
      const q = Q[step];
      optEls = [];
      otherInput = null;
      head.replaceChildren();
      body.replaceChildren();

      const meta = h('div', 'owa-meta');
      if (q.header) meta.appendChild(h('span', 'owa-chip', q.header));
      meta.appendChild(h('span', '', 'Question ' + (step + 1) + ' of ' + N));
      head.appendChild(meta);
      if (N > 1) {
        const bar = h('div', 'owa-bar');
        for (let i = 0; i < N; i++) bar.appendChild(h('div', 'owa-seg' + (i < step ? ' done' : (i === step ? ' cur' : ''))));
        head.appendChild(bar);
      }

      body.appendChild(h('h3', 'owa-q', q.question));

      if (!q.options.length) {
        body.appendChild(h('p', 'owa-hint', 'Type your answer (Shift+Enter for a new line).'));
        const ta = h('textarea', 'owa-input');
        ta.rows = 3;
        ta.placeholder = q.placeholder || 'Your answer...';
        ta.value = A[step].other;
        ta.dir = 'auto';
        ta.addEventListener('input', () => { A[step].other = ta.value; refresh(); });
        body.appendChild(ta);
        otherInput = ta;
      } else {
        body.appendChild(h('p', 'owa-hint', q.multi ? 'Select all that apply.' : 'Select one.'));
        const list = h('div', 'owa-opts');
        list.setAttribute('role', q.multi ? 'group' : 'radiogroup');
        q.options.forEach((o, i) => {
          const b = h('button', 'owa-opt');
          b.setAttribute('type', 'button');
          b.setAttribute('role', q.multi ? 'checkbox' : 'radio');
          b.appendChild(h('span', 'owa-key', i < 9 ? String(i + 1) : ''));
          const t = h('span', 'owa-txt');
          t.appendChild(h('div', 'owa-label', o.label));
          if (o.description) t.appendChild(h('div', 'owa-desc', o.description));
          b.appendChild(t);
          if (o.recommended && CFG.showRecommended) b.appendChild(h('span', 'owa-rec', 'Recommended'));
          b.addEventListener('click', () => pick(i));
          list.appendChild(b);
          optEls.push(b);
        });
        if (q.allowOther) {
          const row = h('div', 'owa-opt owa-other');
          row.appendChild(h('span', 'owa-key', q.options.length < 9 ? String(q.options.length + 1) : '+'));
          const inp = h('input', 'owa-input');
          inp.type = 'text';
          inp.dir = 'auto';
          inp.placeholder = 'Other: type your own answer';
          inp.value = A[step].other;
          inp.addEventListener('input', () => {
            A[step].other = inp.value;
            if (!q.multi && inp.value.trim() !== '') A[step].sel.clear();
            refresh();
          });
          row.addEventListener('click', () => inp.focus());
          row.appendChild(inp);
          list.appendChild(row);
          otherInput = inp;
        }
        body.appendChild(list);
      }

      refresh();
      const firstSel = optEls.find((el) => el.classList.contains('sel'));
      const target = firstSel || optEls[0] || otherInput;
      if (target) target.focus();
    };

    // ---- events ---------------------------------------------------------
    const onKey = (ev) => {
      if (closed) return;
      const t = ev.target;
      const typing = !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA');
      if (ev.key === 'Escape') {
        ev.preventDefault(); ev.stopPropagation();
        finish({ cancelled: true, reason: 'dismissed' });
        return;
      }
      if (ev.key === 'Tab' && !overlay.contains(document.activeElement)) {
        ev.preventDefault();
        (optEls[0] || otherInput || btnNext).focus();
        return;
      }
      if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) {
        if (t && t.tagName === 'BUTTON') return;
        ev.preventDefault(); ev.stopPropagation();
        next();
        return;
      }
      if (!typing && /^[1-9]$/.test(ev.key)) {
        const idx = parseInt(ev.key, 10) - 1;
        if (idx < optEls.length) { ev.preventDefault(); ev.stopPropagation(); pick(idx); }
        else if (idx === optEls.length && otherInput) { ev.preventDefault(); ev.stopPropagation(); otherInput.focus(); }
      }
    };

    btnCancel.addEventListener('click', () => finish({ cancelled: true, reason: 'dismissed' }));
    btnBack.addEventListener('click', back);
    btnNext.addEventListener('click', next);
    document.addEventListener('keydown', onKey, true);

    cleanup = () => {
      document.removeEventListener('keydown', onKey, true);
      if (timer) clearTimeout(timer);
      overlay.remove();
      style.remove();
      try { if (prevFocus && prevFocus.focus) prevFocus.focus(); } catch (_) {}
    };

    if (CFG.timeout > 0) {
      timer = setTimeout(() => finish({ cancelled: true, reason: 'timeout' }), CFG.timeout * 1000);
    }

    document.body.appendChild(overlay);
    render();
  } catch (e) {
    fail(e);
  }
});
"""


class Tools:
    class Valves(BaseModel):
        max_questions: int = Field(
            default=5, ge=1, le=10, description="Hard cap on questions per call."
        )
        show_recommended: bool = Field(
            default=True,
            description="Show a 'Recommended' badge, but only on options the model explicitly flagged. Turn off to hide badges entirely.",
        )
        allow_skip: bool = Field(
            default=True,
            description="Let users skip questions they don't want to answer.",
        )
        timeout_seconds: int = Field(
            default=0,
            ge=0,
            description="Auto-dismiss the modal after N seconds (0 = wait forever).",
        )
        accent_color: str = Field(
            default="#6366f1", description="Default accent color (CSS hex)."
        )
        fallback_to_input_dialogs: bool = Field(
            default=True,
            description="If the custom modal fails to run, fall back to plain Open WebUI input dialogs.",
        )

    class UserValves(BaseModel):
        theme: str = Field(
            default="auto", description="Modal theme: auto, light, or dark."
        )
        accent_color: str = Field(
            default="", description="Your own accent color (CSS hex). Blank = default."
        )
        auto_advance: bool = Field(
            default=True,
            description="Single-choice questions jump to the next question as soon as you pick an option.",
        )
        position: str = Field(
            default="center", description="Where the modal sits: center or bottom."
        )
        width_px: int = Field(default=580, description="Modal width in px (360-900).")
        corner_radius: int = Field(
            default=20, description="Corner roundness in px (0-32)."
        )
        font_scale: float = Field(
            default=1.0, description="Text size multiplier (0.8-1.5)."
        )
        dim_background: bool = Field(
            default=True, description="Dim the page behind the modal."
        )
        blur_background: bool = Field(
            default=True, description="Blur the page behind the modal."
        )
        show_key_hints: bool = Field(
            default=True, description="Show the keyboard-shortcut hint line."
        )
        custom_css: str = Field(
            default="",
            description="Your own CSS, appended last. Classes: .owa-overlay .owa-card .owa-head .owa-body .owa-q .owa-opt .owa-opt.sel .owa-label .owa-desc .owa-rec .owa-key .owa-btn .owa-btn.pri. Colors are CSS vars: --bg --surface --border --text --muted --hover --accent.",
        )

    def __init__(self):
        self.valves = self.Valves()
        # This tool is an interaction, not a source; skip the auto citation card.
        self.citation = False

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    async def _emit(emitter, payload: dict) -> None:
        if emitter:
            try:
                await emitter(payload)
            except Exception:
                pass

    @staticmethod
    def _normalize(raw: Any, limit: int) -> List[dict]:
        """Accept strings, dicts, or a JSON string; return clean question dicts."""
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except Exception:
                raw = [raw]
        if isinstance(raw, dict):
            raw = [raw]
        if not isinstance(raw, list):
            return []

        out: List[dict] = []
        for item in raw:
            if len(out) >= limit:
                break
            if isinstance(item, str):
                item = {"question": item}
            if not isinstance(item, dict):
                continue
            text = str(
                item.get("question") or item.get("text") or item.get("prompt") or ""
            ).strip()
            if not text:
                continue

            options: List[dict] = []
            seen_rec = False
            for o in item.get("options") or item.get("choices") or []:
                if isinstance(o, str):
                    o = {"label": o}
                if not isinstance(o, dict):
                    continue
                label = str(
                    o.get("label") or o.get("title") or o.get("value") or ""
                ).strip()
                if not label or label.lower() in ("other", "something else"):
                    continue  # the modal adds its own "Other" row
                rec = bool(o.get("recommended")) and not seen_rec  # at most one
                seen_rec = seen_rec or rec
                options.append(
                    {
                        "label": label[:120],
                        "description": str(o.get("description") or "").strip()[:200],
                        "recommended": rec,
                    }
                )
                if len(options) >= 8:
                    break

            out.append(
                {
                    "question": text[:300],
                    "header": str(item.get("header") or "").strip()[:24],
                    "options": options,
                    "multi": bool(item.get("multi") or item.get("multiple")),
                    "allowOther": bool(item.get("allow_other", True)),
                    "placeholder": str(item.get("placeholder") or "")[:80],
                }
            )
        return out

    @staticmethod
    def _format(qs: List[dict], answers: List[dict]) -> str:
        lines = ["USER CLARIFICATION RECEIVED:"]
        for i, (q, a) in enumerate(zip(qs, answers), 1):
            parts = list(a.get("selected") or [])
            text = (a.get("text") or "").strip()
            if text:
                parts.append(f"Other: {text}" if q["options"] else text)
            lines.append(
                f"\nQ{i}: {q['question']}\nA{i}: " + ("; ".join(parts) or "[skipped]")
            )
        lines.append(
            "\nUse these answers to proceed. For skipped questions, pick a sensible "
            "default and state the assumption briefly. Do not ask the same questions again."
        )
        return "\n".join(lines)

    async def _fallback(self, qs: List[dict], __event_call__) -> Any:
        """Plain Open WebUI input dialogs, one per question."""
        answers = []
        for i, q in enumerate(qs, 1):
            msg = q["question"]
            if q["options"]:
                msg += "\n\nOptions: " + " | ".join(o["label"] for o in q["options"])
            resp = await __event_call__(
                {
                    "type": "input",
                    "data": {
                        "title": f"Question {i} of {len(qs)}",
                        "message": msg,
                        "placeholder": "Type an option or your own answer",
                    },
                }
            )
            if isinstance(resp, dict) and resp.get("error"):
                return {"error": resp["error"]}
            if resp is False or resp is None:
                return {"cancelled": True, "reason": "dismissed"}
            answers.append(
                {"question": q["question"], "selected": [], "text": str(resp)}
            )
        return {"cancelled": False, "answers": answers}

    # ------------------------------------------------------------------ #
    # the tool
    # ------------------------------------------------------------------ #
    async def get_user_clarification(
        self,
        questions: List[dict],
        __event_call__=None,
        __event_emitter__=None,
        __user__: Optional[dict] = None,
    ) -> str:
        """
        ALWAYS use this tool (never the built-in ask_user) to ask the user clarifying questions.
        Ask the user 1-5 clarifying questions in a single interactive modal. Call this ONLY when the
        request is too vague to do well and a wrong guess would waste effort (style, audience, tech
        stack, scope, constraints). Don't ask what you can reasonably infer. Ask everything in ONE call.

        Each question is an object with keys:
          "question" (string, required): short and specific.
          "header" (string, optional): a 1-2 word tag like "Style" or "Audience".
          "options" (list, optional): 2-5 choices, each a string or {"label": str, "description": str,
              "recommended": bool}. Omit "options" for a free-text question.
          "multi" (bool, optional): true if several options may be picked.
          "recommended" is shown as a badge, so set it on at most one option, and only when you have a
              real reason to prefer it. Do NOT mark an option just because it is first. Leave it off if
              the choice is purely a matter of taste. The user can always type their own answer.

        Example: [{"question": "What visual style?", "header": "Style", "options": [
          {"label": "Minimal", "description": "Lots of whitespace"}, {"label": "Bold"}]}]

        :param questions: List of question objects (see above). Plain strings are accepted as free-text questions.
        :return: The user's answers as text, to be used for the rest of the task.
        """
        if not __event_call__:
            return "Error: this environment does not support interactive dialogs. Ask the questions in plain chat instead."

        qs = self._normalize(questions, self.valves.max_questions)
        if not qs:
            return "No valid questions were provided."

        uv = (__user__ or {}).get("valves")
        theme = str(getattr(uv, "theme", "auto") or "auto").lower()
        if theme not in ("auto", "light", "dark"):
            theme = "auto"
        accent = (
            str(getattr(uv, "accent_color", "") or "").strip()
            or self.valves.accent_color
        )
        auto_advance = bool(getattr(uv, "auto_advance", True))
        position = str(getattr(uv, "position", "center") or "center").lower()
        if position not in ("center", "bottom"):
            position = "center"

        def _num(name, default, lo, hi, cast):
            try:
                return max(lo, min(hi, cast(getattr(uv, name, default))))
            except Exception:
                return default

        cfg = {
            "questions": qs,
            "theme": theme,
            "accent": accent,
            "autoAdvance": auto_advance,
            "allowSkip": self.valves.allow_skip,
            "showRecommended": self.valves.show_recommended,
            "timeout": self.valves.timeout_seconds,
            "position": position,
            "width": _num("width_px", 580, 360, 900, int),
            "radius": _num("corner_radius", 20, 0, 32, int),
            "fontScale": _num("font_scale", 1.0, 0.8, 1.5, float),
            "dim": bool(getattr(uv, "dim_background", True)),
            "blur": bool(getattr(uv, "blur_background", True)),
            "hints": bool(getattr(uv, "show_key_hints", True)),
            "customCss": str(getattr(uv, "custom_css", "") or "")[:4000],
        }
        code = _JS.replace("__CFG__", json.dumps(cfg))

        await self._emit(
            __event_emitter__,
            {
                "type": "status",
                "data": {
                    "description": f"Waiting for your answers ({len(qs)} question{'s' if len(qs) != 1 else ''})...",
                    "done": False,
                },
            },
        )

        result = await __event_call__({"type": "execute", "data": {"code": code}})

        failed = (
            not isinstance(result, dict)
            or bool(result.get("error"))
            or ("answers" not in result and not result.get("cancelled"))
        )
        if failed and self.valves.fallback_to_input_dialogs:
            result = await self._fallback(qs, __event_call__)
            failed = not isinstance(result, dict) or bool(result.get("error"))

        if failed:
            err = result.get("error") if isinstance(result, dict) else result
            await self._emit(
                __event_emitter__,
                {
                    "type": "status",
                    "data": {"description": "Couldn't ask the questions", "done": True},
                },
            )
            return f"Could not ask the user ({err}). Ask the questions in plain chat instead."

        if result.get("cancelled"):
            reason = result.get("reason", "dismissed")
            await self._emit(
                __event_emitter__,
                {
                    "type": "status",
                    "data": {
                        "description": (
                            "Questions timed out"
                            if reason == "timeout"
                            else "Questions dismissed"
                        ),
                        "done": True,
                    },
                },
            )
            return (
                "The user did not answer the questions "
                f"({reason}). Don't re-ask immediately: proceed with sensible defaults and state "
                "your assumptions, or ask in plain chat."
            )

        answers = result.get("answers") or []
        answers = (answers + [{}] * len(qs))[: len(qs)]
        done = sum(
            1 for a in answers if a.get("selected") or (a.get("text") or "").strip()
        )
        await self._emit(
            __event_emitter__,
            {
                "type": "status",
                "data": {
                    "description": f"Got {done} of {len(qs)} answers",
                    "done": True,
                },
            },
        )
        return self._format(qs, answers)
