"""
title: Forward to Webhook
author: @G30
author_url: https://openwebui.com/u/G30/
funding_url: https://github.com/open-webui
version: 0.1.0
license: MIT
required_open_webui_version: 0.8.12
icon_url: data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Ik0xOCAxNi45OGgtNS45OWMtMS4xIDAtMS45NS45NC0yLjQ4IDEuOUE0IDQgMCAwIDEgMiAxN2MuMDEtLjcuMi0xLjQuNTctMiIvPjxwYXRoIGQ9Im02IDE3IDMuMTMtNS43OGMuNTMtLjk3LjEtMi4xOC0uNS0zLjFhNCA0IDAgMCAxIDYuODktNC4wNiIvPjxwYXRoIGQ9Im0xMiA2IDMuMTMgNS43M0MxNS42NiAxMi43IDE2LjkgMTMgMTggMTNhNCA0IDAgMCAxIDAgOCIvPjwvc3ZnPg==
"""

import httpx
import json
import asyncio
import re
from datetime import datetime
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any


class Action:
    """
    Advanced Action to forward AI responses to Discord, Slack, Teams, and more.
    Supports platform-specific formatting (Embeds), User Avatars, and Multi-Channel routing.
    """

    class Valves(BaseModel):
        priority: int = Field(default=40, description="UI button sorting priority.")
        webhook_urls: str = Field(
            default="",
            description="Webhook URLs separated by ; or ,",
            json_schema_extra={"input": {"type": "password"}},
        )
        username: str = Field(default="Open WebUI", description="Bot display name.")
        use_user_name: bool = Field(
            default=True, description="Use the chatting user's name as the sender name."
        )
        avatar_url: str = Field(
            default="https://openwebui.com/favicon.png", description="Bot avatar URL."
        )
        send_as_embed: bool = Field(
            default=True, description="Send as a styled Embed (Discord only)."
        )
        embed_color: str = Field(
            default="#34d399", description="Hex color for Discord embeds."
        )
        strip_reasoning: bool = Field(
            default=True, description="Remove 'Thinking' blocks before forwarding."
        )
        forward_as_rich_text: bool = Field(
            default=True, description="Preserve Markdown formatting (Bold, Links, etc)."
        )
        include_metadata: bool = Field(
            default=True, description="Include Model ID and Timestamp in the footer."
        )

    class UserValves(BaseModel):
        webhook_urls: str = Field(
            default="",
            description="User-specific Webhook URLs (overrides global).",
            json_schema_extra={"input": {"type": "password"}},
        )
        forward_as_rich_text: bool = Field(
            default=True, description="Toggle rich formatting preference."
        )

    def __init__(self):
        self.valves = self.Valves()

    def _infer_type(self, url: str) -> str:
        url = url.lower()
        if "discord" in url:
            return "discord"
        if "slack" in url:
            return "slack"
        if "office.com" in url:
            return "teams"
        if "google.com" in url:
            return "google"
        return "generic"

    async def action(
        self,
        body: dict,
        __user__: dict = None,
        __event_emitter__=None,
        __event_call__=None,
    ) -> Optional[dict]:
        # 1. Valve & Auth Setup
        user_valves_raw = __user__.get("valves", {}) if __user__ else {}
        uv = (
            self.UserValves(**user_valves_raw)
            if isinstance(user_valves_raw, dict)
            else user_valves_raw
        )

        raw_urls = uv.webhook_urls or self.valves.webhook_urls
        if not raw_urls:
            if __event_emitter__:
                await __event_emitter__(
                    {
                        "type": "notification",
                        "data": {
                            "type": "error",
                            "content": "No Webhook URL configured",
                        },
                    }
                )
            return None

        url_configs = [
            (u.strip(), self._infer_type(u.strip()))
            for u in re.split(r"[;,]", raw_urls)
            if u.strip()
        ]
        use_rich = uv.forward_as_rich_text and self.valves.forward_as_rich_text

        try:
            # 2. Extract & Clean Content
            messages = body.get("messages", [])
            if not messages:
                return None

            last_msg = messages[-1]
            raw_content = last_msg.get("content", "")
            model_id = last_msg.get("model", body.get("model", "Unknown"))
            sender_name = (
                __user__.get("name", "User")
                if self.valves.use_user_name
                else self.valves.username
            )

            # Reasoning Stripper
            if self.valves.strip_reasoning:
                clean_content = re.sub(
                    r"<(details|thought|reasoning).*?>.*?</\1>",
                    "",
                    raw_content,
                    flags=re.DOTALL | re.IGNORECASE,
                ).strip()
            else:
                clean_content = raw_content

            # Rich Text Processor
            if not use_rich:
                clean_content = re.sub(r"[*_`~#\[\]]", "", clean_content)

            # 3. Build Payloads
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            footer_text = (
                f"Model: {model_id} | {timestamp}"
                if self.valves.include_metadata
                else ""
            )

            if __event_emitter__:
                await __event_emitter__(
                    {
                        "type": "status",
                        "data": {
                            "description": "Forwarding to channels...",
                            "done": False,
                        },
                    }
                )

            async with httpx.AsyncClient() as client:
                tasks = []
                for url, p_type in url_configs:
                    payload = {}

                    if p_type == "discord":
                        if self.valves.send_as_embed:
                            payload = {
                                "username": sender_name,
                                "avatar_url": self.valves.avatar_url,
                                "embeds": [
                                    {
                                        "description": clean_content[
                                            :4000
                                        ],  # Discord Embed limit
                                        "color": int(
                                            self.valves.embed_color.lstrip("#"), 16
                                        ),
                                        "footer": {"text": footer_text},
                                    }
                                ],
                            }
                        else:
                            content = f"**[{sender_name}]**\n{clean_content}"
                            if footer_text:
                                content += f"\n\n`{footer_text}`"
                            payload = {
                                "content": content[:2000],
                                "username": sender_name,
                                "avatar_url": self.valves.avatar_url,
                            }

                    elif p_type in ["slack", "generic"]:
                        text = f"*[Forwarded by {sender_name}]*\n{clean_content}"
                        if footer_text:
                            text += f"\n\n_{footer_text}_"
                        payload = {
                            "text": text,
                            "username": sender_name,
                            "icon_url": self.valves.avatar_url,
                        }

                    elif p_type == "teams":
                        payload = {"text": f"**{sender_name}**: {clean_content}"}

                    tasks.append(client.post(url, json=payload, timeout=15.0))

                # 4. Execute Parallel Forwarding
                responses = await asyncio.gather(*tasks, return_exceptions=True)

            # 5. Result Reporting
            success_count = sum(
                1
                for r in responses
                if isinstance(r, httpx.Response) and r.status_code < 400
            )

            if __event_emitter__:
                if success_count == len(url_configs):
                    await __event_emitter__(
                        {
                            "type": "notification",
                            "data": {
                                "type": "success",
                                "content": f"Successfully forwarded to {success_count} channel(s)!",
                            },
                        }
                    )
                elif success_count > 0:
                    await __event_emitter__(
                        {
                            "type": "notification",
                            "data": {
                                "type": "warning",
                                "content": f"Sent to {success_count}/{len(url_configs)} channels.",
                            },
                        }
                    )
                else:
                    await __event_emitter__(
                        {
                            "type": "notification",
                            "data": {
                                "type": "error",
                                "content": "Forward failed for all channels.",
                            },
                        }
                    )

        except Exception as e:
            if __event_emitter__:
                await __event_emitter__(
                    {
                        "type": "notification",
                        "data": {"type": "error", "content": f"System Error: {str(e)}"},
                    }
                )
        finally:
            if __event_emitter__:
                await __event_emitter__(
                    {"type": "status", "data": {"done": True, "hidden": True}}
                )

        return None
