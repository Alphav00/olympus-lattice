#!/usr/bin/env python3
"""Install community plugins + knowledge bases into Open WebUI via REST.
Usage: OPENWEBUI_API_KEY=... python3 owui_install.py <bundle_dir> [--dry-run] [--kb-only] [--plugins-only]
bundle_dir/plugins/manifest.json  -> [{slug,name,type,function_type,id,file,verdict,...}]
bundle_dir/kb/<bank>/*.md         -> one KB per bank (INDEX.md included)
Never prints the key. Exit 0 on success, 2 if any item failed."""
import json, os, re, sys, time, urllib.request, urllib.error, uuid, mimetypes, sqlite3, subprocess

BASE = os.environ.get("OWUI_BASE", "http://127.0.0.1:23002")
KEY = os.environ.get("OPENWEBUI_API_KEY", "")
if not KEY:
    print("FATAL: OPENWEBUI_API_KEY empty"); sys.exit(1)
H = {"Authorization": f"Bearer {KEY}", "Accept": "application/json"}
DRY = "--dry-run" in sys.argv
KB_ONLY = "--kb-only" in sys.argv
PL_ONLY = "--plugins-only" in sys.argv
bundle = sys.argv[1]
KB_NAMES = {"music": "🎵 Music", "art": "🎨 Art & Image Craft", "plugins-usage": "🧰 Community Plugins — Usage"}

def req(method, path, body=None, raw=None, ctype="application/json"):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    r = urllib.request.Request(BASE + path, data=data, method=method, headers={**H, **({"Content-Type": ctype} if data else {})})
    try:
        with urllib.request.urlopen(r, timeout=120) as resp:
            t = resp.read().decode()
            return resp.status, (json.loads(t) if t.strip().startswith(("{", "[")) else t)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:400]

def frontmatter(src):
    m = re.match(r'\s*"""(.*?)"""', src, re.S)
    fm = {}
    if m:
        for line in m.group(1).splitlines():
            if ":" in line:
                k, v = line.split(":", 1); fm[k.strip().lower()] = v.strip()
    return fm

def existing():
    s1, tools = req("GET", "/api/v1/tools/")
    s2, funcs = req("GET", "/api/v1/functions/")
    return {t["id"]: t for t in (tools if isinstance(tools, list) else [])}, {f["id"]: f for f in (funcs if isinstance(funcs, list) else [])}

results = []
def rec(kind, ident, status, note=""):
    results.append((kind, ident, status, note)); print(f"{kind:9s} {ident:40s} {status:8s} {note}")

if not KB_ONLY:
    man = json.load(open(os.path.join(bundle, "plugins", "manifest.json")))
    tools, funcs = existing()
    for p in man:
        if p.get("verdict") == "block":
            rec("SKIP", p["slug"], "blocked", p.get("notes", "")[:80]); continue
        path = os.path.join(bundle, "plugins", p["file"]) if not os.path.isabs(p["file"]) else p["file"]
        src = open(path, encoding="utf-8").read()
        fm = frontmatter(src)
        pid = p.get("id") or fm.get("id") or re.sub(r"[^a-z0-9_]", "_", p["slug"].lower())
        name = p.get("name") or fm.get("title") or p["slug"]
        meta = {"description": fm.get("description", "")[:500], "manifest": {k: fm[k] for k in ("title", "author", "version", "requirements", "author_url", "funding_url") if k in fm}}
        if p["type"] == "tool":
            body = {"id": pid, "name": name, "content": src, "meta": meta}
            if DRY: rec("DRY", pid, "tool"); continue
            if pid in tools:
                st, out = req("POST", f"/api/v1/tools/id/{pid}/update", body)
                rec("TOOL", pid, "updated" if st == 200 else f"ERR{st}", str(out)[:120] if st != 200 else f"v{fm.get('version','?')}")
            else:
                st, out = req("POST", "/api/v1/tools/create", body)
                rec("TOOL", pid, "created" if st == 200 else f"ERR{st}", str(out)[:120] if st != 200 else f"v{fm.get('version','?')}")
        else:
            ftype = p.get("function_type") or "filter"
            body = {"id": pid, "name": name, "type": ftype, "content": src, "meta": meta}
            if DRY: rec("DRY", pid, ftype); continue
            if pid in funcs:
                st, out = req("POST", f"/api/v1/functions/id/{pid}/update", body)
                verb = "updated"
            else:
                st, out = req("POST", "/api/v1/functions/create", body)
                verb = "created"
            if st != 200:
                rec("FUNC", pid, f"ERR{st}", str(out)[:160]); continue
            active = funcs.get(pid, {}).get("is_active", False)
            if p.get("enable", True) is False:
                verb += "+left-disabled"
            elif not active:
                st2, out2 = req("POST", f"/api/v1/functions/id/{pid}/toggle")
                verb += "+enabled" if st2 == 200 else f"+toggleERR{st2}"
            rec("FUNC", pid, verb, f"{ftype} v{fm.get('version','?')}")

if not PL_ONLY:
    kbroot = os.path.join(bundle, "kb")
    st, kbs = req("GET", "/api/v1/knowledge/?limit=500")
    kbs = kbs.get("items", []) if isinstance(kbs, dict) else (kbs if isinstance(kbs, list) else [])
    byname = {k["name"]: k for k in kbs}
    for bank in sorted(os.listdir(kbroot)):
        d = os.path.join(kbroot, bank)
        if not os.path.isdir(d): continue
        kname = KB_NAMES.get(bank, bank)
        files = sorted(f for f in os.listdir(d) if f.endswith(".md"))
        if DRY: rec("DRY-KB", kname, f"{len(files)} files"); continue
        if kname in byname:
            kid = byname[kname]["id"]; rec("KB", kname, "exists", kid)
        else:
            st, out = req("POST", "/api/v1/knowledge/create", {"name": kname, "description": f"{bank} bank, built 2026-10-28 (kb-v1)"})
            if st != 200: rec("KB", kname, f"ERR{st}", str(out)[:160]); continue
            kid = out["id"]; rec("KB", kname, "created", kid)
        st, have = req("GET", f"/api/v1/knowledge/{kid}/files?limit=500")
        have = have.get("items", []) if isinstance(have, dict) else (have if isinstance(have, list) else [])
        have_names = {(f.get("meta") or {}).get("name") or f.get("filename") for f in have}
        for f in files:
            if f in have_names: rec("KBFILE", f"{bank}/{f}", "exists"); continue
            data = open(os.path.join(d, f), "rb").read()
            bnd = uuid.uuid4().hex
            raw = (f"--{bnd}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{f}\"\r\nContent-Type: text/markdown\r\n\r\n").encode() + data + f"\r\n--{bnd}--\r\n".encode()
            st, out = req("POST", "/api/v1/files/?process=true", raw=raw, ctype=f"multipart/form-data; boundary={bnd}")
            if st != 200: rec("KBFILE", f"{bank}/{f}", f"uploadERR{st}", str(out)[:120]); continue
            fid = out["id"]
            for attempt in range(6):
                st, out = req("POST", f"/api/v1/knowledge/{kid}/file/add", {"file_id": fid})
                if st == 200: break
                time.sleep(3)
            rec("KBFILE", f"{bank}/{f}", "added" if st == 200 else f"addERR{st}", str(out)[:100] if st != 200 else fid[:8])

fails = [r for r in results if "ERR" in r[2]]
print(f"\nSUMMARY total={len(results)} failed={len(fails)}")
sys.exit(2 if fails else 0)
